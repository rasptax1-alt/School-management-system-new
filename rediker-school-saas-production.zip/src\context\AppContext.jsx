import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import {
  seedProducts,
  seedSuppliers,
  seedPurchaseOrders,
  seedMarketTrends,
  generate90DayInventoryHistory,
  generate30DayDemandForecast
} from '../data/supplyChainSeedData';

const AppContext = createContext();

export function AppProvider({ children }) {
  // Persistence state
  const [products, setProducts] = useState(() => {
    const saved = localStorage.getItem('scm_products');
    return saved ? JSON.parse(saved) : seedProducts;
  });

  const [suppliers, setSuppliers] = useState(() => {
    const saved = localStorage.getItem('scm_suppliers');
    return saved ? JSON.parse(saved) : seedSuppliers;
  });

  const [purchaseOrders, setPurchaseOrders] = useState(() => {
    const saved = localStorage.getItem('scm_pos');
    return saved ? JSON.parse(saved) : seedPurchaseOrders;
  });

  const [marketTrends] = useState(() => {
    const saved = localStorage.getItem('scm_trends');
    return saved ? JSON.parse(saved) : seedMarketTrends;
  });

  // Generator & UI states
  const [isGeneratingRestock, setIsGeneratingRestock] = useState(false);
  const [newProductModalOpen, setNewProductModalOpen] = useState(false);
  const [newPOModalOpen, setNewPOModalOpen] = useState(false);
  const [newSupplierModalOpen, setNewSupplierModalOpen] = useState(false);
  const [prefilledPOProduct, setPrefilledPOProduct] = useState(null);
  const [toasts, setToasts] = useState([]);

  // Save to localStorage on state changes
  useEffect(() => {
    localStorage.setItem('scm_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('scm_suppliers', JSON.stringify(suppliers));
  }, [suppliers]);

  useEffect(() => {
    localStorage.setItem('scm_pos', JSON.stringify(purchaseOrders));
  }, [purchaseOrders]);

  // Toast notification helper
  const addToast = (message, type = 'success') => {
    const id = Date.now() + Math.random().toString(36).substring(2, 6);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3800);
  };

  const removeToast = (id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Maps for fast lookups
  const supplierMap = useMemo(() => {
    return Object.fromEntries(suppliers.map(s => [s.id, s]));
  }, [suppliers]);

  const productMap = useMemo(() => {
    return Object.fromEntries(products.map(p => [p.id, p]));
  }, [products]);

  // Metrics calculations
  const inventoryValue = useMemo(() => {
    return products
      .filter(p => p.status === 'active')
      .reduce((sum, p) => sum + (p.current_stock || 0) * (p.unit_cost || 0), 0);
  }, [products]);

  const lowStockProducts = useMemo(() => {
    return products.filter(
      p => p.status === 'active' && (p.current_stock || 0) <= (p.reorder_point || 0)
    );
  }, [products]);

  const activePurchaseOrders = useMemo(() => {
    return purchaseOrders.filter(po =>
      ['suggested', 'pending_approval', 'approved', 'ordered'].includes(po.status)
    );
  }, [purchaseOrders]);

  // Time-series history & forecast
  const historyPoints = useMemo(() => {
    return generate90DayInventoryHistory(inventoryValue || 180000);
  }, [inventoryValue]);

  const forecastPoints = useMemo(() => {
    const avgVelocity = products.reduce((acc, p) => acc + (p.daily_sales_velocity || 0), 0);
    return generate30DayDemandForecast(avgVelocity || 50);
  }, [products]);

  // CRUD Actions
  const addProduct = (newProd) => {
    const id = 'prod-' + Date.now();
    const created = {
      id,
      status: 'active',
      current_stock: Number(newProd.current_stock) || 0,
      reorder_point: Number(newProd.reorder_point) || 0,
      daily_sales_velocity: Number(newProd.daily_sales_velocity) || 1,
      unit_cost: Number(newProd.unit_cost) || 0,
      selling_price: Number(newProd.selling_price) || 0,
      image_url: newProd.image_url || 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=300&auto=format&fit=crop&q=80',
      ...newProd
    };
    setProducts(prev => [created, ...prev]);
    return created;
  };

  const updateProduct = (id, updates) => {
    setProducts(prev => prev.map(p => (p.id === id ? { ...p, ...updates } : p)));
  };

  const deleteProduct = (id) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const addSupplier = (newSup) => {
    const id = 'sup-' + Date.now();
    const created = {
      id,
      default_lead_time_days: Number(newSup.default_lead_time_days) || 7,
      reliability_score: Number(newSup.reliability_score) || 95,
      image_url: newSup.image_url || 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=200&auto=format&fit=crop&q=80',
      ...newSup
    };
    setSuppliers(prev => [created, ...prev]);
    return created;
  };

  const updateSupplier = (id, updates) => {
    setSuppliers(prev => prev.map(s => (s.id === id ? { ...s, ...updates } : s)));
  };

  const addPurchaseOrder = (newPO) => {
    const id = 'po-' + Date.now();
    const prod = productMap[newPO.product_id];
    const unit_cost = Number(newPO.unit_cost) || (prod?.unit_cost || 0);
    const quantity = Number(newPO.quantity) || 100;
    const total_cost = quantity * unit_cost;

    const created = {
      id,
      po_number: 'PO-' + new Date().getFullYear() + '-' + Math.floor(100 + Math.random() * 900),
      created_date: new Date().toISOString().split('T')[0],
      status: newPO.status || 'pending_approval',
      quantity,
      unit_cost,
      total_cost,
      ...newPO
    };
    setPurchaseOrders(prev => [created, ...prev]);
    return created;
  };

  const updatePOStatus = (poId, status, extraData = {}) => {
    setPurchaseOrders(prev =>
      prev.map(po => {
        if (po.id !== poId) return po;
        const updated = { ...po, status, ...extraData };
        if (status === 'approved' && !updated.approval_date) {
          updated.approval_date = new Date().toISOString().split('T')[0];
        }
        // If received, restock product!
        if (status === 'received' && po.status !== 'received') {
          setProducts(curProds =>
            curProds.map(p =>
              p.id === po.product_id ? { ...p, current_stock: (p.current_stock || 0) + po.quantity } : p
            )
          );
        }
        return updated;
      })
    );
  };

  const approveSuggestion = (poId) => {
    updatePOStatus(poId, 'approved');
  };

  const rejectSuggestion = (poId, reason = '') => {
    setPurchaseOrders(prev =>
      prev.map(po => {
        if (po.id !== poId) return po;
        return {
          ...po,
          status: 'cancelled',
          ai_reasoning: reason ? `${po.ai_reasoning || ''} (Rejected: ${reason})` : po.ai_reasoning
        };
      })
    );
  };

  const bulkApproveSuggestions = (poIds) => {
    const idSet = new Set(poIds);
    const today = new Date().toISOString().split('T')[0];
    setPurchaseOrders(prev =>
      prev.map(po => {
        if (idSet.has(po.id)) {
          return { ...po, status: 'approved', approval_date: today };
        }
        return po;
      })
    );
  };

  const modifySuggestion = (poId, newQuantity, newDeliveryDate) => {
    setPurchaseOrders(prev =>
      prev.map(po => {
        if (po.id !== poId) return po;
        const qty = Number(newQuantity) || po.quantity;
        const total = qty * (po.unit_cost || 0);
        return {
          ...po,
          quantity: qty,
          total_cost: total,
          expected_delivery: newDeliveryDate || po.expected_delivery
        };
      })
    );
  };

  // Run AI Restock Generator simulation
  const runRestockGenerator = async () => {
    setIsGeneratingRestock(true);
    await new Promise(r => setTimeout(r, 1400));

    // Identify products in low/out-of-stock without an active suggested PO
    const existingSuggestedProdIds = new Set(
      purchaseOrders.filter(po => po.status === 'suggested').map(po => po.product_id)
    );

    const candidates = products.filter(
      p => p.status === 'active' && (p.current_stock <= p.reorder_point || p.current_stock < 30)
    );

    let createdCount = 0;
    const newSuggestions = [];

    candidates.forEach(cand => {
      if (!existingSuggestedProdIds.has(cand.id)) {
        const sup = supplierMap[cand.supplier_id] || suppliers[0];
        const leadDays = sup?.default_lead_time_days || 10;
        const recommendedQty = Math.max(100, Math.round(cand.daily_sales_velocity * (leadDays + 15)));
        const deliveryDate = new Date();
        deliveryDate.setDate(deliveryDate.getDate() + leadDays);

        const newPo = {
          id: 'po-ai-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
          po_number: 'PO-' + new Date().getFullYear() + '-' + Math.floor(100 + Math.random() * 900),
          product_id: cand.id,
          supplier_id: cand.supplier_id || sup?.id,
          quantity: recommendedQty,
          unit_cost: cand.unit_cost,
          total_cost: recommendedQty * cand.unit_cost,
          status: 'suggested',
          created_date: new Date().toISOString().split('T')[0],
          suggested_date: new Date().toISOString().split('T')[0],
          expected_delivery: deliveryDate.toISOString().split('T')[0],
          ai_reasoning: `Stock (${cand.current_stock}) will deplete within ${Math.max(1, Math.round(cand.current_stock / (cand.daily_sales_velocity || 1)))} days. Reordering ${recommendedQty} units covers ${leadDays}-day supplier lead time with a 15-day safety buffer.`,
          ai_reasoningAr: `المخزون (${cand.current_stock}) سينفد خلال ${Math.max(1, Math.round(cand.current_stock / (cand.daily_sales_velocity || 1)))} أيام بمعدل الاستهلاك الحالي. طلب ${recommendedQty} وحدة يغطي مهلة التوريد (${leadDays} يوماً) مع هامش أمان لـ 15 يوماً.`
        };
        newSuggestions.push(newPo);
        createdCount++;
      }
    });

    if (newSuggestions.length > 0) {
      setPurchaseOrders(prev => [...newSuggestions, ...prev]);
    }

    setIsGeneratingRestock(false);
    return createdCount;
  };

  const triggerQuickRestockModal = (product) => {
    setPrefilledPOProduct(product);
    setNewPOModalOpen(true);
  };

  return (
    <AppContext.Provider
      value={{
        products,
        suppliers,
        purchaseOrders,
        marketTrends,
        supplierMap,
        productMap,
        inventoryValue,
        lowStockProducts,
        activePurchaseOrders,
        historyPoints,
        forecastPoints,
        isGeneratingRestock,
        toasts,
        addToast,
        removeToast,
        addProduct,
        updateProduct,
        deleteProduct,
        addSupplier,
        updateSupplier,
        addPurchaseOrder,
        updatePOStatus,
        approveSuggestion,
        rejectSuggestion,
        bulkApproveSuggestions,
        modifySuggestion,
        runRestockGenerator,
        triggerQuickRestockModal,
        newProductModalOpen,
        setNewProductModalOpen,
        newPOModalOpen,
        setNewPOModalOpen,
        newSupplierModalOpen,
        setNewSupplierModalOpen,
        prefilledPOProduct,
        setPrefilledPOProduct
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
