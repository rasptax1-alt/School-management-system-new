import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  Award, 
  Search, 
  UploadCloud, 
  DownloadCloud, 
  FileSpreadsheet, 
  Printer, 
  CheckCircle2, 
  SlidersHorizontal 
} from 'lucide-react';
import { exportDataToCsv } from '../services/csvExportImport';

export function Gradebook({ onOpenCsvModal, onOpenReportCard }) {
  const { currentSchool, students, grades, setGrades, showToast } = useSchool();
  const { t, lang, isRTL } = useLanguage();

  const [selectedSubject, setSelectedSubject] = useState('all');
  const [selectedTerm, setSelectedTerm] = useState('الفصل الدراسي الأول');

  const filteredGrades = grades.filter(g => {
    const matchesSub = selectedSubject === 'all' || g.subjectNameAr === selectedSubject;
    const matchesTerm = g.term === selectedTerm;
    return matchesSub && matchesTerm;
  });

  const handleExportCsv = () => {
    const formatted = filteredGrades.map(g => ({
      "رقم_الطالب": g.studentId,
      "اسم_الطالب": g.studentNameAr,
      "رمز_المادة": g.classCode,
      "المادة_عربي": g.subjectNameAr,
      "الفصل": g.term,
      "النشاط_اليومي_20": g.dailyActivities,
      "امتحان_نصف_السنة_30": g.midtermExam,
      "الشفهي_والكويزات_10": g.quizzes,
      "النهائي_40": g.finalExam,
      "المجموع_100": g.totalScore,
      "التقدير": g.letterGrade,
      "الحالة": g.status
    }));

    exportDataToCsv(formatted, `grades-${currentSchool.code}.csv`);
    showToast(isRTL ? 'تم تصدير سجل العلامات والدرجات CSV بنجاح' : 'Grades CSV exported successfully');
  };

  const primaryColor = currentSchool.theme?.primary || '#0F766E';

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              {t('gradebookModule')} (TeacherPlus)
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              دفتر الدرجات الإلكتروني، رصد العلامات وإصدار الشهادات المدرسية • {currentSchool.nameAr}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => onOpenCsvModal('grades')}
            className="px-3.5 py-2.5 rounded-xl border border-teal-200 bg-teal-50 text-teal-800 text-xs font-bold hover:bg-teal-100 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <UploadCloud className="w-4 h-4 text-teal-700" />
            <span>استيراد درجات (CSV)</span>
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-800 text-xs font-bold hover:bg-slate-50 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <DownloadCloud className="w-4 h-4 text-slate-600" />
            <span>{t('exportCsv')}</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-700 font-semibold focus:outline-none"
          >
            <option value="all">كافة المواد الدراسية</option>
            <option value="الرياضيات">الرياضيات</option>
            <option value="الفيزياء">الفيزياء</option>
            <option value="اللغة العربية">اللغة العربية</option>
            <option value="الكيمياء العامة">الكيمياء العامة</option>
          </select>

          <select
            value={selectedTerm}
            onChange={(e) => setSelectedTerm(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-700 font-semibold focus:outline-none"
          >
            <option value="الفصل الدراسي الأول">الفصل الدراسي الأول</option>
            <option value="الفصل الدراسي الثاني">الفصل الدراسي الثاني</option>
            <option value="امتحانات الدور الثاني">امتحانات الدور الثاني</option>
          </select>
        </div>
      </div>

      {/* Gradebook Table */}
      <div className="bg-white rounded-3xl border border-slate-200/90 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-start text-xs">
            <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
              <tr>
                <th className="p-3.5 text-start">{t('studentId')}</th>
                <th className="p-3.5 text-start">{t('studentName')}</th>
                <th className="p-3.5 text-start">المادة</th>
                <th className="p-3.5 text-center">النشاط (20)</th>
                <th className="p-3.5 text-center">نصف السنة (30)</th>
                <th className="p-3.5 text-center">الشفهي (10)</th>
                <th className="p-3.5 text-center">النهائي (40)</th>
                <th className="p-3.5 text-center">{t('totalScore')}</th>
                <th className="p-3.5 text-center">{t('letterGrade')}</th>
                <th className="p-3.5 text-center">الشهادة الرسمية</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredGrades.map((g) => {
                const targetStudent = students.find(s => s.studentId === g.studentId);
                return (
                  <tr key={g.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3.5 font-mono font-bold text-slate-700">{g.studentId}</td>
                    <td className="p-3.5 font-bold text-slate-900">{g.studentNameAr}</td>
                    <td className="p-3.5 text-slate-700 font-medium">{g.subjectNameAr}</td>
                    <td className="p-3.5 text-center text-slate-600">{g.dailyActivities}</td>
                    <td className="p-3.5 text-center text-slate-600">{g.midtermExam}</td>
                    <td className="p-3.5 text-center text-slate-600">{g.quizzes}</td>
                    <td className="p-3.5 text-center text-slate-600">{g.finalExam}</td>
                    <td className="p-3.5 text-center font-extrabold text-slate-900 text-sm">
                      {g.totalScore}
                    </td>
                    <td className="p-3.5 text-center font-bold text-emerald-700">
                      {g.letterGrade}
                    </td>
                    <td className="p-3.5 text-center">
                      <button
                        type="button"
                        onClick={() => targetStudent && onOpenReportCard(targetStudent)}
                        className="px-3 py-1.5 rounded-xl bg-slate-900 text-white font-bold hover:bg-slate-800 transition-colors flex items-center gap-1 mx-auto"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>طباعة الشهادة</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
