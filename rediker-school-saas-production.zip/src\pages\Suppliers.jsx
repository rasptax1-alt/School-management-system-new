import React from 'react';
import { NavLink } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useApp } from '../context/AppContext';
import {
  Building2,
  Plus,
  ArrowUpRight,
  MapPin,
  Clock,
  ShieldCheck,
  Mail,
  Phone,
  Package
} from 'lucide-react';

export default function Suppliers() {
  const { t, isRtl } = useLanguage();
  const { suppliers, products, setNewSupplierModalOpen } = useApp();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-24 flex flex-col gap-6">
      {/* Header & Add Supplier CTA */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#DFDFDF]">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-4 h-4 rounded-full bg-[#FF9000]" />
            <h1 className="font-semibold text-lg text-[#111111]">
              {t('suppliersTitle')}
            </h1>
            <span className="text-xs text-[#898989]">
              ({suppliers.length} {t('suppliersCount')})
            </span>
          </div>
        </div>

        <button
          onClick={() => setNewSupplierModalOpen(true)}
          className="flex items-center gap-2 h-9 px-4 rounded-full bg-[#FF9000] hover:bg-[#111111] text-[#111111] hover:text-white transition-all text-xs font-semibold self-start sm:self-auto shadow-sm"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{t('addSupplier')}</span>
        </button>
      </div>

      {/* Suppliers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {suppliers.map(sup => {
          const supProducts = products.filter(p => p.supplier_id === sup.id);

          return (
            <div
              key={sup.id}
              className="bg-white rounded-3xl p-5 border border-[#DFDFDF] shadow-card-subtle flex flex-col justify-between hover:border-[#111111] transition-all group"
            >
              <div>
                {/* Top Info */}
                <div className="flex items-start gap-3.5">
                  <img
                    src={sup.image_url}
                    alt={sup.name}
                    className="w-12 h-12 rounded-2xl object-cover border border-[#DFDFDF] shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <h3 className="font-semibold text-sm text-[#111111] group-hover:text-[#FF9000] transition-colors truncate">
                      {isRtl ? (sup.nameAr || sup.name) : sup.name}
                    </h3>
                    <div className="flex items-center gap-1 text-[11px] text-[#898989] mt-0.5">
                      <MapPin className="w-3 h-3 text-[#FF9000]" />
                      <span className="truncate">{isRtl ? (sup.locationAr || sup.location) : sup.location}</span>
                    </div>
                  </div>
                </div>

                {/* Score & Lead Time Badges */}
                <div className="grid grid-cols-3 gap-2 my-4 pt-3 border-t border-[#DFDFDF]/70 text-center text-xs">
                  <div className="p-2 rounded-xl bg-[#F3F3F5]">
                    <span className="text-[10px] text-[#898989] block">{t('colReliability')}</span>
                    <span className="font-bold text-[#10B981] mt-0.5 block">{sup.reliability_score}%</span>
                  </div>
                  <div className="p-2 rounded-xl bg-[#F3F3F5]">
                    <span className="text-[10px] text-[#898989] block">{t('colLeadTime')}</span>
                    <span className="font-bold text-[#111111] mt-0.5 block">{sup.default_lead_time_days}d</span>
                  </div>
                  <div className="p-2 rounded-xl bg-[#F3F3F5]">
                    <span className="text-[10px] text-[#898989] block">{t('colActiveProducts')}</span>
                    <span className="font-bold text-[#111111] mt-0.5 block">{supProducts.length}</span>
                  </div>
                </div>

                {/* Contact info snippets */}
                <div className="flex flex-col gap-1 text-[11px] text-[#343434] mb-3">
                  <div className="flex items-center gap-2 text-[#898989]">
                    <Mail className="w-3 h-3 text-[#898989]" />
                    <span className="truncate">{sup.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[#898989]">
                    <Phone className="w-3 h-3 text-[#898989]" />
                    <span>{sup.phone}</span>
                  </div>
                </div>
              </div>

              {/* View Supplier Profile Action */}
              <NavLink
                to={`/suppliers/${sup.id}`}
                className="w-full mt-2 h-9 rounded-full bg-[#EBEBED] hover:bg-[#111111] text-[#111111] hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
              >
                <span>{t('viewSupplier')}</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </NavLink>
            </div>
          );
        })}
      </div>
    </div>
  );
}
