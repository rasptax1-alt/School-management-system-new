import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useApp } from '../context/AppContext';
import {
  LayoutDashboard,
  Package,
  Sparkles,
  ShoppingCart,
  Building2,
  TrendingUp
} from 'lucide-react';

export default function MobileDock() {
  const { t } = useLanguage();
  const { purchaseOrders } = useApp();
  const location = useLocation();

  const suggestedCount = purchaseOrders.filter(po => po.status === 'suggested').length;

  const links = [
    { path: '/', label: t('navDashboard'), icon: LayoutDashboard },
    { path: '/products', label: t('navProducts'), icon: Package },
    {
      path: '/ai-suggestions',
      label: t('navAISuggestions'),
      icon: Sparkles,
      badge: suggestedCount > 0 ? suggestedCount : null
    },
    { path: '/purchase-orders', label: t('navProcurement'), icon: ShoppingCart },
    { path: '/suppliers', label: t('navSuppliers'), icon: Building2 },
    { path: '/market-trends', label: t('navMarketTrends'), icon: TrendingUp }
  ];

  return (
    <div className="lg:hidden fixed bottom-3 left-0 right-0 z-50 flex justify-center pointer-events-none px-4">
      <div className="glass-dock rounded-full p-1.5 shadow-dock flex items-center gap-1 pointer-events-auto max-w-md w-full justify-around border border-white/10">
        {links.map(link => {
          const Icon = link.icon;
          const isActive =
            link.path === '/'
              ? location.pathname === '/'
              : location.pathname.startsWith(link.path);

          return (
            <NavLink
              key={link.path}
              to={link.path}
              className={`flex flex-col items-center justify-center p-2 rounded-full relative transition-all duration-150 ${
                isActive
                  ? 'bg-[#FF9000] text-[#111111]'
                  : 'text-white/70 hover:text-white'
              }`}
              title={link.label}
            >
              <Icon className="w-5 h-5" />
              {link.badge && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#F24E2C] text-white text-[9px] font-bold flex items-center justify-center">
                  {link.badge}
                </span>
              )}
            </NavLink>
          );
        })}
      </div>
    </div>
  );
}
