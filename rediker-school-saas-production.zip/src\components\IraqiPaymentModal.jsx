import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  X, 
  CheckCircle2, 
  Smartphone, 
  CreditCard, 
  QrCode, 
  Zap, 
  ShieldCheck, 
  Lock, 
  Printer, 
  Building2,
  AlertCircle
} from 'lucide-react';

export function IraqiPaymentModal({ invoice, onClose, onPaymentSuccess }) {
  const { currentSchool, markInvoicePaid, showToast } = useSchool();
  const { t, lang, isRTL } = useLanguage();

  const [selectedGateway, setSelectedGateway] = useState('zaincash'); // zaincash, qicard, fib, asiapay
  const [step, setStep] = useState('input'); // input, processing, success
  const [loading, setLoading] = useState(false);

  // Form states
  const [phone, setPhone] = useState('07801234567');
  const [pin, setPin] = useState('1234');
  const [otp, setOtp] = useState('8842');
  const [cardNumber, setCardNumber] = useState('5352 1890 2837 9104');
  const [cardHolder, setCardHolder] = useState(invoice?.guardianName || 'ولي الأمر');
  const [cardExpiry, setCardExpiry] = useState('10/28');
  const [cardCvv, setCardCvv] = useState('492');
  const [completedPayment, setCompletedPayment] = useState(null);

  if (!invoice) return null;

  const totalAmountIQD = invoice.amountIQD || 2500000;
  
  // Calculate small processing fee based on gateway
  let fee = Math.round(totalAmountIQD * 0.01);
  if (selectedGateway === 'qicard') fee = Math.round(totalAmountIQD * 0.012);
  if (selectedGateway === 'fib') fee = Math.round(totalAmountIQD * 0.008);

  const payableTotal = totalAmountIQD + fee;

  const handleProcessPayment = () => {
    setLoading(true);
    setStep('processing');

    setTimeout(() => {
      const receiptNumber = `REC-IRQ-${Date.now().toString().slice(-8)}`;
      const transactionId = `TXN-${selectedGateway.toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`;

      const gatewayLabels = {
        zaincash: 'زين كاش العراق (ZainCash)',
        qicard: 'بطاقة كي كارد (Qi Card / ISC)',
        fib: 'مصرف العراق الأول (First Iraqi Bank - FIB)',
        asiapay: 'آسيا باي / فاست باي (AsiaPay)'
      };

      const paymentResult = {
        invoiceId: invoice.id,
        invoiceNumber: invoice.invoiceNumber,
        studentId: invoice.studentId,
        studentName: invoice.studentNameAr,
        schoolName: currentSchool.nameAr,
        amountIQD: totalAmountIQD,
        gateway: selectedGateway,
        gatewayName: gatewayLabels[selectedGateway],
        transactionId,
        receiptNumber,
        paidDate: new Date().toISOString().split('T')[0],
        paidTime: new Date().toLocaleTimeString(isRTL ? 'ar-IQ' : 'en-US')
      };

      markInvoicePaid(invoice.id, paymentResult);
      setCompletedPayment(paymentResult);
      setLoading(false);
      setStep('success');

      if (onPaymentSuccess) {
        onPaymentSuccess(paymentResult);
      }
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-slate-100 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div 
          className="p-5 text-white flex items-center justify-between"
          style={{ backgroundColor: currentSchool.theme?.primary || '#0F766E' }}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-white">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg">
                {t('payNow')}
              </h3>
              <p className="text-xs text-white/80">
                {currentSchool.nameAr} • {invoice.invoiceNumber}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6">

          {/* Invoice Summary Card */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
            <div>
              <p className="text-xs text-slate-500 font-medium">{t('studentName')}</p>
              <h4 className="text-sm font-bold text-slate-900">{invoice.studentNameAr}</h4>
              <p className="text-xs text-slate-600 mt-0.5">{invoice.feeCategory}</p>
            </div>
            <div className="text-end">
              <p className="text-xs text-slate-500 font-medium">{t('totalAmount')}</p>
              <p className="text-lg font-black text-emerald-700">
                {totalAmountIQD.toLocaleString()} <span className="text-xs font-bold">{t('iqd')}</span>
              </p>
            </div>
          </div>

          {step === 'input' && (
            <>
              {/* Select Iraqi Gateway */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">
                  {t('selectPaymentGateway')}
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  
                  {/* ZainCash */}
                  <button
                    type="button"
                    onClick={() => setSelectedGateway('zaincash')}
                    className={`p-3 rounded-2xl border text-start flex items-center gap-2.5 transition-all ${
                      selectedGateway === 'zaincash' 
                        ? 'border-rose-500 bg-rose-50/50 ring-2 ring-rose-500/20' 
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0">
                      <Smartphone className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-extrabold text-slate-900">زين كاش</p>
                      <p className="text-[10px] text-slate-500">ZainCash Wallet</p>
                    </div>
                  </button>

                  {/* Qi Card */}
                  <button
                    type="button"
                    onClick={() => setSelectedGateway('qicard')}
                    className={`p-3 rounded-2xl border text-start flex items-center gap-2.5 transition-all ${
                      selectedGateway === 'qicard' 
                        ? 'border-blue-600 bg-blue-50/50 ring-2 ring-blue-600/20' 
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-xl bg-blue-700 text-white flex items-center justify-center shrink-0">
                      <CreditCard className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-extrabold text-slate-900">كي كارد (Qi)</p>
                      <p className="text-[10px] text-slate-500">Mastercard / ISC</p>
                    </div>
                  </button>

                  {/* First Iraqi Bank (FIB) */}
                  <button
                    type="button"
                    onClick={() => setSelectedGateway('fib')}
                    className={`p-3 rounded-2xl border text-start flex items-center gap-2.5 transition-all ${
                      selectedGateway === 'fib' 
                        ? 'border-teal-600 bg-teal-50/50 ring-2 ring-teal-600/20' 
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-xl bg-teal-700 text-white flex items-center justify-center shrink-0">
                      <QrCode className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-extrabold text-slate-900">مصرف العراق الأول</p>
                      <p className="text-[10px] text-slate-500">FIB Digital Bank</p>
                    </div>
                  </button>

                  {/* AsiaPay / FastPay */}
                  <button
                    type="button"
                    onClick={() => setSelectedGateway('asiapay')}
                    className={`p-3 rounded-2xl border text-start flex items-center gap-2.5 transition-all ${
                      selectedGateway === 'asiapay' 
                        ? 'border-amber-600 bg-amber-50/50 ring-2 ring-amber-600/20' 
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0">
                      <Zap className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-extrabold text-slate-900">آسيا باي</p>
                      <p className="text-[10px] text-slate-500">AsiaPay / FastPay</p>
                    </div>
                  </button>

                </div>
              </div>

              {/* Gateway Interactive Inputs */}
              {selectedGateway === 'zaincash' && (
                <div className="p-4 rounded-2xl bg-rose-50/30 border border-rose-100 space-y-3">
                  <div className="flex items-center gap-2 text-rose-800 text-xs font-bold">
                    <Smartphone className="w-4 h-4" />
                    <span>الدفع عبر محفظة زين كاش العراق الإلكترونية</span>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">{t('phoneNumber')}</label>
                    <input 
                      type="text" 
                      value={phone} 
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="07801234567"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-rose-500 bg-white"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">{t('enterPin')}</label>
                      <input 
                        type="password" 
                        value={pin} 
                        onChange={(e) => setPin(e.target.value)}
                        placeholder="••••"
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-rose-500 bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">رمز التحقق OTP</label>
                      <input 
                        type="text" 
                        value={otp} 
                        onChange={(e) => setOtp(e.target.value)}
                        placeholder="8842"
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-rose-500 bg-white"
                      />
                    </div>
                  </div>
                </div>
              )}

              {selectedGateway === 'qicard' && (
                <div className="p-4 rounded-2xl bg-blue-50/30 border border-blue-100 space-y-3">
                  <div className="flex items-center gap-2 text-blue-900 text-xs font-bold">
                    <CreditCard className="w-4 h-4" />
                    <span>بوابة كي كارد والشركة العالمية للبطاقة الذكية (ISC)</span>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">{t('cardNumber')}</label>
                    <input 
                      type="text" 
                      value={cardNumber} 
                      onChange={(e) => setCardNumber(e.target.value)}
                      placeholder="5352 •••• •••• ••••"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">{t('cardExpiry')}</label>
                      <input 
                        type="text" 
                        value={cardExpiry} 
                        onChange={(e) => setCardExpiry(e.target.value)}
                        placeholder="MM/YY"
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">{t('cardCvv')}</label>
                      <input 
                        type="password" 
                        value={cardCvv} 
                        onChange={(e) => setCardCvv(e.target.value)}
                        placeholder="•••"
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      />
                    </div>
                  </div>
                </div>
              )}

              {selectedGateway === 'fib' && (
                <div className="p-4 rounded-2xl bg-teal-50/40 border border-teal-100 text-center space-y-3">
                  <div className="flex items-center justify-center gap-2 text-teal-900 text-xs font-bold">
                    <QrCode className="w-4 h-4" />
                    <span>الدفع الفوري عبر مسح رمز الاستجابة السريعة FIB QR</span>
                  </div>
                  <div className="p-3 bg-white rounded-2xl border border-slate-200 inline-block shadow-sm">
                    {/* SVG Mock QR Code */}
                    <div className="w-36 h-36 mx-auto bg-slate-900 rounded-lg p-2.5 flex flex-col justify-between">
                      <div className="flex justify-between">
                        <div className="w-8 h-8 bg-white rounded-xs p-1"><div className="w-full h-full bg-slate-900"></div></div>
                        <div className="w-8 h-8 bg-white rounded-xs p-1"><div className="w-full h-full bg-slate-900"></div></div>
                      </div>
                      <div className="flex items-center justify-center text-teal-400 font-black text-xs">
                        FIB PAY
                      </div>
                      <div className="flex justify-between">
                        <div className="w-8 h-8 bg-white rounded-xs p-1"><div className="w-full h-full bg-slate-900"></div></div>
                        <div className="w-4 h-4 bg-teal-400 rounded-full"></div>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-slate-600 font-medium">
                    {t('fibQrInstruction')}
                  </p>
                </div>
              )}

              {selectedGateway === 'asiapay' && (
                <div className="p-4 rounded-2xl bg-amber-50/30 border border-amber-100 space-y-3">
                  <div className="flex items-center gap-2 text-amber-900 text-xs font-bold">
                    <Zap className="w-4 h-4" />
                    <span>محفظة آسيا باي وفاست باي العراق (AsiaPay / FastPay)</span>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">رقم خط آسيا سيل</label>
                    <input 
                      type="text" 
                      value="07705544332" 
                      readOnly
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">رمز التأكيد والموافقة</label>
                    <input 
                      type="password" 
                      value="9901" 
                      readOnly
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white"
                    />
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-3 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-50 transition-colors"
                >
                  {t('cancel')}
                </button>
                <button
                  type="button"
                  onClick={handleProcessPayment}
                  className="flex-1 py-3 rounded-xl text-white text-xs font-bold shadow-md hover:opacity-95 transition-all flex items-center justify-center gap-2"
                  style={{ backgroundColor: currentSchool.theme?.primary || '#0F766E' }}
                >
                  <Lock className="w-4 h-4" />
                  <span>تأكيد ودفع {payableTotal.toLocaleString()} {t('iqd')}</span>
                </button>
              </div>
            </>
          )}

          {step === 'processing' && (
            <div className="py-12 text-center space-y-4">
              <div className="w-12 h-12 border-4 border-slate-200 border-t-emerald-600 rounded-full animate-spin mx-auto" />
              <p className="text-sm font-bold text-slate-800">{t('processingPayment')}</p>
              <p className="text-xs text-slate-500">جاري الاتصال بالسيرفر الآمن للبنك المركزي العراقي...</p>
            </div>
          )}

          {step === 'success' && completedPayment && (
            <div className="py-6 text-center space-y-5 animate-in fade-in">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <div>
                <h4 className="text-lg font-black text-slate-900">{t('paymentSuccess')}</h4>
                <p className="text-xs text-slate-500 mt-1">
                  تم إصدار وصل القبض الرسمي وقيد المبلغ في حساب المدرسة
                </p>
              </div>

              {/* Receipt Details Box */}
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-xs text-start space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">{t('receiptNo')}:</span>
                  <span className="font-bold text-slate-900">{completedPayment.receiptNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">{t('transactionId')}:</span>
                  <span className="font-bold text-slate-700">{completedPayment.transactionId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">{t('paymentGateway')}:</span>
                  <span className="font-bold text-emerald-700">{completedPayment.gatewayName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">{t('paidAt')}:</span>
                  <span className="font-bold text-slate-700">{completedPayment.paidDate} {completedPayment.paidTime}</span>
                </div>
              </div>

              {/* Print Receipt / Finish Buttons */}
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    window.print();
                  }}
                  className="flex-1 py-3 rounded-xl border border-slate-300 text-slate-800 text-xs font-bold hover:bg-slate-100 flex items-center justify-center gap-2"
                >
                  <Printer className="w-4 h-4" />
                  <span>{t('print')} {t('officialReceipt')}</span>
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-3 rounded-xl text-white text-xs font-bold hover:opacity-95"
                  style={{ backgroundColor: currentSchool.theme?.primary || '#0F766E' }}
                >
                  {t('close')}
                </button>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
