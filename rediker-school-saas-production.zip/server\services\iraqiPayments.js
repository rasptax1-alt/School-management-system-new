// Iraqi Payment Gateways Processing Service
// Integrations: ZainCash, QiCard (ISC), First Iraqi Bank (FIB), AsiaPay / FastPay

export class IraqiPaymentService {
  /**
   * Initialize a payment transaction for an Iraqi gateway
   */
  static async initiatePayment({ gateway, amountIQD, invoiceNumber, studentName, studentId, schoolName, guardianPhone, notes }) {
    const timestamp = Date.now();
    const transactionId = `TXN-IRQ-${gateway.toUpperCase()}-${timestamp.toString().slice(-6)}`;
    
    // Calculate fee based on gateway
    let feePercent = 0.01;
    if (gateway === 'qicard') feePercent = 0.012;
    else if (gateway === 'fib') feePercent = 0.008;
    else if (gateway === 'zaincash') feePercent = 0.01;
    else if (gateway === 'asiapay') feePercent = 0.01;

    const gatewayFee = Math.round(amountIQD * feePercent);
    const totalPayableIQD = amountIQD + gatewayFee;

    // Gateway-specific transaction metadata
    let gatewayDetails = {};

    switch (gateway.toLowerCase()) {
      case 'zaincash':
        gatewayDetails = {
          provider: "ZainCash Iraq",
          walletPrefix: "078",
          referenceCode: `ZC-${Math.floor(100000 + Math.random() * 900000)}`,
          merchantId: "5ffb892a40e53a2b1f8e1234",
          step: "awaiting_otp",
          smsInstructionAr: "تم إرسال رمز التحقق OTP إلى هاتف المحفظة المسجل",
          smsInstructionEn: "An OTP verification code was sent to the registered wallet phone number"
        };
        break;

      case 'qicard':
        gatewayDetails = {
          provider: "Qi Card (International Smart Card - ISC)",
          authCode: `QI-${Math.floor(100000 + Math.random() * 900000)}`,
          network: "National Iraqi Switch / Qi Mastercard",
          step: "awaiting_card_auth",
          smsInstructionAr: "سيتم خصم المبلغ من بطاقة كي كارد أو محفظة خدماتي",
          smsInstructionEn: "Amount will be deducted from Qi Card or Khadamaty wallet"
        };
        break;

      case 'fib':
        gatewayDetails = {
          provider: "First Iraqi Bank (مصرف العراق الأول)",
          qrPayload: `fib://pay?account=FIB-SCH-${timestamp}&amount=${totalPayableIQD}&ref=${transactionId}`,
          readableRef: `FIB-REF-${Math.floor(100000 + Math.random() * 900000)}`,
          step: "awaiting_qr_scan",
          smsInstructionAr: "افتح تطبيق مصرف العراق الأول (FIB) وامسح رمز QR لإتمام الدفع بلحظات",
          smsInstructionEn: "Open your FIB Mobile app and scan the QR code to approve payment in seconds"
        };
        break;

      case 'asiapay':
        gatewayDetails = {
          provider: "AsiaPay / FastPay (آسيا سيل)",
          walletPrefix: "077",
          referenceCode: `AP-${Math.floor(100000 + Math.random() * 900000)}`,
          step: "awaiting_pin",
          smsInstructionAr: "أدخل رقم الهاتف ورمز PIN الخاص بمحفظة آسيا باي",
          smsInstructionEn: "Enter your phone number and AsiaPay wallet PIN"
        };
        break;

      default:
        throw new Error(`Unsupported Iraqi payment gateway: ${gateway}`);
    }

    return {
      success: true,
      transactionId,
      gateway,
      amountIQD,
      gatewayFee,
      totalPayableIQD,
      invoiceNumber,
      studentName,
      studentId,
      schoolName,
      guardianPhone,
      status: "pending",
      createdAt: new Date().toISOString(),
      gatewayDetails
    };
  }

  /**
   * Finalize and confirm the payment
   */
  static async confirmPayment({ transactionId, gateway, pinOrOtp, cardDetails, phoneNumber }) {
    // In real life or sandbox this validates the OTP / webhook callback from ZainCash / FIB / Qi Card
    const receiptNumber = `REC-IRQ-${Date.now().toString().slice(-8)}`;
    const paidDate = new Date().toISOString().split('T')[0];
    const paidTime = new Date().toLocaleTimeString('ar-IQ');

    return {
      success: true,
      status: "completed",
      transactionId,
      receiptNumber,
      gateway,
      paidDate,
      paidTime,
      paymentSummaryAr: `تمت عملية الدفع بنجاح عبر بوابة ${gateway.toUpperCase()}`,
      paymentSummaryEn: `Payment successfully processed via ${gateway.toUpperCase()}`
    };
  }
}
