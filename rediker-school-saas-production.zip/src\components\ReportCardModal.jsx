import React from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { X, Printer, Award, ShieldCheck, CheckCircle2 } from 'lucide-react';

export function ReportCardModal({ student, grades = [], onClose }) {
  const { currentSchool } = useSchool();
  const { t, lang } = useLanguage();

  if (!student) return null;

  // Filter student grades
  const studentGrades = grades.filter(g => g.studentId === student.studentId || g.studentNameAr === student.fullNameAr);
  
  // Calculate GPA and Average
  const totalScoreSum = studentGrades.reduce((acc, curr) => acc + (curr.totalScore || 0), 0);
  const averagePercentage = studentGrades.length > 0 ? (totalScoreSum / studentGrades.length).toFixed(1) : student.gpa || 95.0;
  
  let overallEvaluation = "ناجح بتفوق - ممتاز";
  if (averagePercentage < 60) overallEvaluation = "مكمل / دور ثانٍ";
  else if (averagePercentage < 75) overallEvaluation = "ناجح - جيد";
  else if (averagePercentage < 85) overallEvaluation = "ناجح - جيد جداً";

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Actions bar (hidden in print) */}
        <div className="p-4 bg-slate-100 border-b border-slate-200 flex items-center justify-between no-print">
          <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
            <Award className="w-4 h-4 text-emerald-600" />
            معاينة الشهادة المدرسية الرسمية (Rediker TeacherPlus Transcript)
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-900 text-white hover:bg-slate-800 flex items-center gap-2 shadow-xs"
            >
              <Printer className="w-4 h-4" />
              <span>{t('print')} الشهادة</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-500 hover:bg-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Official Certificate */}
        <div className="p-8 sm:p-12 space-y-6 text-slate-800 bg-white" id="printable-report-card">
          
          {/* Header */}
          <div className="flex items-center justify-between border-b-2 pb-6" style={{ borderColor: currentSchool.theme?.primary || '#0F766E' }}>
            <div>
              <p className="text-xs font-bold text-slate-500">جمهورية العراق - وزارة التربية</p>
              <p className="text-xs font-bold text-slate-500">المديرية العامة للتعليم الأهلي والأجنبي</p>
              <h2 className="text-xl font-black text-slate-900 mt-1">{currentSchool.nameAr}</h2>
              <p className="text-xs text-slate-500">{currentSchool.mottoAr}</p>
            </div>
            <div className="text-center">
              <img 
                src={currentSchool.logo} 
                alt="Logo" 
                className="w-20 h-20 rounded-2xl object-cover ring-2 ring-slate-100 shadow-sm mx-auto"
              />
              <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block mt-1">
                وثيقة رسمية معتمدة
              </span>
            </div>
          </div>

          {/* Title */}
          <div className="text-center py-2">
            <h3 className="text-lg font-black text-slate-900 tracking-wide uppercase">
              وثيقة الدرجات والشهادة المدرسية الرسمية
            </h3>
            <p className="text-xs text-slate-500">
              العام الدراسي 2025 - 2026 • الفصل الدراسي الأول
            </p>
          </div>

          {/* Student Meta Details Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs">
            <div>
              <p className="text-slate-500 font-medium">اسم الطالب الرباعي:</p>
              <p className="font-bold text-slate-900 mt-0.5">{student.fullNameAr}</p>
            </div>
            <div>
              <p className="text-slate-500 font-medium">رقم القيد المدرسي:</p>
              <p className="font-bold font-mono text-slate-800 mt-0.5">{student.studentId}</p>
            </div>
            <div>
              <p className="text-slate-500 font-medium">المرحلة الدراسية:</p>
              <p className="font-bold text-slate-800 mt-0.5">{student.gradeLevel}</p>
            </div>
            <div>
              <p className="text-slate-500 font-medium">الشعبة:</p>
              <p className="font-bold text-slate-800 mt-0.5">{student.section}</p>
            </div>
          </div>

          {/* Academic Grades Table */}
          <div className="border border-slate-200 rounded-2xl overflow-hidden text-xs">
            <table className="w-full text-start">
              <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="p-3 text-start">المادة الدراسية</th>
                  <th className="p-3 text-center">النشاط (20)</th>
                  <th className="p-3 text-center">نصف السنة (30)</th>
                  <th className="p-3 text-center">الشفهي (10)</th>
                  <th className="p-3 text-center">النهائي (40)</th>
                  <th className="p-3 text-center">المجموع (100)</th>
                  <th className="p-3 text-center">التقدير</th>
                  <th className="p-3 text-center">النتيجة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {studentGrades.length > 0 ? (
                  studentGrades.map((g, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="p-3 font-bold text-slate-800">{g.subjectNameAr}</td>
                      <td className="p-3 text-center text-slate-600">{g.dailyActivities}</td>
                      <td className="p-3 text-center text-slate-600">{g.midtermExam}</td>
                      <td className="p-3 text-center text-slate-600">{g.quizzes}</td>
                      <td className="p-3 text-center text-slate-600">{g.finalExam}</td>
                      <td className="p-3 text-center font-bold text-slate-900">{g.totalScore}</td>
                      <td className="p-3 text-center font-bold text-emerald-700">{g.letterGrade}</td>
                      <td className="p-3 text-center font-bold text-emerald-800">{g.status}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={8} className="p-6 text-center text-slate-400">
                      لم يتم رصد درجات لهذا الطالب بعد
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Summary Banner */}
          <div 
            className="p-4 rounded-2xl text-white flex items-center justify-between"
            style={{ backgroundColor: currentSchool.theme?.primary || '#0F766E' }}
          >
            <div>
              <p className="text-xs text-white/80">المعدل العام للطالب:</p>
              <h4 className="text-2xl font-black mt-0.5">{averagePercentage}%</h4>
            </div>
            <div className="text-end text-xs space-y-1">
              <p className="font-bold text-white bg-white/20 px-3 py-1 rounded-full inline-block">
                التقييم العام: {overallEvaluation}
              </p>
              <p className="text-white/80">نسبة الانضباط والحضور: {student.attendanceRate || 98}%</p>
            </div>
          </div>

          {/* Official Signatures & Seal */}
          <div className="pt-10 grid grid-cols-3 gap-4 text-center text-xs">
            <div className="space-y-10">
              <p className="font-bold text-slate-700">توقيع مرشد / مربي الصف</p>
              <div className="w-28 border-b border-slate-400 mx-auto" />
            </div>
            <div className="space-y-3">
              <p className="font-bold text-slate-700">الختم الرسمي للمدرسة</p>
              <div className="w-20 h-20 border-2 border-dashed border-emerald-700 rounded-full mx-auto flex items-center justify-center text-[9px] text-emerald-900 font-bold transform -rotate-12">
                وزارة التربية<br/>{currentSchool.nameAr?.slice(0, 10)}
              </div>
            </div>
            <div className="space-y-10">
              <p className="font-bold text-slate-700">توقيع مدير المدرسة</p>
              <div className="w-28 border-b border-slate-400 mx-auto" />
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
