import Papa from 'papaparse';
import { CSV_TEMPLATES } from '../../server/services/csvHandler';

/**
 * Triggers a client-side download of a UTF-8 CSV file
 */
export function downloadCsvFile(filename, csvString) {
  // Ensure UTF-8 BOM is present for Excel on Windows
  const bom = '\uFEFF';
  const content = csvString.startsWith(bom) ? csvString : bom + csvString;
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Export arbitrary dataset to CSV and download
 */
export function exportDataToCsv(data, filename = 'school-data.csv') {
  if (!data || data.length === 0) return;
  const csv = Papa.unparse(data);
  downloadCsvFile(filename, csv);
}

/**
 * Download sample CSV template for a specific school module
 */
export function downloadSectionTemplate(section, lang = 'ar') {
  const template = CSV_TEMPLATES[section];
  if (!template) return;

  const headers = lang === 'ar' ? template.headersAr : template.headersEn;
  const sampleRows = template.sampleRowsAr || [];
  const rows = [headers, ...sampleRows];
  const csv = Papa.unparse(rows);
  downloadCsvFile(`template-${section}-${lang}.csv`, csv);
}

/**
 * Parse a user uploaded File object (from input[type=file])
 */
export function parseUploadedCsvFile(file) {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: true,
      encoding: 'UTF-8',
      complete: (results) => {
        resolve({
          data: results.data,
          meta: results.meta,
          errors: results.errors
        });
      },
      error: (error) => {
        reject(error);
      }
    });
  });
}
