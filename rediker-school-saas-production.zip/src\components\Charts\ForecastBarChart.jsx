import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext';

export default function ForecastBarChart({ data = [], height = 220 }) {
  const { formatNumber, formatDate, t } = useLanguage();
  const [hoverItem, setHoverItem] = useState(null);

  if (!data || data.length === 0) return null;

  const maxVal = Math.max(...data.map(d => Math.max(d.projected, d.baseline))) * 1.15 || 100;

  return (
    <div className="w-full flex flex-col gap-2">
      {/* Legend & Hover Info */}
      <div className="flex flex-wrap items-center justify-between text-xs px-1 gap-2">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#111111]" />
            <span className="text-[#343434]">{t('projectedDemand')}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-[#DFDFDF]" />
            <span className="text-[#898989]">{t('historicalVelocity')}</span>
          </div>
        </div>
        {hoverItem ? (
          <div className="font-medium text-xs text-[#111111] bg-white px-2.5 py-0.5 rounded-full border border-[#DFDFDF] shadow-xs">
            {formatDate(hoverItem.date)}: <span className="font-bold text-[#FF9000]">{formatNumber(hoverItem.projected)}</span> {t('units')}
          </div>
        ) : (
          <span className="text-[11px] text-[#898989]">30-Day Window</span>
        )}
      </div>

      {/* Bars Chart Area */}
      <div className="relative w-full rounded-xl bg-[#EBEBED]/60 p-3 border border-[#DFDFDF]/60">
        <div className="flex items-end justify-between gap-1 h-44 pt-4 pb-2" style={{ height }}>
          {data.slice(0, 30).map((d, i) => {
            const projHeight = (d.projected / maxVal) * 100;
            const baseHeight = (d.baseline / maxVal) * 100;

            return (
              <div
                key={i}
                className="flex-1 flex items-end justify-center gap-0.5 h-full group relative cursor-pointer"
                onMouseEnter={() => setHoverItem(d)}
                onMouseLeave={() => setHoverItem(null)}
              >
                {/* Baseline bar */}
                <div
                  className="w-1/2 bg-[#DFDFDF] rounded-t-sm transition-all duration-150 group-hover:bg-[#C8C8CC]"
                  style={{ height: `${baseHeight}%` }}
                />
                {/* Projected bar */}
                <div
                  className="w-1/2 bg-[#111111] rounded-t-sm transition-all duration-150 group-hover:bg-[#FF9000]"
                  style={{ height: `${projHeight}%` }}
                />
              </div>
            );
          })}
        </div>

        {/* X-axis indicators */}
        <div className="flex justify-between items-center text-[10px] text-[#898989] pt-2 border-t border-[#DFDFDF]/60 px-1">
          <span>Day 1</span>
          <span>Day 10</span>
          <span>Day 20</span>
          <span>Day 30</span>
        </div>
      </div>
    </div>
  );
}
