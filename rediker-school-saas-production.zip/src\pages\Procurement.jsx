import React, { useState, useMemo } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useApp } from '../context/AppContext';
import {
  ShoppingCart,
  Search,
  Plus,
  CheckCircle2,
  Clock,
  Check,
  X,
  Truck,
  Sparkles
} from 'lucide-react';

export default function Procurement() {
  const { t, isRtl, formatCurrency, formatNumber, formatDate } = useLanguage();
  const {
    purchaseOrders,
    productMap,
    supplierMap,
    updatePOStatus,
    setNewPOModalOpen,
    addToast
  } = useApp();

  const [selectedStatus, setSelectedStatus] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const statusFilters = ['All', 'suggested', 'pending_approval', 'approved', 'ordered', 'received', 'cancelled'];

  const filteredOrders = useMemo(() => {
    return purchaseOrders.filter(po => {
      if (selectedStatus !== 'All' && po.status !== selectedStatus) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const prod = productMap[po.product_id];
        const sup = supplierMap[po.supplier_id];
        const matchPO = (po.po_number || '').toLowerCase().includes(q);
        const matchProd = (prod?.name || '').toLowerCase().includes(q) || (prod?.nameAr || '').toLowerCase().includes(q);
        const matchSup = (sup?.name || '').toLowerCase().includes(q) || (sup?.nameAr || '').toLowerCase().includes(q);
        if (!matchPO && !matchProd && !matchSup) return false;
      }
      return true;
    });
  }, [purchaseOrders, selectedStatus, searchQuery, productMap, supplierMap]);

  const handleStatusTransition = (poId, nextStatus) => {
    updatePOStatus(poId, nextStatus);
    addToast(t('toastStatusUpdated'), 'success');
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'suggested':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#FF9000]/15 text-[#B86800] border border-[#FF9000]/30 inline-flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            {t('statusSuggested')}
          </span>
        );
      case 'pending_approval':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/15 text-amber-700 border border-amber-500/30 inline-flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {t('statusPending')}
          </span>
        );
      case 'approved':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#10B981]/15 text-[#059669] border border-[#10B981]/30 inline-flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            {t('statusApproved')}
          </span>
        );
      case 'ordered':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-blue-500/15 text-blue-700 border border-blue-500/30 inline-flex items-center gap-1">
            <Truck className="w-3 h-3" />
            {t('statusOrdered')}
          </span>
        );
      case 'received':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/15 text-emerald-700 border border-emerald-500/30 inline-flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            {t('statusReceived')}
          </span>
        );
      case 'cancelled':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-medium bg-red-100 text-red-600">
            {t('statusCancelled')}
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-medium bg-gray-100 text-gray-700">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-24 flex flex-col gap-6">
      {/* Header & Create PO Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-4 h-4 rounded-full bg-[#111111]" />
            <h1 className="font-semibold text-lg text-[#111111]">
              {t('procurementTitle')}
            </h1>
            <span className="text-xs text-[#898989]">
              ({purchaseOrders.length} {t('ordersCount')})
            </span>
          </div>
        </div>

        <button
          onClick={() => setNewPOModalOpen(true)}
          className="flex items-center gap-2 h-9 px-4 rounded-full bg-[#FF9000] hover:bg-[#111111] text-[#111111] hover:text-white transition-all text-xs font-semibold self-start sm:self-auto shadow-sm"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{t('createPO')}</span>
        </button>
      </div>

      {/* Filter Tabs & Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-[#DFDFDF]">
        {/* Status Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 md:pb-0">
          {statusFilters.map(st => {
            const isSel = selectedStatus === st;
            return (
              <button
                key={st}
                onClick={() => setSelectedStatus(st)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all shrink-0 capitalize ${
                  isSel
                    ? 'bg-[#111111] text-white shadow-xs'
                    : 'text-[#898989] hover:text-[#111111] hover:bg-[#F3F3F5]'
                }`}
              >
                {st === 'All' ? t('allCategories') : t(`status${st.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join('')}`)}
              </button>
            );
          })}
        </div>

        {/* Search */}
        <div className="relative w-full md:w-64">
          <input
            type="text"
            placeholder={t('searchPlaceholder')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-8 pl-8 pr-3 text-xs bg-[#F3F3F5] rounded-full border border-[#DFDFDF] focus:outline-none focus:border-[#111111]"
            style={{
              paddingLeft: isRtl ? '12px' : '30px',
              paddingRight: isRtl ? '30px' : '12px'
            }}
          />
          <Search className={`w-3.5 h-3.5 text-[#898989] absolute top-2.5 ${isRtl ? 'right-2.5' : 'left-2.5'}`} />
        </div>
      </div>

      {/* Purchase Orders Table */}
      <div className="bg-white rounded-3xl border border-[#DFDFDF] shadow-card-subtle overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            <thead className="bg-[#EBEBED]/60 border-b border-[#DFDFDF] text-[#898989] font-medium">
              <tr>
                <th className="py-3 px-4">{t('colPONumber')}</th>
                <th className="py-3 px-3">{t('colProduct')}</th>
                <th className="py-3 px-3">{t('colSupplier')}</th>
                <th className="py-3 px-3">{t('colQuantity')}</th>
                <th className="py-3 px-3">{t('colTotalCost')}</th>
                <th className="py-3 px-3">{t('colExpectedDelivery')}</th>
                <th className="py-3 px-3">{t('colStatus')}</th>
                <th className="py-3 px-4 text-center">{t('colActions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#DFDFDF]/70 text-[#111111]">
              {filteredOrders.map(po => {
                const prod = productMap[po.product_id];
                const sup = supplierMap[po.supplier_id];

                return (
                  <tr key={po.id} className="hover:bg-[#F8F8FA] transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-xs text-[#111111]">
                      {po.po_number}
                    </td>

                    <td className="py-3.5 px-3">
                      <div className="flex items-center gap-2">
                        {prod && (
                          <img
                            src={prod.image_url}
                            alt=""
                            className="w-7 h-7 rounded-lg object-cover border border-[#DFDFDF] shrink-0"
                          />
                        )}
                        <div>
                          <span className="font-semibold text-xs block text-[#111111]">
                            {prod ? (isRtl ? (prod.nameAr || prod.name) : prod.name) : '—'}
                          </span>
                          <span className="font-mono text-[10px] text-[#898989]">
                            {prod?.sku}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-3 text-[#343434]">
                      {sup ? (isRtl ? (sup.nameAr || sup.name) : sup.name) : '—'}
                    </td>

                    <td className="py-3.5 px-3 font-semibold text-[#111111]">
                      {formatNumber(po.quantity)} {t('units')}
                    </td>

                    <td className="py-3.5 px-3 font-bold text-[#111111]">
                      {formatCurrency(po.total_cost)}
                    </td>

                    <td className="py-3.5 px-3 text-[#898989]">
                      {formatDate(po.expected_delivery || po.created_date)}
                    </td>

                    <td className="py-3.5 px-3">
                      {getStatusBadge(po.status)}
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        {/* Status transition action buttons */}
                        {po.status === 'suggested' && (
                          <button
                            onClick={() => handleStatusTransition(po.id, 'approved')}
                            className="px-2.5 py-1 rounded-full bg-[#111111] hover:bg-[#10B981] text-white text-[11px] font-semibold transition-colors"
                          >
                            {t('approvePO')}
                          </button>
                        )}

                        {po.status === 'pending_approval' && (
                          <button
                            onClick={() => handleStatusTransition(po.id, 'approved')}
                            className="px-2.5 py-1 rounded-full bg-[#10B981] hover:bg-[#059669] text-white text-[11px] font-semibold transition-colors"
                          >
                            {t('statusApproved')}
                          </button>
                        )}

                        {po.status === 'approved' && (
                          <button
                            onClick={() => handleStatusTransition(po.id, 'ordered')}
                            className="px-2.5 py-1 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold transition-colors"
                          >
                            {t('markOrdered')}
                          </button>
                        )}

                        {po.status === 'ordered' && (
                          <button
                            onClick={() => handleStatusTransition(po.id, 'received')}
                            className="px-2.5 py-1 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-semibold transition-colors"
                          >
                            {t('markReceived')}
                          </button>
                        )}

                        {!['received', 'cancelled'].includes(po.status) && (
                          <button
                            onClick={() => handleStatusTransition(po.id, 'cancelled')}
                            className="p-1 rounded-full hover:bg-red-50 text-[#898989] hover:text-[#F24E2C] transition-colors"
                            title={t('cancelOrder')}
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredOrders.length === 0 && (
          <div className="py-12 text-center text-xs text-[#898989]">
            {t('noOrdersFound')}
          </div>
        )}
      </div>
    </div>
  );
}
