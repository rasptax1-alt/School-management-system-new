import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useApp } from '../context/AppContext';
import { X, Building2 } from 'lucide-react';

export default function NewSupplierModal({ isOpen, onClose }) {
  const { t } = useLanguage();
  const { addSupplier, addToast } = useApp();

  const [formData, setFormData] = useState({
    name: '',
    nameAr: '',
    contact_name: '',
    email: '',
    phone: '',
    location: '',
    default_lead_time_days: 7,
    reliability_score: 95,
    payment_terms: 'Net 30',
    notes: ''
  });

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    addSupplier({
      ...formData,
      nameAr: formData.nameAr || formData.name
    });

    addToast(t('toastSupplierCreated'), 'success');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
      <div
        className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-[#DFDFDF] max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-4 border-b border-[#DFDFDF]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#111111] text-[#FF9000] flex items-center justify-center">
              <Building2 className="w-4 h-4" />
            </div>
            <h2 className="font-semibold text-base text-[#111111]">
              {t('modalNewSupplierTitle')}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-[#F3F3F5] text-[#898989] hover:text-[#111111] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 flex flex-col gap-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('colSupplierName')} (EN) *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Apex Technologies"
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              />
            </div>

            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('colSupplierName')} (AR)
              </label>
              <input
                type="text"
                value={formData.nameAr}
                onChange={(e) => setFormData({ ...formData, nameAr: e.target.value })}
                placeholder="أبيكس للتقنيات"
                dir="rtl"
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs font-arabic"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldContactName')}
              </label>
              <input
                type="text"
                value={formData.contact_name}
                onChange={(e) => setFormData({ ...formData, contact_name: e.target.value })}
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              />
            </div>

            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldEmail')}
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldPhone')}
              </label>
              <input
                type="text"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              />
            </div>

            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldLocation')}
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="Riyadh / Frankfurt"
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldLeadTimeDays')}
              </label>
              <input
                type="number"
                min="1"
                value={formData.default_lead_time_days}
                onChange={(e) => setFormData({ ...formData, default_lead_time_days: Number(e.target.value) })}
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              />
            </div>

            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldReliability')}
              </label>
              <input
                type="number"
                min="50"
                max="100"
                value={formData.reliability_score}
                onChange={(e) => setFormData({ ...formData, reliability_score: Number(e.target.value) })}
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              />
            </div>

            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldPaymentTerms')}
              </label>
              <select
                value={formData.payment_terms}
                onChange={(e) => setFormData({ ...formData, payment_terms: e.target.value })}
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              >
                <option value="Net 30">Net 30</option>
                <option value="Net 60">Net 60</option>
                <option value="Net 15">Net 15</option>
                <option value="Immediate">Immediate</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#DFDFDF]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-full border border-[#DFDFDF] hover:bg-[#F3F3F5] text-[#343434] transition-colors"
            >
              {t('btnCancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-full bg-[#111111] hover:bg-[#FF9000] text-white hover:text-[#111111] font-semibold transition-all"
            >
              {t('btnSave')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
