import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  BookOpen, 
  Calendar, 
  UploadCloud, 
  DownloadCloud, 
  Plus, 
  Users, 
  Clock, 
  X,
  Building 
} from 'lucide-react';
import { exportDataToCsv } from '../services/csvExportImport';

export function Classes({ onOpenCsvModal }) {
  const { currentSchool, classes, setClasses, showToast } = useSchool();
  const { t, lang, isRTL } = useLanguage();

  const [activeTab, setActiveTab] = useState('directory'); // directory or timetable
  const [showAddModal, setShowAddModal] = useState(false);

  // New Class Form State
  const [code, setCode] = useState('');
  const [nameAr, setNameAr] = useState('');
  const [gradeLevel, setGradeLevel] = useState('الرابع العلمي');
  const [section, setSection] = useState('أ');
  const [roomNumber, setRoomNumber] = useState('قاعة 101');
  const [homeroomTeacher, setHomeroomTeacher] = useState('د. حسين كريم العامري');
  const [maxCapacity, setMaxCapacity] = useState(35);

  const handleExportCsv = () => {
    const formatted = classes.map(c => ({
      "رمز_الصف": c.code,
      "اسم_الصف_عربي": c.nameAr,
      "اسم_الصف_انجليزي": c.nameEn,
      "المرحلة": c.gradeLevel,
      "الشعبة": c.section,
      "رقم_القاعة": c.roomNumber,
      "مربي_الصف": c.homeroomTeacher,
      "عدد_الطلاب": c.studentCount,
      "السعة_القصوى": c.maxCapacity
    }));

    exportDataToCsv(formatted, `classes-${currentSchool.code}.csv`);
    showToast(isRTL ? 'تم تصدير ملف الصفوف والجداول CSV بنجاح' : 'Classes CSV exported successfully');
  };

  const handleAddSubmit = (e) => {
    e.preventDefault();
    if (!nameAr) return;

    const newClass = {
      id: `cls-${Date.now()}`,
      schoolId: currentSchool.id,
      code: code || `G-${Math.floor(10 + Math.random() * 90)}`,
      nameAr,
      nameEn: nameAr,
      gradeLevel,
      section,
      roomNumber,
      homeroomTeacher,
      studentCount: 25,
      maxCapacity: Number(maxCapacity),
      academicTerm: "الفصل الدراسي الأول",
      weeklyPeriods: 35
    };

    setClasses(prev => [newClass, ...prev]);
    showToast(`تمت إضافة الصف: ${newClass.nameAr}`, 'success');
    setShowAddModal(false);

    setCode('');
    setNameAr('');
  };

  const primaryColor = currentSchool.theme?.primary || '#0F766E';

  // Sample weekly schedule grid (Sunday to Thursday)
  const scheduleDays = [
    { day: "الأحد", periods: ["الرياضيات (قاعة 101)", "اللغة العربية", "الفيزياء", "استراحة", "الكيمياء", "اللغة الإنجليزية"] },
    { day: "الاثنين", periods: ["اللغة الإنجليزية", "الرياضيات", "الأحياء", "استراحة", "التربية الإسلامية", "الحاسوب"] },
    { day: "الثلاثاء", periods: ["الفيزياء (مختبر)", "الكيمياء", "الرياضيات", "استراحة", "اللغة العربية", "التربية الفنية"] },
    { day: "الأربعاء", periods: ["الرياضيات", "اللغة الإنجليزية", "التاريخ والوطنية", "استراحة", "الفيزياء", "الأحياء"] },
    { day: "الخميس", periods: ["الكيمياء", "الرياضيات", "اللغة العربية", "استراحة", "الحاسوب والذكاء الاصطناعي", "نشاط رياضي"] }
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              {t('classes')} (Master Schedule)
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              الشعب الدراسية، توزيع القاعات والجدول الأسبوعي العام • {currentSchool.nameAr}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => onOpenCsvModal('classes')}
            className="px-3.5 py-2.5 rounded-xl border border-amber-200 bg-amber-50 text-amber-900 text-xs font-bold hover:bg-amber-100 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <UploadCloud className="w-4 h-4 text-amber-700" />
            <span>استيراد صفوف (CSV)</span>
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-800 text-xs font-bold hover:bg-slate-50 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <DownloadCloud className="w-4 h-4 text-slate-600" />
            <span>{t('exportCsv')}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 rounded-xl text-white text-xs font-bold shadow-md hover:opacity-95 transition-all flex items-center gap-1.5"
            style={{ backgroundColor: primaryColor }}
          >
            <Plus className="w-4 h-4" />
            <span>إضافة شعبة جديدة</span>
          </button>
        </div>
      </div>

      {/* Tabs Switcher: Directory / Master Timetable */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('directory')}
          className={`px-4 py-2 rounded-xl text-xs font-extrabold transition-colors ${
            activeTab === 'directory' 
              ? 'text-white shadow-sm' 
              : 'text-slate-600 hover:text-slate-900 bg-white'
          }`}
          style={activeTab === 'directory' ? { backgroundColor: primaryColor } : {}}
        >
          دليل الشعب والقاعات الدراسية ({classes.length})
        </button>
        <button
          onClick={() => setActiveTab('timetable')}
          className={`px-4 py-2 rounded-xl text-xs font-extrabold transition-colors ${
            activeTab === 'timetable' 
              ? 'text-white shadow-sm' 
              : 'text-slate-600 hover:text-slate-900 bg-white'
          }`}
          style={activeTab === 'timetable' ? { backgroundColor: primaryColor } : {}}
        >
          {t('timetableSchedule')}
        </button>
      </div>

      {activeTab === 'directory' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {classes.map(c => (
            <div 
              key={c.id} 
              className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-xs hover:shadow-md transition-all space-y-4"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-mono">
                    {c.code}
                  </span>
                  <h3 className="font-extrabold text-sm text-slate-900 mt-1">{c.nameAr}</h3>
                  <p className="text-xs text-slate-500">{c.gradeLevel} • شعبة {c.section}</p>
                </div>
                <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center font-bold text-xs">
                  {c.section}
                </div>
              </div>

              <div className="space-y-2 text-xs border-t border-slate-100 pt-3">
                <div className="flex justify-between text-slate-600">
                  <span>مربي الصف:</span>
                  <span className="font-bold text-slate-800">{c.homeroomTeacher}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>الموقع والقاعة:</span>
                  <span className="font-semibold text-slate-700">{c.roomNumber}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>عدد الطلاب / السعة:</span>
                  <span className="font-bold text-emerald-700">{c.studentCount} / {c.maxCapacity} مقعد</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'timetable' && (
        <div className="bg-white rounded-3xl border border-slate-200/90 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900">
                الجدول المدرسي الأسبوعي العام (الصف الرابع العلمي أ)
              </h3>
              <p className="text-xs text-slate-500">
                توقيت الحصص: من 08:00 صباحاً حتى 01:30 ظهراً • دوام حضوري كامل
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-start text-xs border border-slate-200 rounded-2xl overflow-hidden">
              <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="p-3 text-start">اليوم</th>
                  <th className="p-3 text-center">الحصة 1 (08:00)</th>
                  <th className="p-3 text-center">الحصة 2 (08:45)</th>
                  <th className="p-3 text-center">الحصة 3 (09:30)</th>
                  <th className="p-3 text-center bg-amber-50 text-amber-900">الاستراحة (10:15)</th>
                  <th className="p-3 text-center">الحصة 4 (10:45)</th>
                  <th className="p-3 text-center">الحصة 5 (11:30)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {scheduleDays.map((sd, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="p-3.5 font-extrabold text-slate-900 bg-slate-50/50">{sd.day}</td>
                    <td className="p-3.5 text-center font-bold text-slate-800">{sd.periods[0]}</td>
                    <td className="p-3.5 text-center font-medium text-slate-700">{sd.periods[1]}</td>
                    <td className="p-3.5 text-center font-medium text-slate-700">{sd.periods[2]}</td>
                    <td className="p-3.5 text-center font-bold bg-amber-50/50 text-amber-800">فرصة</td>
                    <td className="p-3.5 text-center font-medium text-slate-700">{sd.periods[4]}</td>
                    <td className="p-3.5 text-center font-medium text-slate-700">{sd.periods[5]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Class Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div 
              className="p-5 text-white flex items-center justify-between"
              style={{ backgroundColor: primaryColor }}
            >
              <h3 className="font-extrabold text-base">إضافة شعبة دراسية جديدة</h3>
              <button onClick={() => setShowAddModal(false)} className="text-white hover:opacity-80">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">اسم الصف والشعبة (عربي) *</label>
                <input 
                  type="text" 
                  required
                  value={nameAr}
                  onChange={(e) => setNameAr(e.target.value)}
                  placeholder="مثال: الصف الرابع العلمي - شعبة ج"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">المرحلة الدراسية</label>
                  <select 
                    value={gradeLevel}
                    onChange={(e) => setGradeLevel(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                  >
                    <option value="الرابع العلمي">الرابع العلمي</option>
                    <option value="الخامس العلمي">الخامس العلمي</option>
                    <option value="السادس العلمي">السادس العلمي</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">الشعبة</label>
                  <input 
                    type="text" 
                    value={section}
                    onChange={(e) => setSection(e.target.value)}
                    placeholder="ج"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">رقم القاعة</label>
                  <input 
                    type="text" 
                    value={roomNumber}
                    onChange={(e) => setRoomNumber(e.target.value)}
                    placeholder="قاعة 103"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">السعة القصوى</label>
                  <input 
                    type="number" 
                    value={maxCapacity}
                    onChange={(e) => setMaxCapacity(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 font-bold"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-white font-bold"
                  style={{ backgroundColor: primaryColor }}
                >
                  {t('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
