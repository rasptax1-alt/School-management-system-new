import React, { useState, useMemo } from 'react';
import { NavLink, useSearchParams } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useApp } from '../context/AppContext';
import {
  Package,
  Search,
  Plus,
  ArrowUpRight,
  Filter,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Clock
} from 'lucide-react';

export default function Products() {
  const { t, isRtl, formatCurrency, formatNumber } = useLanguage();
  const { products, supplierMap, setNewProductModalOpen, triggerQuickRestockModal } = useApp();
  const [searchParams, setSearchParams] = useSearchParams();

  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [selectedStatus, setSelectedStatus] = useState(searchParams.get('status') || 'All');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = useMemo(() => {
    return ['All', ...new Set(products.map(p => p.category))];
  }, [products]);

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = (p.name || '').toLowerCase().includes(q);
        const matchNameAr = (p.nameAr || '').toLowerCase().includes(q);
        const matchSKU = (p.sku || '').toLowerCase().includes(q);
        const matchCat = (p.category || '').toLowerCase().includes(q);
        if (!matchName && !matchNameAr && !matchSKU && !matchCat) return false;
      }

      // Status Filter
      if (selectedStatus === 'Active' && p.status !== 'active') return false;
      if (selectedStatus === 'Low Stock' && !(p.status === 'active' && p.current_stock > 0 && p.current_stock <= p.reorder_point)) return false;
      if (selectedStatus === 'Out of Stock' && !(p.status === 'active' && p.current_stock === 0)) return false;
      if (selectedStatus === 'Discontinued' && p.status !== 'discontinued') return false;

      // Category Filter
      if (selectedCategory !== 'All' && p.category !== selectedCategory) return false;

      return true;
    });
  }, [products, searchQuery, selectedStatus, selectedCategory]);

  const getStatusBadge = (prod) => {
    if (prod.status === 'discontinued') {
      return (
        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-medium bg-gray-200 text-gray-700">
          {t('statusDiscontinued')}
        </span>
      );
    }
    if (prod.current_stock === 0) {
      return (
        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#F24E2C]/15 text-[#F24E2C] border border-[#F24E2C]/30">
          {t('statusOutOfStock')}
        </span>
      );
    }
    if (prod.current_stock <= prod.reorder_point) {
      return (
        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#FF9000]/15 text-[#B86800] border border-[#FF9000]/30">
          {t('statusLowStock')}
        </span>
      );
    }
    return (
      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-medium bg-[#10B981]/15 text-[#059669] border border-[#10B981]/30">
        {t('statusActive')}
      </span>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-24 flex flex-col gap-6">
      {/* Header & New Product CTA */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-4 h-4 rounded-full bg-[#FF9000]" />
            <h1 className="font-semibold text-lg text-[#111111]">
              {t('productsTitle')}
            </h1>
            <span className="text-xs text-[#898989]">
              ({products.length} {t('productsCount')})
            </span>
          </div>
        </div>

        <button
          onClick={() => setNewProductModalOpen(true)}
          className="flex items-center gap-2 h-9 px-4 rounded-full bg-[#FF9000] hover:bg-[#111111] text-[#111111] hover:text-white transition-all text-xs font-semibold self-start sm:self-auto shadow-sm"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{t('newProduct')}</span>
        </button>
      </div>

      {/* Search & Filter Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-[#DFDFDF]">
        {/* Status Filter Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 md:pb-0">
          {['All', 'Active', 'Low Stock', 'Out of Stock', 'Discontinued'].map(st => {
            const isSel = selectedStatus === st;
            return (
              <button
                key={st}
                onClick={() => setSelectedStatus(st)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all shrink-0 ${
                  isSel
                    ? 'bg-[#111111] text-white shadow-xs'
                    : 'text-[#898989] hover:text-[#111111] hover:bg-[#F3F3F5]'
                }`}
              >
                {st === 'All' ? t('allCategories') : t(`status${st.replace(/\s/g, '')}`)}
              </button>
            );
          })}
        </div>

        {/* Search bar & Category dropdown */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1 sm:w-60">
            <input
              type="text"
              placeholder={t('searchPlaceholder')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-8 pl-8 pr-3 text-xs bg-[#F3F3F5] rounded-full border border-[#DFDFDF] focus:outline-none focus:border-[#111111]"
              style={{
                paddingLeft: isRtl ? '12px' : '30px',
                paddingRight: isRtl ? '30px' : '12px'
              }}
            />
            <Search className={`w-3.5 h-3.5 text-[#898989] absolute top-2.5 ${isRtl ? 'right-2.5' : 'left-2.5'}`} />
          </div>

          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="h-8 px-3 text-xs bg-[#F3F3F5] rounded-full border border-[#DFDFDF] text-[#343434] focus:outline-none focus:border-[#111111]"
          >
            {categories.map(c => (
              <option key={c} value={c}>
                {c === 'All' ? t('allCategories') : c}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-3xl border border-[#DFDFDF] shadow-card-subtle overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            <thead className="bg-[#EBEBED]/60 border-b border-[#DFDFDF] text-[#898989] font-medium">
              <tr>
                <th className="py-3 px-4">{t('colProduct')}</th>
                <th className="py-3 px-3">{t('colSKU')}</th>
                <th className="py-3 px-3">{t('colCategory')}</th>
                <th className="py-3 px-3">{t('colStock')}</th>
                <th className="py-3 px-3">{t('colVelocity')}</th>
                <th className="py-3 px-3">{t('colUnitCost')}</th>
                <th className="py-3 px-3">{t('colPrice')}</th>
                <th className="py-3 px-3">{t('colSupplier')}</th>
                <th className="py-3 px-3">{t('colStatus')}</th>
                <th className="py-3 px-4 text-center">{t('colActions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#DFDFDF]/70 text-[#111111]">
              {filteredProducts.map(prod => {
                const sup = supplierMap[prod.supplier_id];
                const stockPct = Math.min(100, (prod.current_stock / (prod.reorder_point * 2.5)) * 100);

                return (
                  <tr key={prod.id} className="hover:bg-[#F8F8FA] transition-colors group">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={prod.image_url}
                          alt={prod.name}
                          className="w-9 h-9 rounded-xl object-cover border border-[#DFDFDF] shrink-0"
                        />
                        <div className="min-w-0">
                          <NavLink
                            to={`/products/${prod.id}`}
                            className="font-medium text-xs text-[#111111] hover:text-[#FF9000] truncate block transition-colors"
                          >
                            {isRtl ? (prod.nameAr || prod.name) : prod.name}
                          </NavLink>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-3 font-mono text-[11px] text-[#898989]">
                      {prod.sku}
                    </td>

                    <td className="py-3 px-3 text-[#343434]">
                      {isRtl ? (prod.categoryAr || prod.category) : prod.category}
                    </td>

                    <td className="py-3 px-3">
                      <div className="flex flex-col gap-1 w-24">
                        <div className="flex justify-between text-[11px]">
                          <span className="font-semibold">{formatNumber(prod.current_stock)}</span>
                          <span className="text-[#898989]">/ {prod.reorder_point}</span>
                        </div>
                        <div className="w-full h-1.5 bg-[#DFDFDF] rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              prod.current_stock === 0
                                ? 'bg-[#F24E2C]'
                                : prod.current_stock <= prod.reorder_point
                                ? 'bg-[#FF9000]'
                                : 'bg-[#10B981]'
                            }`}
                            style={{ width: `${stockPct}%` }}
                          />
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-3 font-medium text-[#343434]">
                      {prod.daily_sales_velocity} {t('perDay')}
                    </td>

                    <td className="py-3 px-3 font-semibold text-[#111111]">
                      {formatCurrency(prod.unit_cost)}
                    </td>

                    <td className="py-3 px-3 text-[#898989]">
                      {formatCurrency(prod.selling_price)}
                    </td>

                    <td className="py-3 px-3">
                      <span className="text-[11px] text-[#343434] truncate max-w-[120px] block">
                        {sup ? (isRtl ? (sup.nameAr || sup.name) : sup.name) : '—'}
                      </span>
                    </td>

                    <td className="py-3 px-3">
                      {getStatusBadge(prod)}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <NavLink
                          to={`/products/${prod.id}`}
                          className="p-1.5 rounded-full hover:bg-[#EBEBED] text-[#898989] hover:text-[#111111] transition-colors"
                          title={t('viewDetails')}
                        >
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        </NavLink>

                        {prod.current_stock <= prod.reorder_point && (
                          <button
                            onClick={() => triggerQuickRestockModal(prod)}
                            className="px-2 py-1 rounded-full bg-[#111111] hover:bg-[#FF9000] text-white hover:text-[#111111] text-[10px] font-semibold transition-colors"
                          >
                            {t('orderNow')}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredProducts.length === 0 && (
          <div className="py-12 text-center text-xs text-[#898989]">
            {t('noProductsFound')}
          </div>
        )}
      </div>
    </div>
  );
}
