import React from 'react';
import { useSchool } from '../context/SchoolContext';
import { CheckCircle2, AlertCircle, Info } from 'lucide-react';

export function Toast() {
  const { notifications } = useSchool();

  if (!notifications || notifications.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 space-y-2 max-w-sm w-full pointer-events-none">
      {notifications.map((n) => (
        <div
          key={n.id}
          className={`p-4 rounded-2xl shadow-xl border flex items-center gap-3 backdrop-blur-md pointer-events-auto animate-in slide-in-from-bottom-5 duration-200 ${
            n.type === 'error'
              ? 'bg-rose-50/95 border-rose-200 text-rose-900'
              : n.type === 'info'
              ? 'bg-blue-50/95 border-blue-200 text-blue-900'
              : 'bg-emerald-50/95 border-emerald-200 text-emerald-950'
          }`}
        >
          {n.type === 'error' ? (
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          ) : n.type === 'info' ? (
            <Info className="w-5 h-5 text-blue-600 shrink-0" />
          ) : (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          )}
          <span className="text-xs font-bold leading-relaxed">{n.message}</span>
        </div>
      ))}
    </div>
  );
}
