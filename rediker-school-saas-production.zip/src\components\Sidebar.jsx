import React from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  LayoutDashboard, 
  GraduationCap, 
  Users, 
  BookOpen, 
  CalendarCheck, 
  Award, 
  CreditCard, 
  Building, 
  Palette, 
  FileSpreadsheet,
  ExternalLink,
  Sparkles
} from 'lucide-react';

export function Sidebar({ currentTab, setCurrentTab }) {
  const { currentSchool, students, invoices } = useSchool();
  const { t, isRTL, lang } = useLanguage();

  const navItems = [
    { id: 'dashboard', label: t('dashboard'), icon: LayoutDashboard },
    { id: 'students', label: t('students'), icon: GraduationCap, badge: students.length },
    { id: 'staff', label: t('staff'), icon: Users },
    { id: 'classes', label: t('classes'), icon: BookOpen },
    { id: 'attendance', label: t('attendance'), icon: CalendarCheck },
    { id: 'gradebook', label: t('gradebook'), icon: Award },
    { 
      id: 'billing', 
      label: t('billing'), 
      icon: CreditCard,
      badge: invoices.filter(i => i.status !== 'مدفوع بالكامل').length || null
    },
    { id: 'saasAdmin', label: t('saasAdmin'), icon: Building },
    { id: 'brandingTheme', label: t('brandingTheme'), icon: Palette },
    { id: 'bulkCenter', label: t('bulkCenter'), icon: FileSpreadsheet, highlight: true },
  ];

  const primaryColor = currentSchool.theme?.primary || '#0F766E';

  return (
    <aside 
      className="w-64 lg:w-72 bg-white border-r border-slate-200/90 flex flex-col justify-between shrink-0 min-h-[calc(100vh-5rem)]"
    >
      <div className="p-4 space-y-6">
        
        {/* Navigation list */}
        <nav className="space-y-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-semibold transition-all ${
                  isActive 
                    ? 'text-white shadow-sm' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80'
                } ${item.highlight && !isActive ? 'border border-dashed border-emerald-300 bg-emerald-50/40 text-emerald-800' : ''}`}
                style={isActive ? { backgroundColor: primaryColor } : {}}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                  <span>{item.label}</span>
                </div>

                {item.badge !== undefined && item.badge !== null && (
                  <span 
                    className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                      isActive 
                        ? 'bg-white/20 text-white' 
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Iraqi Payment Gateways Badge */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-50 to-emerald-50/50 border border-emerald-100 space-y-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <p className="text-xs font-bold text-slate-800">
              {lang === 'ar' ? 'بوابات الدفع العراقية المعتمدة' : 'Supported Iraqi Gateways'}
            </p>
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-white text-rose-700 border border-rose-200">
              زين كاش
            </span>
            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-white text-blue-800 border border-blue-200">
              كي كارد
            </span>
            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-white text-teal-800 border border-teal-200">
              FIB مصرف
            </span>
            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-white text-amber-800 border border-amber-200">
              آسيا باي
            </span>
          </div>
        </div>

      </div>

      {/* Footer / School Identity & SaaS Status */}
      <div className="p-4 border-t border-slate-100 bg-slate-50/50">
        <div className="flex items-center justify-between text-xs text-slate-500">
          <span className="font-medium">Rediker Architecture</span>
          <span className="font-bold text-emerald-700">v2.5 Iraq SIS</span>
        </div>
        <p className="text-[11px] text-slate-400 mt-1">
          {lang === 'ar' ? 'نظام متعدد المدارس يدعم استيراد وتصدير CSV الشامل' : 'Multi-school SaaS with Universal CSV'}
        </p>
      </div>
    </aside>
  );
}
