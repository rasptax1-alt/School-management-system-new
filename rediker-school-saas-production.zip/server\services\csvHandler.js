// Universal CSV Handler for Rediker-Style School Management System
// Includes UTF-8 BOM (\uFEFF) for perfect Arabic Excel compatibility
import Papa from 'papaparse';

export const CSV_TEMPLATES = {
  students: {
    headersAr: ["رقم_القيد", "الاسم_الرباعي_عربي", "الاسم_انجليزي", "الرقم_الوطني", "الجنس", "تاريخ_الميلاد", "المرحلة_الدراسية", "الشعبة", "اسم_ولي_الأمر", "هاتف_ولي_الأمر", "البريد_الإلكتروني", "العنوان", "فصيلة_الدم", "القسط_الكلي"],
    headersEn: ["studentId", "fullNameAr", "fullNameEn", "nationalId", "gender", "birthDate", "gradeLevel", "section", "guardianName", "guardianPhone", "guardianEmail", "address", "bloodType", "tuitionTotal"],
    sampleRowsAr: [
      ["STU-2026-101", "حيدر أحمد جاسم الحسني", "Haider Ahmed Jasim Al-Hasani", "199923847291", "ذكر", "2010-05-12", "الرابع العلمي", "أ", "أحمد جاسم الحسني", "07701234567", "ahmed@example.com", "بغداد - الكرخ", "O+", "2500000"],
      ["STU-2026-102", "سارة عادل محمود التميمي", "Sara Adil Mahmood Al-Tamimi", "200019283746", "أنثى", "2010-09-18", "الرابع العلمي", "أ", "عادل محمود التميمي", "07802345678", "adil@example.com", "بغداد - الرصافة", "A+", "2500000"]
    ]
  },
  staff: {
    headersAr: ["الرقم_الوظيفي", "الاسم_الرباعي_عربي", "الاسم_انجليزي", "المسمى_الوظيفي", "القسم", "البريد_الإلكتروني", "رقم_الهاتف", "المؤهل_العلمي", "الراتب_الشهري_دينار", "المواد_المعينة"],
    headersEn: ["staffId", "fullNameAr", "fullNameEn", "role", "department", "email", "phone", "qualification", "salaryIQD", "subjectsTaught"],
    sampleRowsAr: [
      ["TCH-301", "د. عمار فاضل الكرخي", "Dr. Ammar Fadhil Al-Karkhi", "أستاذ أول / رئيس قسم", "الرياضيات", "ammar@school.edu.iq", "07709988776", "دكتوراه رياضيات", "1800000", "الرياضيات المتقدمة"],
      ["TCH-302", "أ. نور خليل الجبوري", "Noor Khalil Al-Jubouri", "مدرسة لغة إنجليزية", "اللغة الإنجليزية", "noor@school.edu.iq", "07801122334", "ماجستير ترجمة", "1500000", "اللغة الإنجليزية"]
    ]
  },
  classes: {
    headersAr: ["رمز_الصف", "اسم_الصف_عربي", "اسم_الصف_انجليزي", "المرحلة", "الشعبة", "رقم_القاعة", "مربي_الصف", "السعة_القصوى"],
    headersEn: ["code", "nameAr", "nameEn", "gradeLevel", "section", "roomNumber", "homeroomTeacher", "maxCapacity"],
    sampleRowsAr: [
      ["G10-A", "الصف الرابع العلمي أ", "Grade 10 Science A", "الرابع العلمي", "أ", "قاعة 101", "د. حسين العامري", "35"],
      ["G10-B", "الصف الرابع العلمي ب", "Grade 10 Science B", "الرابع العلمي", "ب", "قاعة 102", "أ. حارث السامرائي", "35"]
    ]
  },
  grades: {
    headersAr: ["رقم_الطالب", "اسم_الطالب", "رمز_المادة", "المادة_عربي", "المادة_انجليزي", "الفصل", "النشاط_اليومي_20", "امتحان_شهري_30", "اختبارات_قصيرة_10", "الامتحان_النهائي_40", "المجموع_100", "التقدير"],
    headersEn: ["studentId", "studentNameAr", "classCode", "subjectNameAr", "subjectNameEn", "term", "dailyActivities", "midtermExam", "quizzes", "finalExam", "totalScore", "letterGrade"],
    sampleRowsAr: [
      ["STU-2026-001", "علي حيدر كاظم الزبيدي", "MATH-101", "الرياضيات", "Mathematics", "الفصل الأول", "19", "28", "10", "38", "95", "A+"],
      ["STU-2026-002", "فاطمة أحمد حسن العبيدي", "ARAB-101", "اللغة العربية", "Arabic", "الفصل الأول", "20", "29", "10", "40", "99", "A+"]
    ]
  },
  attendance: {
    headersAr: ["التاريخ", "رقم_الطالب", "اسم_الطالب", "رمز_الصف", "الحالة", "وقت_الحضور", "ملاحظات_الغياب"],
    headersEn: ["date", "studentId", "studentNameAr", "classCode", "status", "checkInTime", "notes"],
    sampleRowsAr: [
      ["2026-10-12", "STU-2026-001", "علي حيدر كاظم الزبيدي", "G10-SCI-A", "حاضر", "07:45 AM", ""],
      ["2026-10-12", "STU-2026-003", "محمد ياسر عبد الرزاق التميمي", "G11-SCI-B", "متأخر", "08:15 AM", "ازدحام مروري"]
    ]
  },
  invoices: {
    headersAr: ["رقم_الفاتورة", "رقم_الطالب", "اسم_الطالب", "المرحلة", "نوع_القسط", "المبلغ_الكلي_دينار", "المدفوع_دينار", "المتبقي_دينار", "تاريخ_الاستحقاق", "حالة_السداد", "بوابة_الدفع"],
    headersEn: ["invoiceNumber", "studentId", "studentNameAr", "gradeLevel", "feeCategory", "amountIQD", "paidAmountIQD", "remainingAmountIQD", "dueDate", "status", "paymentMethod"],
    sampleRowsAr: [
      ["INV-2026-1090", "STU-2026-001", "علي حيدر كاظم الزبيدي", "الرابع العلمي", "القسط الدراسي الشامل", "2500000", "2500000", "0", "2025-10-15", "مدفوع بالكامل", "ZainCash"],
      ["INV-2026-1091", "STU-2026-002", "فاطمة أحمد حسن العبيدي", "الرابع العلمي", "القسط الدراسي - دفعة 2", "2500000", "1500000", "1000000", "2026-01-15", "مدفوع جزئياً", "QiCard"]
    ]
  }
};

/**
 * Convert array of objects or 2D array to CSV string with UTF-8 BOM
 */
export function generateCsvString(data, lang = 'ar') {
  const csv = Papa.unparse(data);
  // Prepend UTF-8 BOM so Excel on Windows recognizes Arabic characters properly
  return '\uFEFF' + csv;
}

/**
 * Parse CSV text into array of objects with header mapping
 */
export function parseCsvString(csvString) {
  // Remove BOM if present
  let cleanString = csvString;
  if (cleanString.charCodeAt(0) === 0xFEFF) {
    cleanString = cleanString.slice(1);
  }

  const result = Papa.parse(cleanString, {
    header: true,
    skipEmptyLines: true,
    dynamicTyping: true
  });

  return result.data;
}
