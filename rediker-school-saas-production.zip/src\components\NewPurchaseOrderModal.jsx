import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useApp } from '../context/AppContext';
import { X, ShoppingCart } from 'lucide-react';

export default function NewPurchaseOrderModal({ isOpen, onClose }) {
  const { t, isRtl, formatCurrency } = useLanguage();
  const { products, suppliers, addPurchaseOrder, addToast, prefilledPOProduct, setPrefilledPOProduct } = useApp();

  const [formData, setFormData] = useState({
    product_id: '',
    supplier_id: '',
    quantity: 100,
    unit_cost: 0,
    expected_delivery: ''
  });

  useEffect(() => {
    if (prefilledPOProduct) {
      const defaultDelivery = new Date();
      defaultDelivery.setDate(defaultDelivery.getDate() + 14);
      setFormData({
        product_id: prefilledPOProduct.id,
        supplier_id: prefilledPOProduct.supplier_id || suppliers[0]?.id || '',
        quantity: Math.max(100, Math.round((prefilledPOProduct.daily_sales_velocity || 5) * 20)),
        unit_cost: prefilledPOProduct.unit_cost || 0,
        expected_delivery: defaultDelivery.toISOString().split('T')[0]
      });
    } else if (products.length > 0) {
      const defaultDelivery = new Date();
      defaultDelivery.setDate(defaultDelivery.getDate() + 14);
      setFormData({
        product_id: products[0].id,
        supplier_id: products[0].supplier_id || suppliers[0]?.id || '',
        quantity: 100,
        unit_cost: products[0].unit_cost || 0,
        expected_delivery: defaultDelivery.toISOString().split('T')[0]
      });
    }
  }, [prefilledPOProduct, products, suppliers]);

  if (!isOpen) return null;

  const handleProductChange = (e) => {
    const prodId = e.target.value;
    const selectedProd = products.find(p => p.id === prodId);
    setFormData(prev => ({
      ...prev,
      product_id: prodId,
      supplier_id: selectedProd?.supplier_id || prev.supplier_id,
      unit_cost: selectedProd?.unit_cost || prev.unit_cost
    }));
  };

  const totalCost = (Number(formData.quantity) || 0) * (Number(formData.unit_cost) || 0);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.product_id) return;

    addPurchaseOrder({
      ...formData,
      status: 'pending_approval'
    });

    addToast(t('toastPOCreated'), 'success');
    setPrefilledPOProduct(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
      <div
        className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-[#DFDFDF]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-4 border-b border-[#DFDFDF]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#111111] text-[#FF9000] flex items-center justify-center">
              <ShoppingCart className="w-4 h-4" />
            </div>
            <h2 className="font-semibold text-base text-[#111111]">
              {t('modalNewPOTitle')}
            </h2>
          </div>
          <button
            onClick={() => {
              setPrefilledPOProduct(null);
              onClose();
            }}
            className="p-1 rounded-full hover:bg-[#F3F3F5] text-[#898989] hover:text-[#111111] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 flex flex-col gap-4 text-xs">
          <div>
            <label className="block font-medium text-[#343434] mb-1">
              {t('colProduct')} *
            </label>
            <select
              value={formData.product_id}
              onChange={handleProductChange}
              className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
            >
              {products.map(p => (
                <option key={p.id} value={p.id}>
                  {p.sku} — {isRtl ? (p.nameAr || p.name) : p.name} (Stock: {p.current_stock})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-medium text-[#343434] mb-1">
              {t('fieldSupplier')} *
            </label>
            <select
              value={formData.supplier_id}
              onChange={(e) => setFormData({ ...formData, supplier_id: e.target.value })}
              className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
            >
              {suppliers.map(s => (
                <option key={s.id} value={s.id}>
                  {isRtl ? (s.nameAr || s.name) : s.name} ({s.default_lead_time_days} days lead)
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldQuantity')} *
              </label>
              <input
                type="number"
                min="1"
                required
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: Number(e.target.value) })}
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs font-semibold"
              />
            </div>

            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldUnitCost')} ($)
              </label>
              <input
                type="number"
                min="0"
                step="0.01"
                required
                value={formData.unit_cost}
                onChange={(e) => setFormData({ ...formData, unit_cost: Number(e.target.value) })}
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs font-semibold"
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-[#343434] mb-1">
              {t('fieldDeliveryDate')}
            </label>
            <input
              type="date"
              required
              value={formData.expected_delivery}
              onChange={(e) => setFormData({ ...formData, expected_delivery: e.target.value })}
              className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
            />
          </div>

          {/* Cost Summary Box */}
          <div className="p-3.5 rounded-2xl bg-[#EBEBED] flex items-center justify-between border border-[#DFDFDF]">
            <span className="text-[#343434] font-medium">{t('colTotalCost')}:</span>
            <span className="font-bold text-base text-[#111111]">
              {formatCurrency(totalCost)}
            </span>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#DFDFDF]">
            <button
              type="button"
              onClick={() => {
                setPrefilledPOProduct(null);
                onClose();
              }}
              className="px-4 py-2 rounded-full border border-[#DFDFDF] hover:bg-[#F3F3F5] text-[#343434] transition-colors"
            >
              {t('btnCancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-full bg-[#111111] hover:bg-[#FF9000] text-white hover:text-[#111111] font-semibold transition-all"
            >
              {t('btnCreate')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
