# 📚 دليل رفع ونشر منظومة ريديكر لإدارة المدارس على الدومين الخاص
### Rediker School Management SaaS - Production Deployment Guide

تم تجهيز هذا المشروع ليعمل فورياً إما كـ **Full-Stack Application متكامل (Frontend + Backend)** على خادم Node.js أو كـ **Static Application** على استضافات الويب العادية.

---

## 📦 محتويات الحزمة المضغوطة (Zip Package)
1. **مجلد `dist/`:** النسخة النهائية المترجمة والمبنية للواجهة الأمامية (جاهزة للرفع المباشر).
2. **مجلد `server/`:** الخادم الخلفي (Express API) المتكامل مع بوابات الدفع العراقية ونظام الـ Multi-Tenant والـ CSV.
3. **مجلد `src/`:** الكود المصدري الكامل للواجهة الأمامية.
4. **ملف `package.json`:** ملف التبعيات وأوامر التشغيل.
5. **ملفات الإعدادات:** `vite.config.js`, `tailwind.config.js`, `postcss.config.js`.

---

## 🚀 الخيار الأول: الرفع على استضافة cPanel تدعم Node.js (الأكثر شيوعاً)
مثل استضافات (Hostinger, Namecheap, A2Hosting, Bluehost وغيرها):

1. **رفع الحزمة:**
   - افتح **cPanel** واذهب إلى **File Manager (إدارة الملفات)**.
   - ارفع الملف المضغوط وفك ضغطه داخل المجلد المطلوب (مثلاً مجلد فرعي أو المجلد الرئيسي).

2. **إنشاء تطبيق Node.js:**
   - من لوحة cPanel، اختر **Setup Node.js App**.
   - اضغط **Create Application**.
   - اختر إصدار Node.js: **v18 أو v20 أو v22**.
   - في خانة **Application Root**: اكتب اسم المجلد الذي فككت الضغط فيه.
   - في خانة **Application URL**: اختر الدومين الخاص بك (مثلاً `school.yourdomain.com` أو `yourdomain.com`).
   - في خانة **Application Startup File**: اكتب:
     ```text
     server/index.js
     ```
   - اضغط **Create**.

3. **تثبيت الحزم وتشغيل التطبيق:**
   - اضغط على زر **Run NPM Install** في نفس الصفحة.
   - اضغط **Restart** لتشغيل التطبيق.
   - مبروك! التطبيق سيعمل الآن مباشرة على الدومين الخاص بك مع معالجة الـ API والـ Frontend معاً.

---

## 🖥️ الخيار الثاني: الرفع على خادم سحابي VPS (Ubuntu / Debian / Nginx)
إذا كان لديك سيرفر خاص (VPS من DigitalOcean, Hetzner, AWS, Linode):

1. **نقل الملفات وتثبيت التبعيات:**
   ```bash
   unzip rediker-school-saas-production.zip -d /var/www/school-app
   cd /var/www/school-app
   npm install --production
   ```

2. **تشغيل التطبيق في الخلفية عبر PM2:**
   ```bash
   sudo npm install -g pm2
   pm2 start server/index.js --name "school-saas"
   pm2 startup
   pm2 save
   ```

3. **إعداد سيرفر Nginx وربط الدومين:**
   أنشئ ملف إعداد Nginx عبر الأمر:
   `sudo nano /etc/nginx/sites-available/school.conf`
   
   ```nginx
   server {
       server_name yourdomain.com www.yourdomain.com;

       location / {
           proxy_pass http://localhost:5000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       }
   }
   ```
   تفعيل الموقع وشهادة SSL المجانية:
   ```bash
   sudo ln -s /etc/nginx/sites-available/school.conf /etc/nginx/sites-enabled/
   sudo nginx -t && sudo systemctl restart nginx
   sudo certbot --nginx -d yourdomain.com
   ```

---

## ⚡ الخيار الثالث: الرفع كـ Static Web على استضافة عادية (cPanel Public_html)
إذا أردت رفع الواجهة فقط على استضافة مشتركة لا تدعم Node.js:
1. ادخل إلى مجلد `dist/` الموجود في الحزمة.
2. حدد جميع الملفات الموجودة بداخله (`index.html` والمجلد `assets/`).
3. ارفعها مباشرة داخل مجلد `public_html` في استضافتك.
4. سيعمل التطبيق في المتصفح بكامل ميزاته (المعالجة المحلية والـ LocalStorage ومحاكاة البوابات العراقية وتصدير/استيراد الـ CSV).

---

## 🔐 إعدادات بوابات الدفع والبيئة (.env)
يمكنك إنشاء ملف `.env` بجانب `package.json` عند الرغبة في ربط مفاتيح الإنتاج الرسمية:
```env
PORT=5000
NODE_ENV=production

# ZainCash Production Keys (بوابة زين كاش)
ZAINCASH_MERCHANT_ID=your_merchant_id
ZAINCASH_SECRET=your_secret_key
ZAINCASH_MSISDN=0780xxxxxxx

# First Iraqi Bank (مصرف العراق الأول FIB)
FIB_CLIENT_ID=your_fib_client_id
FIB_CLIENT_SECRET=your_fib_client_secret

# Qi Card (كي كارد العالمية ISC)
QICARD_MERCHANT_KEY=your_qicard_key

# AsiaPay / FastPay
ASIAPAY_MERCHANT_KEY=your_asiapay_key
```

---
تم إعداد هذا الدليل لتسهيل إطلاق منصتك التعليمية بنجاح على أي دومين واستضافة!
