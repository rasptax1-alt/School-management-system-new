import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { Palette, Sparkles, Save, CheckCircle2, RefreshCw } from 'lucide-react';

export function BrandingTheme() {
  const { currentSchool, updateSchoolTheme, showToast } = useSchool();
  const { t, lang } = useLanguage();

  const [nameAr, setNameAr] = useState(currentSchool.nameAr);
  const [nameEn, setNameEn] = useState(currentSchool.nameEn);
  const [mottoAr, setMottoAr] = useState(currentSchool.mottoAr);
  const [logo, setLogo] = useState(currentSchool.logo);
  const [primary, setPrimary] = useState(currentSchool.theme?.primary || '#0F766E');
  const [secondary, setSecondary] = useState(currentSchool.theme?.secondary || '#D97706');
  const [accent, setAccent] = useState(currentSchool.theme?.accent || '#14B8A6');

  const presetThemes = [
    {
      id: "emerald",
      name: "الزمردي الملكي والذهبي (بغداد الأهلية)",
      primary: "#0F766E",
      secondary: "#D97706",
      accent: "#14B8A6"
    },
    {
      id: "navy",
      name: "الأزرق الملكي الدولي (الرافدين الأهلية)",
      primary: "#1E3A8A",
      secondary: "#BE123C",
      accent: "#38BDF8"
    },
    {
      id: "purple",
      name: "الأرجوان البابلي والكهرمان (بابل الحديثة)",
      primary: "#6B21A8",
      secondary: "#F59E0B",
      accent: "#C084FC"
    },
    {
      id: "slate",
      name: "الفحمي والتركواز (أكاديمية المتميزين)",
      primary: "#334155",
      secondary: "#0284C7",
      accent: "#10B981"
    }
  ];

  const handleApplyPreset = (preset) => {
    setPrimary(preset.primary);
    setSecondary(preset.secondary);
    setAccent(preset.accent);
  };

  const handleSave = () => {
    updateSchoolTheme(currentSchool.id, {
      nameAr,
      nameEn,
      mottoAr,
      logo,
      theme: {
        ...currentSchool.theme,
        primary,
        primaryHover: primary,
        secondary,
        accent,
        sidebarBg: primary
      }
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center">
            <Palette className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              {t('visualIdentityTitle')}
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {t('visualIdentitySubtitle')} • {currentSchool.nameAr}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleSave}
          className="px-5 py-2.5 rounded-xl text-white text-xs font-bold shadow-md hover:opacity-95 transition-all flex items-center gap-1.5"
          style={{ backgroundColor: primary }}
        >
          <Save className="w-4 h-4" />
          <span>{t('applyVisualIdentity')}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Settings Form */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs space-y-5">
          <div>
            <h3 className="font-extrabold text-sm text-slate-900 mb-3">
              {t('themePresets')}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {presetThemes.map(p => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => handleApplyPreset(p)}
                  className={`p-3.5 rounded-2xl border text-start transition-all ${
                    primary === p.primary 
                      ? 'border-slate-800 ring-2 ring-slate-800/20 bg-slate-50' 
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className="w-4 h-4 rounded-full" style={{ backgroundColor: p.primary }} />
                    <span className="w-4 h-4 rounded-full" style={{ backgroundColor: p.secondary }} />
                    <span className="w-4 h-4 rounded-full" style={{ backgroundColor: p.accent }} />
                  </div>
                  <p className="text-xs font-bold text-slate-800">{p.name}</p>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">{t('primaryColor')}</label>
              <div className="flex items-center gap-2 border border-slate-200 rounded-xl p-2 bg-slate-50">
                <input 
                  type="color" 
                  value={primary} 
                  onChange={(e) => setPrimary(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                />
                <span className="text-xs font-mono font-bold text-slate-700">{primary}</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">{t('secondaryColor')}</label>
              <div className="flex items-center gap-2 border border-slate-200 rounded-xl p-2 bg-slate-50">
                <input 
                  type="color" 
                  value={secondary} 
                  onChange={(e) => setSecondary(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                />
                <span className="text-xs font-mono font-bold text-slate-700">{secondary}</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">{t('accentColor')}</label>
              <div className="flex items-center gap-2 border border-slate-200 rounded-xl p-2 bg-slate-50">
                <input 
                  type="color" 
                  value={accent} 
                  onChange={(e) => setAccent(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                />
                <span className="text-xs font-mono font-bold text-slate-700">{accent}</span>
              </div>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">{t('schoolNameAr')}</label>
              <input 
                type="text" 
                value={nameAr} 
                onChange={(e) => setNameAr(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">{t('schoolNameEn')}</label>
              <input 
                type="text" 
                value={nameEn} 
                onChange={(e) => setNameEn(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">{t('schoolMottoAr')}</label>
              <input 
                type="text" 
                value={mottoAr} 
                onChange={(e) => setMottoAr(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">{t('schoolLogoUrl')}</label>
              <input 
                type="text" 
                value={logo} 
                onChange={(e) => setLogo(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-mono text-[11px]"
              />
            </div>
          </div>
        </div>

        {/* Live UI Preview Card */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs space-y-6">
          <h3 className="font-extrabold text-sm text-slate-900">
            معاينة حية للمظهر والترويسة
          </h3>

          <div 
            className="p-6 rounded-3xl text-white shadow-md space-y-4"
            style={{ backgroundColor: primary }}
          >
            <div className="flex items-center gap-3">
              <img src={logo} alt="" className="w-14 h-14 rounded-2xl object-cover ring-2 ring-white/20" />
              <div>
                <h4 className="text-lg font-black">{nameAr}</h4>
                <p className="text-xs text-white/80 font-medium">{mottoAr}</p>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-white text-slate-900">
                زر المعاينة 1
              </span>
              <span 
                className="px-3 py-1 rounded-full text-xs font-bold text-white"
                style={{ backgroundColor: secondary }}
              >
                زر ثانوي
              </span>
            </div>
          </div>

          <div className="border border-slate-200 p-5 rounded-3xl space-y-3 bg-slate-50">
            <span className="text-xs font-bold text-slate-500">وصل القبض المالي التجريبي</span>
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-800">قسط الطالب: علي حيدر الزبيدي</span>
              <span className="font-bold font-mono" style={{ color: primary }}>2,500,000 د.ع</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden">
              <div className="h-full rounded-full" style={{ width: '75%', backgroundColor: primary }} />
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
