import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  Building2, 
  Plus, 
  CheckCircle2, 
  ShieldCheck, 
  Sparkles, 
  ExternalLink, 
  Calendar, 
  Users, 
  Layers, 
  CreditCard,
  X 
} from 'lucide-react';

export function SaasAdmin({ onOpenThemeModal }) {
  const { 
    schools, 
    currentSchool, 
    switchSchool, 
    addNewSchool, 
    saasPlans, 
    allStudents, 
    showToast 
  } = useSchool();
  
  const { t, lang, isRTL } = useLanguage();

  const [showAddSchoolModal, setShowAddSchoolModal] = useState(false);
  const [nameAr, setNameAr] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [city, setCity] = useState('بغداد');
  const [district, setDistrict] = useState('الكرخ');
  const [phone, setPhone] = useState('07701234567');
  const [email, setEmail] = useState('info@school.iq');
  const [selectedPlanId, setSelectedPlanId] = useState('pro');

  const totalSaaSRevenue = schools.reduce((acc, s) => acc + (s.saasSubscription?.priceIQD || 3500000), 0);

  const handleCreateSchoolSubmit = (e) => {
    e.preventDefault();
    if (!nameAr) return;

    const plan = saasPlans.find(p => p.id === selectedPlanId) || saasPlans[1];

    addNewSchool({
      nameAr,
      nameEn: nameEn || nameAr,
      city,
      district,
      phone,
      email,
      planId: plan.id,
      planNameAr: plan.nameAr,
      logo: "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=150&auto=format&fit=crop&q=80"
    });

    setShowAddSchoolModal(false);
    setNameAr('');
    setNameEn('');
  };

  const primaryColor = currentSchool.theme?.primary || '#0F766E';

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              {t('saasTitle')}
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {t('saasSubtitle')}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowAddSchoolModal(true)}
          className="px-4 py-2.5 rounded-xl text-white text-xs font-bold shadow-md hover:opacity-95 transition-all flex items-center gap-1.5"
          style={{ backgroundColor: primaryColor }}
        >
          <Plus className="w-4 h-4" />
          <span>{t('addNewSchool')}</span>
        </button>
      </div>

      {/* Platform KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-xs">
          <span className="text-xs font-bold text-slate-500">{t('activeSchoolsCount')}</span>
          <p className="text-2xl font-black text-slate-900 mt-2">{schools.length} مدارس</p>
          <p className="text-[11px] text-slate-400 mt-1">مدارس نشطة على السحابة</p>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-xs">
          <span className="text-xs font-bold text-slate-500">{t('totalStudentsAcrossSchools')}</span>
          <p className="text-2xl font-black text-emerald-600 mt-2">{allStudents.length} طالب</p>
          <p className="text-[11px] text-slate-400 mt-1">سجلات بيانات معزولة لكل مدرسة</p>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-xs">
          <span className="text-xs font-bold text-slate-500">{t('saasRevenueTotal')}</span>
          <p className="text-2xl font-black text-amber-600 mt-2">
            {totalSaaSRevenue.toLocaleString()} <span className="text-xs font-bold">{t('iqd')}</span>
          </p>
          <p className="text-[11px] text-slate-400 mt-1">اشتراكات سنوية وشهرية</p>
        </div>
      </div>

      {/* Registered Schools Tenants List */}
      <div className="bg-white rounded-3xl border border-slate-200/90 overflow-hidden shadow-xs space-y-4 p-6">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-base text-slate-900">
            المدارس المسجلة في النظام (Multi-Tenant Schools)
          </h3>
          <span className="text-xs text-slate-500 font-semibold">
            {schools.length} مدارس مرخصة
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {schools.map(school => {
            const isActiveTenant = school.id === currentSchool.id;
            return (
              <div 
                key={school.id}
                className={`p-5 rounded-3xl border transition-all ${
                  isActiveTenant 
                    ? 'border-emerald-500 ring-2 ring-emerald-500/20 bg-emerald-50/20' 
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <img 
                      src={school.logo} 
                      alt="" 
                      className="w-12 h-12 rounded-2xl object-cover ring-2 ring-slate-100" 
                    />
                    <div>
                      <h4 className="font-extrabold text-sm text-slate-900">
                        {lang === 'ar' ? school.nameAr : school.nameEn}
                      </h4>
                      <p className="text-xs text-slate-500">{school.city} • {school.district}</p>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">باقة الاشتراك:</span>
                    <span className="font-bold text-slate-900">{school.saasSubscription?.planNameAr}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">الحد الأقصى للطلاب:</span>
                    <span className="font-bold text-slate-700">{school.saasSubscription?.studentsLimit} طالب</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">تاريخ التجديد:</span>
                    <span className="font-mono text-slate-600">{school.saasSubscription?.expiresDate}</span>
                  </div>
                </div>

                <div className="mt-4 pt-2 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => switchSchool(school.id)}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                      isActiveTenant 
                        ? 'bg-emerald-600 text-white cursor-default' 
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                    }`}
                  >
                    {isActiveTenant ? 'المدرسة الحالية' : 'التبديل إلى هذه المدرسة'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      switchSchool(school.id);
                      onOpenThemeModal();
                    }}
                    title="تخصيص الهوية"
                    className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600"
                  >
                    <Sparkles className="w-4 h-4 text-amber-500" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SaaS Subscription Plans Grid */}
      <div className="space-y-4">
        <div className="text-center max-w-xl mx-auto space-y-1">
          <h3 className="font-extrabold text-lg text-slate-900">باقات الاشتراك السحابي للمدارس</h3>
          <p className="text-xs text-slate-500">
            اختر الباقة المناسبة لحجم مدرستك مع تفعيل فوري لكافة بوابات الدفع العراقية
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {saasPlans.map(plan => (
            <div 
              key={plan.id}
              className={`bg-white p-6 rounded-3xl border transition-all flex flex-col justify-between ${
                plan.recommended 
                  ? 'border-emerald-600 ring-2 ring-emerald-600/20 shadow-lg relative' 
                  : 'border-slate-200 shadow-xs'
              }`}
            >
              {plan.recommended && (
                <span className="absolute -top-3 right-6 px-3 py-1 rounded-full text-[10px] font-extrabold bg-emerald-700 text-white shadow-xs">
                  الأكثر طلباً في العراق
                </span>
              )}

              <div className="space-y-4">
                <div>
                  <h4 className="font-extrabold text-base text-slate-900">{plan.nameAr}</h4>
                  <div className="mt-2 flex items-baseline gap-1">
                    <span className="text-2xl font-black text-slate-900">
                      {plan.priceYearlyIQD?.toLocaleString()}
                    </span>
                    <span className="text-xs font-bold text-slate-500">{t('iqd')} / سنوياً</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">أو {plan.priceMonthlyIQD?.toLocaleString()} د.ع شهرياً</p>
                </div>

                <div className="space-y-2 text-xs border-t border-slate-100 pt-4">
                  {(plan.featuresAr || []).map((feat, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-slate-700">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-6 mt-6 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => showToast(`تم اختيار باقة ${plan.nameAr}`, 'info')}
                  className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all ${
                    plan.recommended 
                      ? 'bg-emerald-700 text-white hover:bg-emerald-800 shadow-md' 
                      : 'bg-slate-100 text-slate-800 hover:bg-slate-200'
                  }`}
                >
                  اختيار هذه الباقة
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Onboard New School Modal */}
      {showAddSchoolModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div 
              className="p-5 text-white flex items-center justify-between"
              style={{ backgroundColor: primaryColor }}
            >
              <h3 className="font-extrabold text-base">{t('addNewSchool')}</h3>
              <button onClick={() => setShowAddSchoolModal(false)} className="text-white hover:opacity-80">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSchoolSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">{t('schoolNameAr')} *</label>
                <input 
                  type="text" 
                  required
                  value={nameAr}
                  onChange={(e) => setNameAr(e.target.value)}
                  placeholder="مثال: مدارس دجلة الأهلية النموذجية"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">{t('schoolNameEn')}</label>
                <input 
                  type="text" 
                  value={nameEn}
                  onChange={(e) => setNameEn(e.target.value)}
                  placeholder="Tigris Model High School"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t('schoolCity')}</label>
                  <input 
                    type="text" 
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="بغداد"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t('schoolDistrict')}</label>
                  <input 
                    type="text" 
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    placeholder="الكرخ / المنصور"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">{t('selectPlan')}</label>
                <select 
                  value={selectedPlanId}
                  onChange={(e) => setSelectedPlanId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                >
                  <option value="basic">الباقة الأساسية (Starter) - 3,500,000 د.ع</option>
                  <option value="pro">الباقة المتقدمة (Pro) - 6,500,000 د.ع</option>
                  <option value="enterprise">الباقة المؤسسية (Enterprise) - 12,000,000 د.ع</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddSchoolModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 font-bold"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-white font-bold"
                  style={{ backgroundColor: primaryColor }}
                >
                  تأكيد تسجيل المدرسة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
