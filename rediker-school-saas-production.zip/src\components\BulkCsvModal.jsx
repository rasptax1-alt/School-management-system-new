import React, { useState, useRef } from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  X, 
  UploadCloud, 
  Download, 
  FileSpreadsheet, 
  CheckCircle2, 
  AlertCircle, 
  Eye, 
  HelpCircle 
} from 'lucide-react';
import { 
  parseUploadedCsvFile, 
  downloadSectionTemplate 
} from '../services/csvExportImport';

export function BulkCsvModal({ section = 'students', sectionTitle, onClose, onImportComplete }) {
  const { currentSchool, bulkImportSection, showToast } = useSchool();
  const { t, lang, isRTL } = useLanguage();
  
  const [file, setFile] = useState(null);
  const [previewRows, setPreviewRows] = useState([]);
  const [headers, setHeaders] = useState([]);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const fileInputRef = useRef(null);

  const handleFileChange = async (e) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    if (!selectedFile.name.endsWith('.csv')) {
      setErrorMsg(isRTL ? 'يرجى اختيار ملف بصيغة CSV فقط' : 'Please select a valid CSV file');
      return;
    }

    setErrorMsg('');
    setFile(selectedFile);
    setLoading(true);

    try {
      const result = await parseUploadedCsvFile(selectedFile);
      if (result.data && result.data.length > 0) {
        setPreviewRows(result.data);
        setHeaders(Object.keys(result.data[0] || {}));
      } else {
        setErrorMsg(isRTL ? 'الملف لا يحتوي على صفوف بيانات صالحة' : 'CSV file contains no valid rows');
      }
    } catch (err) {
      setErrorMsg(err.message || 'Error parsing CSV file');
    } finally {
      setLoading(false);
    }
  };

  const handleExecuteImport = () => {
    if (previewRows.length === 0) return;
    bulkImportSection(section, previewRows);
    if (onImportComplete) onImportComplete(previewRows);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div 
          className="p-5 text-white flex items-center justify-between"
          style={{ backgroundColor: currentSchool.theme?.primary || '#0F766E' }}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg">
                {t('bulkImportStudents')} - {sectionTitle || section}
              </h3>
              <p className="text-xs text-white/80">
                {currentSchool.nameAr} • استيراد جماعي لملفات CSV متوافقة مع Excel
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">

          {/* Download Template Banner */}
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h4 className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                <Download className="w-4 h-4 text-emerald-600" />
                تحميل نموذج CSV الجاهز لهذا القسم
              </h4>
              <p className="text-[11px] text-emerald-800 mt-0.5">
                {t('templateReadyText')}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => downloadSectionTemplate(section, 'ar')}
                className="px-3 py-1.5 rounded-xl bg-emerald-700 text-white text-xs font-bold hover:bg-emerald-800 transition-colors shadow-xs"
              >
                تحميل نموذج (عربي)
              </button>
              <button
                type="button"
                onClick={() => downloadSectionTemplate(section, 'en')}
                className="px-3 py-1.5 rounded-xl bg-white border border-emerald-300 text-emerald-800 text-xs font-bold hover:bg-emerald-50 transition-colors"
              >
                Template (EN)
              </button>
            </div>
          </div>

          {/* Upload Area */}
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-2xl p-8 text-center cursor-pointer bg-slate-50 hover:bg-emerald-50/20 transition-all group"
          >
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              accept=".csv"
              className="hidden" 
            />
            <div className="w-14 h-14 rounded-2xl bg-white shadow-sm border border-slate-200 flex items-center justify-center mx-auto text-slate-500 group-hover:text-emerald-600 group-hover:scale-110 transition-all">
              <UploadCloud className="w-7 h-7" />
            </div>
            <p className="text-sm font-bold text-slate-800 mt-3">
              {file ? file.name : t('dragDropCsv')}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              يدعم ترميز UTF-8 وملفات Excel المصدرة
            </p>
          </div>

          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2 font-semibold">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Data Preview */}
          {previewRows.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Eye className="w-4 h-4 text-blue-600" />
                  معاينة البيانات المكتشفة ({previewRows.length} صف)
                </span>
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                  جاهز للإدراج
                </span>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden max-h-56 overflow-x-auto overflow-y-auto text-xs">
                <table className="w-full text-start">
                  <thead className="bg-slate-100 text-slate-700 font-bold sticky top-0 border-b border-slate-200">
                    <tr>
                      <th className="p-2 text-start">#</th>
                      {headers.slice(0, 5).map((h, i) => (
                        <th key={i} className="p-2 text-start whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {previewRows.slice(0, 5).map((row, rIdx) => (
                      <tr key={rIdx} className="hover:bg-slate-50">
                        <td className="p-2 text-slate-400 font-mono">{rIdx + 1}</td>
                        {headers.slice(0, 5).map((h, cIdx) => (
                          <td key={cIdx} className="p-2 text-slate-700 whitespace-nowrap">
                            {String(row[h] || '')}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Footer Controls */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-50 transition-colors"
            >
              {t('cancel')}
            </button>
            <button
              type="button"
              disabled={previewRows.length === 0 || loading}
              onClick={handleExecuteImport}
              className="px-6 py-2.5 rounded-xl text-white text-xs font-bold shadow-md hover:opacity-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              style={{ backgroundColor: currentSchool.theme?.primary || '#0F766E' }}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{t('executeBulkImport')} ({previewRows.length})</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
