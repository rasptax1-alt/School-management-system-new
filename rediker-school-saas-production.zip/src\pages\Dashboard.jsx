import React from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  GraduationCap, 
  Users, 
  BookOpen, 
  CreditCard, 
  CalendarCheck, 
  ArrowUpRight, 
  FileSpreadsheet, 
  PlusCircle, 
  ShieldCheck, 
  ChevronRight,
  TrendingUp,
  Clock,
  Sparkles
} from 'lucide-react';

export function Dashboard({ onNavigate, onOpenCsvModal, onOpenPaymentModal }) {
  const { 
    currentSchool, 
    students, 
    staff, 
    classes, 
    invoices, 
    attendance, 
    grades 
  } = useSchool();
  const { t, lang, isRTL } = useLanguage();

  const totalTuition = invoices.reduce((acc, i) => acc + (i.amountIQD || 0), 0);
  const collectedTuition = invoices.reduce((acc, i) => acc + (i.paidAmountIQD || 0), 0);
  const collectionRate = totalTuition > 0 ? Math.round((collectedTuition / totalTuition) * 100) : 0;
  const pendingInvoices = invoices.filter(i => i.status !== 'مدفوع بالكامل');

  // Today attendance stats
  const presentCount = attendance.filter(a => a.status === 'حاضر').length;
  const attendanceRate = attendance.length > 0 ? Math.round((presentCount / attendance.length) * 100) : 98;

  const primaryColor = currentSchool.theme?.primary || '#0F766E';
  const secondaryColor = currentSchool.theme?.secondary || '#D97706';

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      
      {/* Top Banner with School Identity */}
      <div 
        className="rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-lg transition-all"
        style={{ 
          background: `linear-gradient(135deg, ${primaryColor} 0%, ${currentSchool.theme?.darkBg || '#042F2E'} 100%)` 
        }}
      >
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>{currentSchool.saasSubscription?.planNameAr} • نشط حتى {currentSchool.saasSubscription?.expiresDate}</span>
          </div>
          
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            مرحباً بك في {lang === 'ar' ? currentSchool.nameAr : currentSchool.nameEn}
          </h2>
          
          <p className="text-white/80 text-xs sm:text-sm font-medium leading-relaxed">
            {lang === 'ar' ? currentSchool.mottoAr : currentSchool.mottoEn} — منظومة إدارة المدارس السحابية المتكاملة بمعمارية Rediker المتطورة وبوابات الدفع العراقية.
          </p>

          {/* Quick Action Badges */}
          <div className="flex flex-wrap items-center gap-2.5 pt-2">
            <button
              onClick={() => onNavigate('students')}
              className="px-4 py-2 rounded-xl bg-white text-slate-900 text-xs font-extrabold hover:bg-slate-100 transition-all shadow-sm flex items-center gap-1.5"
            >
              <PlusCircle className="w-3.5 h-3.5 text-emerald-600" />
              <span>{t('newStudentEnroll')}</span>
            </button>
            <button
              onClick={() => onNavigate('billing')}
              className="px-4 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold transition-all backdrop-blur-md flex items-center gap-1.5"
            >
              <CreditCard className="w-3.5 h-3.5 text-amber-300" />
              <span>{t('payNow')}</span>
            </button>
            <button
              onClick={() => onOpenCsvModal('students')}
              className="px-4 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold transition-all backdrop-blur-md flex items-center gap-1.5"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-teal-300" />
              <span>{t('bulkImportStudents')}</span>
            </button>
          </div>
        </div>

        {/* Decorative Watermark Logo */}
        <div className="absolute top-1/2 -translate-y-1/2 left-8 opacity-15 pointer-events-none hidden lg:block">
          <img 
            src={currentSchool.logo} 
            alt="" 
            className="w-56 h-56 rounded-full object-cover ring-8 ring-white/10" 
          />
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        
        {/* Total Students */}
        <div 
          onClick={() => onNavigate('students')}
          className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-xs hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">{t('totalStudents')}</span>
            <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center group-hover:scale-110 transition-transform">
              <GraduationCap className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">{students.length}</span>
            <span className="text-xs text-emerald-600 font-bold flex items-center gap-0.5">
              <ArrowUpRight className="w-3 h-3" />
              +100% {t('active')}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">الحد الأقصى للباقة: {currentSchool.saasSubscription?.studentsLimit} طالب</p>
        </div>

        {/* Total Faculty & Staff */}
        <div 
          onClick={() => onNavigate('staff')}
          className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-xs hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">{t('totalStaff')}</span>
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-700 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">{staff.length}</span>
            <span className="text-xs text-slate-500 font-semibold">معلمين وإداريين</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">نسبة معلم لكل 8 طلاب</p>
        </div>

        {/* Today's Attendance Rate */}
        <div 
          onClick={() => onNavigate('attendance')}
          className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-xs hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">{t('attendanceRateToday')}</span>
            <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:scale-110 transition-transform">
              <CalendarCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">{attendanceRate}%</span>
            <span className="text-xs text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">
              ممتاز
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">مسجل اليوم: {attendance.length} طالب</p>
        </div>

        {/* Tuition Collection Rate */}
        <div 
          onClick={() => onNavigate('billing')}
          className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-xs hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">{t('tuitionCollection')}</span>
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center group-hover:scale-110 transition-transform">
              <CreditCard className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">{collectionRate}%</span>
            <span className="text-xs text-amber-700 font-bold">
              {collectedTuition.toLocaleString()} {t('iqd')}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">بوابات الدفع: زين كاش، كي كارد، FIB</p>
        </div>

      </div>

      {/* Main Sections Split: Pending Invoices & Recent Students */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Pending Invoices / Iraqi Gateways Quick Pay */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
                <CreditCard className="w-4 h-4" />
              </div>
              <h3 className="font-extrabold text-sm sm:text-base text-slate-900">
                {t('pendingInvoices')} ({pendingInvoices.length})
              </h3>
            </div>
            <button
              onClick={() => onNavigate('billing')}
              className="text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1"
            >
              <span>{t('all')}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {pendingInvoices.slice(0, 3).map((inv) => (
              <div 
                key={inv.id}
                className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between hover:bg-slate-100/70 transition-colors"
              >
                <div>
                  <h4 className="text-xs font-bold text-slate-900">{inv.studentNameAr}</h4>
                  <p className="text-[11px] text-slate-500">{inv.feeCategory} • {inv.gradeLevel}</p>
                  <p className="text-[10px] text-slate-400 font-mono">{inv.invoiceNumber}</p>
                </div>
                <div className="text-end space-y-1.5">
                  <span className="text-xs font-extrabold text-slate-900 block">
                    {(inv.amountIQD || 2500000).toLocaleString()} {t('iqd')}
                  </span>
                  <button
                    onClick={() => onOpenPaymentModal(inv)}
                    className="px-3 py-1 rounded-lg text-white text-[11px] font-bold shadow-xs hover:opacity-95 transition-opacity"
                    style={{ backgroundColor: primaryColor }}
                  >
                    تسديد فوري
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Student Enrollments */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
                <GraduationCap className="w-4 h-4" />
              </div>
              <h3 className="font-extrabold text-sm sm:text-base text-slate-900">
                أحدث الطلاب المسجلين (Administrator's Plus)
              </h3>
            </div>
            <button
              onClick={() => onNavigate('students')}
              className="text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1"
            >
              <span>{t('studentDirectory')}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {students.slice(0, 4).map((stu) => (
              <div 
                key={stu.id}
                className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between hover:bg-slate-100/70 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center">
                    {stu.fullNameAr?.slice(0, 1) || 'ط'}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">{stu.fullNameAr}</h4>
                    <p className="text-[11px] text-slate-500">{stu.gradeLevel} • شعبة {stu.section}</p>
                  </div>
                </div>
                <div className="text-end">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    stu.tuitionStatus === 'مدفوع' 
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                      : (stu.tuitionStatus === 'جزئي' ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-rose-50 text-rose-700 border border-rose-200')
                  }`}>
                    {stu.tuitionStatus}
                  </span>
                  <p className="text-[10px] text-slate-400 font-mono mt-0.5">{stu.studentId}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
