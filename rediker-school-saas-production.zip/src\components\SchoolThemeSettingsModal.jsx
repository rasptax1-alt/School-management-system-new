import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  X, 
  Palette, 
  Check, 
  Sparkles, 
  Image as ImageIcon, 
  Save, 
  RefreshCw 
} from 'lucide-react';

export function SchoolThemeSettingsModal({ onClose }) {
  const { currentSchool, updateSchoolTheme, showToast } = useSchool();
  const { t, lang } = useLanguage();

  const [nameAr, setNameAr] = useState(currentSchool.nameAr);
  const [nameEn, setNameEn] = useState(currentSchool.nameEn);
  const [mottoAr, setMottoAr] = useState(currentSchool.mottoAr);
  const [logo, setLogo] = useState(currentSchool.logo);
  const [primary, setPrimary] = useState(currentSchool.theme?.primary || '#0F766E');
  const [secondary, setSecondary] = useState(currentSchool.theme?.secondary || '#D97706');
  const [accent, setAccent] = useState(currentSchool.theme?.accent || '#14B8A6');

  const presetThemes = [
    {
      id: "emerald",
      name: "الزمردي الملكي والذهبي",
      primary: "#0F766E",
      primaryHover: "#0D9488",
      secondary: "#D97706",
      accent: "#14B8A6",
      darkBg: "#134E4A",
      sidebarBg: "#042F2E",
      cardBorder: "#CCFBF1"
    },
    {
      id: "navy",
      name: "الأزرق الملكي والقرمزي",
      primary: "#1E3A8A",
      primaryHover: "#2563EB",
      secondary: "#BE123C",
      accent: "#38BDF8",
      darkBg: "#172554",
      sidebarBg: "#0F172A",
      cardBorder: "#DBEAFE"
    },
    {
      id: "purple",
      name: "الأرجوان البابلي والكهرمان",
      primary: "#6B21A8",
      primaryHover: "#7E22CE",
      secondary: "#F59E0B",
      accent: "#C084FC",
      darkBg: "#3B0764",
      sidebarBg: "#2E1065",
      cardBorder: "#F3E8FF"
    },
    {
      id: "slate",
      name: "الفحمي المطور والتركواز",
      primary: "#334155",
      primaryHover: "#475569",
      secondary: "#0284C7",
      accent: "#10B981",
      darkBg: "#0F172A",
      sidebarBg: "#020617",
      cardBorder: "#E2E8F0"
    }
  ];

  const handleApplyPreset = (preset) => {
    setPrimary(preset.primary);
    setSecondary(preset.secondary);
    setAccent(preset.accent);
  };

  const handleSave = () => {
    updateSchoolTheme(currentSchool.id, {
      nameAr,
      nameEn,
      mottoAr,
      logo,
      theme: {
        ...currentSchool.theme,
        primary,
        primaryHover: primary,
        secondary,
        accent,
        sidebarBg: primary
      }
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div 
          className="p-5 text-white flex items-center justify-between"
          style={{ backgroundColor: primary }}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <Palette className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg">
                {t('visualIdentityTitle')}
              </h3>
              <p className="text-xs text-white/80">
                تخصيص ألوان وثيم وشعار المدرسة بصورة حية وفورية
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">

          {/* Preset Palettes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              {t('themePresets')}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {presetThemes.map(p => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => handleApplyPreset(p)}
                  className={`p-3 rounded-2xl border text-start transition-all ${
                    primary === p.primary 
                      ? 'border-slate-800 ring-2 ring-slate-800/20 bg-slate-50' 
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className="w-4 h-4 rounded-full" style={{ backgroundColor: p.primary }} />
                    <span className="w-4 h-4 rounded-full" style={{ backgroundColor: p.secondary }} />
                    <span className="w-4 h-4 rounded-full" style={{ backgroundColor: p.accent }} />
                  </div>
                  <p className="text-xs font-bold text-slate-800">{p.name}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Color Pickers */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t('primaryColor')}
              </label>
              <div className="flex items-center gap-2 border border-slate-200 rounded-xl p-2 bg-slate-50">
                <input 
                  type="color" 
                  value={primary} 
                  onChange={(e) => setPrimary(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                />
                <span className="text-xs font-mono font-bold text-slate-700">{primary}</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t('secondaryColor')}
              </label>
              <div className="flex items-center gap-2 border border-slate-200 rounded-xl p-2 bg-slate-50">
                <input 
                  type="color" 
                  value={secondary} 
                  onChange={(e) => setSecondary(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                />
                <span className="text-xs font-mono font-bold text-slate-700">{secondary}</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t('accentColor')}
              </label>
              <div className="flex items-center gap-2 border border-slate-200 rounded-xl p-2 bg-slate-50">
                <input 
                  type="color" 
                  value={accent} 
                  onChange={(e) => setAccent(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                />
                <span className="text-xs font-mono font-bold text-slate-700">{accent}</span>
              </div>
            </div>
          </div>

          {/* School Name & Motto Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t('schoolNameAr')}
              </label>
              <input 
                type="text" 
                value={nameAr} 
                onChange={(e) => setNameAr(e.target.value)}
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t('schoolNameEn')}
              </label>
              <input 
                type="text" 
                value={nameEn} 
                onChange={(e) => setNameEn(e.target.value)}
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t('schoolMottoAr')}
              </label>
              <input 
                type="text" 
                value={mottoAr} 
                onChange={(e) => setMottoAr(e.target.value)}
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t('schoolLogoUrl')}
              </label>
              <input 
                type="text" 
                value={logo} 
                onChange={(e) => setLogo(e.target.value)}
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Live Preview Card */}
          <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-3">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              معاينة حية للمظهر
            </span>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img src={logo} alt="" className="w-12 h-12 rounded-xl object-cover ring-2 ring-slate-200" />
                <div>
                  <h4 className="font-extrabold text-sm text-slate-900">{nameAr}</h4>
                  <p className="text-xs text-slate-500">{mottoAr}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  type="button" 
                  className="px-3 py-1.5 rounded-xl text-xs font-bold text-white shadow-xs"
                  style={{ backgroundColor: primary }}
                >
                  زر أساسي
                </button>
                <button 
                  type="button" 
                  className="px-3 py-1.5 rounded-xl text-xs font-bold text-white shadow-xs"
                  style={{ backgroundColor: secondary }}
                >
                  زر ثانوي
                </button>
              </div>
            </div>
          </div>

          {/* Footer Controls */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-50 transition-colors"
            >
              {t('cancel')}
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-6 py-2.5 rounded-xl text-white text-xs font-bold shadow-md hover:opacity-95 transition-all flex items-center gap-2"
              style={{ backgroundColor: primary }}
            >
              <Save className="w-4 h-4" />
              <span>{t('applyVisualIdentity')}</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
