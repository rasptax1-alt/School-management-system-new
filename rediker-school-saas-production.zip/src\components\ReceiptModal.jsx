import React from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { X, Printer, CheckCircle, ShieldCheck } from 'lucide-react';

export function ReceiptModal({ invoice, onClose }) {
  const { currentSchool } = useSchool();
  const { t, lang } = useLanguage();

  if (!invoice) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Actions bar (hidden in print) */}
        <div className="p-4 bg-slate-100 border-b border-slate-200 flex items-center justify-between no-print">
          <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            معاينة وصل القبض الرسمي المعتمد
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-900 text-white hover:bg-slate-800 flex items-center gap-2"
            >
              <Printer className="w-4 h-4" />
              <span>{t('print')}</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-500 hover:bg-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Paper */}
        <div className="p-8 sm:p-12 space-y-6 text-slate-800 bg-white" id="printable-receipt">
          
          {/* Header */}
          <div className="flex items-center justify-between border-b-2 pb-6" style={{ borderColor: currentSchool.theme?.primary || '#0F766E' }}>
            <div className="space-y-1">
              <p className="text-xs font-bold text-slate-500">جمهورية العراق - وزارة التربية</p>
              <h2 className="text-xl font-black text-slate-900">{currentSchool.nameAr}</h2>
              <p className="text-xs text-slate-500">{currentSchool.mottoAr}</p>
              <p className="text-[11px] text-slate-400">{currentSchool.city} • {currentSchool.phone}</p>
            </div>
            <div className="text-center">
              <img 
                src={currentSchool.logo} 
                alt="Logo" 
                className="w-20 h-20 rounded-2xl object-cover ring-2 ring-slate-100 shadow-sm mx-auto"
              />
              <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block mt-1">
                معتمد رسمياً
              </span>
            </div>
          </div>

          {/* Receipt Title & Meta */}
          <div className="flex items-center justify-between bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <div>
              <span className="text-xs text-slate-500 font-semibold">نوع المستند:</span>
              <h3 className="text-base font-black text-slate-900">وصل قبض مالي رسمي (Tuition Receipt)</h3>
            </div>
            <div className="text-end">
              <p className="text-xs font-bold text-slate-700">رقم الوصل: <span className="font-mono text-emerald-800">{invoice.receiptNumber || `REC-BAG-2025-${invoice.invoiceNumber?.slice(-3)}`}</span></p>
              <p className="text-[11px] text-slate-500">التاريخ: {invoice.paidDate || new Date().toISOString().split('T')[0]}</p>
              <p className="text-[11px] text-slate-500">العام الدراسي: 2025 - 2026</p>
            </div>
          </div>

          {/* Student & Payment Info Grid */}
          <div className="grid grid-cols-2 gap-4 text-xs border border-slate-200 p-4 rounded-2xl">
            <div>
              <p className="text-slate-500 font-medium">اسم الطالب:</p>
              <p className="font-bold text-sm text-slate-900 mt-0.5">{invoice.studentNameAr}</p>
            </div>
            <div>
              <p className="text-slate-500 font-medium">رقم القيد:</p>
              <p className="font-bold font-mono text-slate-800 mt-0.5">{invoice.studentId}</p>
            </div>
            <div>
              <p className="text-slate-500 font-medium">المرحلة الدراسية:</p>
              <p className="font-bold text-slate-800 mt-0.5">{invoice.gradeLevel}</p>
            </div>
            <div>
              <p className="text-slate-500 font-medium">نوع القسط / الرسوم:</p>
              <p className="font-bold text-slate-800 mt-0.5">{invoice.feeCategory}</p>
            </div>
          </div>

          {/* Amount Paid Box */}
          <div 
            className="p-4 rounded-2xl text-white flex items-center justify-between shadow-xs"
            style={{ backgroundColor: currentSchool.theme?.primary || '#0F766E' }}
          >
            <div>
              <p className="text-xs text-white/80">المبلغ المستلم بالدينار العراقي:</p>
              <h4 className="text-2xl font-black mt-0.5">
                {(invoice.amountIQD || 2500000).toLocaleString()} د.ع
              </h4>
            </div>
            <div className="text-end text-xs">
              <span className="px-3 py-1 rounded-full bg-white/20 font-bold inline-block mb-1">
                مسدد بالكامل
              </span>
              <p className="text-white/80 text-[11px]">بوابة الدفع: {invoice.paymentGatewayName || invoice.paymentMethod}</p>
            </div>
          </div>

          {/* Payment Gateway Transaction Token */}
          <div className="text-[11px] text-slate-500 bg-slate-50 p-3 rounded-xl border border-slate-200 flex justify-between items-center">
            <span>المرجع الإلكتروني للعملية:</span>
            <span className="font-mono font-bold text-slate-700">{invoice.transactionRef || 'ZC-TXN-984210'}</span>
          </div>

          {/* Signatures & Stamps */}
          <div className="pt-8 grid grid-cols-2 gap-8 text-center text-xs">
            <div className="space-y-12">
              <p className="font-bold text-slate-700">توقيع ولي الأمر / المستلم</p>
              <div className="w-36 border-b border-slate-400 mx-auto" />
            </div>
            <div className="space-y-4">
              <p className="font-bold text-slate-700">ختم المدرسة وأمين الصندوق</p>
              <div className="w-24 h-24 border-2 border-dashed border-emerald-600 rounded-full mx-auto flex items-center justify-center text-[10px] text-emerald-800 font-bold transform -rotate-12">
                ختم الإدارة المالية<br/>{currentSchool.nameAr?.slice(0, 12)}
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
