import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useApp } from '../context/AppContext';
import {
  Sparkles,
  CheckCircle2,
  XCircle,
  Edit2,
  Check,
  ChevronDown,
  ArrowRight,
  RotateCw,
  Package,
  Calendar,
  Building2,
  AlertCircle
} from 'lucide-react';

export default function AISuggestions() {
  const { t, isRtl, formatCurrency, formatNumber, formatDate } = useLanguage();
  const {
    purchaseOrders,
    productMap,
    supplierMap,
    isGeneratingRestock,
    runRestockGenerator,
    approveSuggestion,
    rejectSuggestion,
    bulkApproveSuggestions,
    modifySuggestion,
    addToast
  } = useApp();

  const [selectedIds, setSelectedIds] = useState(new Set());
  const [expandedReasoning, setExpandedReasoning] = useState(new Set());
  const [editingPoId, setEditingPoId] = useState(null);
  const [editQty, setEditQty] = useState(100);
  const [editDate, setEditDate] = useState('');

  const suggestions = purchaseOrders.filter(po => po.status === 'suggested');

  const handleToggleSelect = (id) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleSelectAll = () => {
    if (selectedIds.size === suggestions.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(suggestions.map(s => s.id)));
    }
  };

  const handleBulkApprove = () => {
    if (selectedIds.size === 0) return;
    bulkApproveSuggestions(Array.from(selectedIds));
    addToast(`Approved ${selectedIds.size} purchase orders successfully!`, 'success');
    setSelectedIds(new Set());
  };

  const toggleReasoning = (id) => {
    setExpandedReasoning(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const startEdit = (po) => {
    setEditingPoId(po.id);
    setEditQty(po.quantity);
    setEditDate(po.expected_delivery || '');
  };

  const saveEdit = (poId) => {
    modifySuggestion(poId, editQty, editDate);
    setEditingPoId(null);
    addToast('Suggestion updated', 'success');
  };

  const handleRunGenerator = async () => {
    const count = await runRestockGenerator();
    if (count > 0) {
      addToast(`AI created ${count} new restock recommendations!`, 'success');
    } else {
      addToast(t('toastGeneratorFinished'), 'success');
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 pb-24 flex flex-col gap-6">
      {/* Header & Run Generator Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#DFDFDF]">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-4 h-4 rounded-full bg-[#FF9000]" />
            <h1 className="font-semibold text-lg text-[#111111]">
              {t('aiPageTitle')}
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-[#FF9000]/15 text-[#B86800] font-bold">
              {suggestions.length} {t('suggestionsFound')}
            </span>
          </div>
          <p className="text-xs text-[#898989] mt-1">
            {t('aiPageSubtitle')}
          </p>
        </div>

        <button
          onClick={handleRunGenerator}
          disabled={isGeneratingRestock}
          className={`flex items-center gap-2 h-10 px-5 rounded-full bg-[#111111] hover:bg-[#FF9000] text-white hover:text-[#111111] font-semibold text-xs transition-all shadow-sm self-start sm:self-auto ${
            isGeneratingRestock ? 'opacity-70 cursor-not-allowed' : ''
          }`}
        >
          <RotateCw className={`w-3.5 h-3.5 ${isGeneratingRestock ? 'animate-spin text-[#FF9000]' : ''}`} />
          <span>
            {isGeneratingRestock ? t('runningGenerator') : t('runRestockGenerator')}
          </span>
        </button>
      </div>

      {/* Bulk Action Bar */}
      {suggestions.length > 0 && (
        <div className="flex items-center justify-between bg-white px-4 py-2.5 rounded-2xl border border-[#DFDFDF] text-xs">
          <label className="flex items-center gap-2 cursor-pointer font-medium text-[#343434]">
            <input
              type="checkbox"
              checked={selectedIds.size === suggestions.length && suggestions.length > 0}
              onChange={handleSelectAll}
              className="rounded accent-[#111111] w-4 h-4"
            />
            <span>{t('selectAll')} ({suggestions.length})</span>
          </label>

          {selectedIds.size > 0 && (
            <button
              onClick={handleBulkApprove}
              className="flex items-center gap-1.5 h-8 px-4 rounded-full bg-[#10B981] hover:bg-[#059669] text-white font-semibold transition-all shadow-xs"
            >
              <Check className="w-3.5 h-3.5" />
              <span>{t('bulkApprove')} ({selectedIds.size})</span>
            </button>
          )}
        </div>
      )}

      {/* Suggestion Cards Feed */}
      <div className="flex flex-col gap-4">
        {suggestions.map(po => {
          const prod = productMap[po.product_id];
          const sup = supplierMap[po.supplier_id];
          const isSelected = selectedIds.has(po.id);
          const isExpanded = expandedReasoning.has(po.id);
          const isEditing = editingPoId === po.id;

          const reasoningText = isRtl
            ? (po.ai_reasoningAr || po.ai_reasoning)
            : (po.ai_reasoning || po.ai_reasoningAr);

          return (
            <div
              key={po.id}
              className={`bg-white rounded-3xl p-5 border transition-all duration-200 shadow-card-subtle flex flex-col gap-4 ${
                isSelected ? 'border-[#111111] ring-1 ring-[#111111]' : 'border-[#DFDFDF]'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                {/* Product & Checkbox */}
                <div className="flex items-start gap-3 min-w-0">
                  <input
                    type="checkbox"
                    checked={isSelected}
                    onChange={() => handleToggleSelect(po.id)}
                    className="rounded accent-[#111111] w-4 h-4 mt-1 cursor-pointer"
                  />

                  {prod && (
                    <img
                      src={prod.image_url}
                      alt={prod.name}
                      className="w-12 h-12 rounded-xl object-cover border border-[#DFDFDF] shrink-0"
                    />
                  )}

                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs font-bold text-[#111111]">
                        {po.po_number}
                      </span>
                      <span className="font-mono text-[10px] text-[#898989] px-2 py-0.5 rounded bg-[#F3F3F5]">
                        {prod?.sku}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#FF9000]/15 text-[#B86800] font-semibold">
                        {t('statusSuggested')}
                      </span>
                    </div>

                    <h3 className="font-semibold text-sm text-[#111111] mt-1 truncate">
                      {prod ? (isRtl ? (prod.nameAr || prod.name) : prod.name) : 'Product'}
                    </h3>

                    <div className="text-[11px] text-[#898989] mt-0.5 flex items-center gap-2">
                      <span>{t('fieldSupplier')}: <span className="text-[#111111] font-medium">{sup ? (isRtl ? (sup.nameAr || sup.name) : sup.name) : '—'}</span></span>
                      <span>·</span>
                      <span>Lead Time: <span className="font-medium text-[#111111]">{sup?.default_lead_time_days || 10} days</span></span>
                    </div>
                  </div>
                </div>

                {/* Key Numbers / Inline Edit Form */}
                <div className="flex sm:flex-col items-end justify-between sm:justify-start gap-2 text-right">
                  {isEditing ? (
                    <div className="flex items-center gap-2 bg-[#F3F3F5] p-2 rounded-xl">
                      <input
                        type="number"
                        min="1"
                        value={editQty}
                        onChange={(e) => setEditQty(Number(e.target.value))}
                        className="w-20 h-7 px-2 text-xs rounded border border-[#DFDFDF] bg-white font-semibold"
                      />
                      <input
                        type="date"
                        value={editDate}
                        onChange={(e) => setEditDate(e.target.value)}
                        className="h-7 px-2 text-xs rounded border border-[#DFDFDF] bg-white"
                      />
                      <button
                        onClick={() => saveEdit(po.id)}
                        className="p-1 rounded bg-[#10B981] text-white hover:bg-[#059669]"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <div>
                        <div className="text-base font-bold text-[#111111]">
                          {formatCurrency(po.total_cost)}
                        </div>
                        <div className="text-xs text-[#898989]">
                          {formatNumber(po.quantity)} {t('units')} @ {formatCurrency(po.unit_cost)}
                        </div>
                      </div>
                      <div className="text-[11px] text-[#898989] flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-[#FF9000]" />
                        <span>Delivery: {formatDate(po.expected_delivery)}</span>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* Collapsible AI Reasoning */}
              <div className="border-t border-[#DFDFDF]/70 pt-3">
                <button
                  onClick={() => toggleReasoning(po.id)}
                  className="flex items-center justify-between w-full text-xs font-semibold text-[#111111] hover:text-[#FF9000] transition-colors"
                >
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#FF9000]" />
                    <span>{t('aiReasoning')}</span>
                  </div>
                  <ChevronDown className={`w-4 h-4 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                </button>

                {isExpanded && (
                  <div className="mt-2.5 p-3 rounded-2xl bg-[#EBEBED]/70 text-xs text-[#343434] leading-relaxed border border-[#DFDFDF]/60 animate-in fade-in duration-150">
                    {reasoningText}
                  </div>
                )}
              </div>

              {/* Card Actions Footer */}
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  onClick={() => startEdit(po)}
                  className="px-3 py-1.5 rounded-full hover:bg-[#F3F3F5] text-xs font-medium text-[#898989] hover:text-[#111111] transition-colors flex items-center gap-1"
                >
                  <Edit2 className="w-3 h-3" />
                  <span>{t('editSuggestion')}</span>
                </button>

                <button
                  onClick={() => {
                    rejectSuggestion(po.id);
                    addToast(t('toastPORejected'), 'error');
                  }}
                  className="px-3 py-1.5 rounded-full hover:bg-red-50 text-xs font-medium text-[#F24E2C] transition-colors"
                >
                  {t('rejectSuggestion')}
                </button>

                <button
                  onClick={() => {
                    approveSuggestion(po.id);
                    addToast(t('toastPOApproved'), 'success');
                  }}
                  className="px-4 py-1.5 rounded-full bg-[#111111] hover:bg-[#10B981] text-white text-xs font-semibold transition-all flex items-center gap-1.5 shadow-xs"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>{t('approvePO')}</span>
                </button>
              </div>
            </div>
          );
        })}

        {/* Empty State */}
        {suggestions.length === 0 && (
          <div className="bg-white rounded-3xl p-12 border border-[#DFDFDF] text-center flex flex-col items-center justify-center gap-3">
            <div className="w-12 h-12 rounded-full bg-[#10B981]/15 text-[#10B981] flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="font-semibold text-base text-[#111111]">
              {t('noSuggestionsTitle')}
            </h3>
            <p className="text-xs text-[#898989] max-w-md">
              {t('noSuggestionsDesc')}
            </p>
            <button
              onClick={handleRunGenerator}
              disabled={isGeneratingRestock}
              className="mt-2 h-9 px-5 rounded-full bg-[#FF9000] hover:bg-[#111111] text-[#111111] hover:text-white text-xs font-semibold transition-all shadow-sm flex items-center gap-2"
            >
              <RotateCw className={`w-3.5 h-3.5 ${isGeneratingRestock ? 'animate-spin' : ''}`} />
              <span>{t('runRestockGenerator')}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
