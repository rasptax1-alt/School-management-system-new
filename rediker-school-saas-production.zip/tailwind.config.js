/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
        arabic: ['"Cairo"', 'system-ui', 'sans-serif'],
      },
      colors: {
        brand: {
          dark: '#111111',
          orange: '#FF9000',
          orangeHover: '#E58200',
          canvas: '#F3F3F5',
          card: '#FFFFFF',
          border: '#DFDFDF',
          muted: '#898989',
          body: '#343434',
          alert: '#F24E2C',
          success: '#10B981',
          info: '#2563EB',
        },
      },
      borderRadius: {
        '2xl': '18px',
        '3xl': '24px',
        'full': '9999px',
      },
      boxShadow: {
        'dock': '0 10px 30px -10px rgba(0, 0, 0, 0.25)',
        'card-subtle': '0 1px 3px rgba(0,0,0,0.04)',
      }
    },
  },
  plugins: [],
}
