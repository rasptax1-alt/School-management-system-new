// Rediker-Style School Management System & Multi-School SaaS Backend
// Supports Arabic First, Dynamic Theming, Iraqi Payment Gateways & Universal CSV Import/Export

import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { 
  defaultSchools, 
  saasPlans, 
  initialStudents, 
  initialStaff, 
  initialClasses, 
  initialGrades, 
  initialAttendance, 
  initialInvoices,
  iraqiPaymentGatewaysInfo 
} from './data/defaultSchools.js';
import { IraqiPaymentService } from './services/iraqiPayments.js';
import { CSV_TEMPLATES, generateCsvString, parseCsvString } from './services/csvHandler.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const distPath = path.join(__dirname, '../dist');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve static frontend build if present
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
}

// In-Memory state initialized from seed data
let db = {
  schools: [...defaultSchools],
  students: [...initialStudents],
  staff: [...initialStaff],
  classes: [...initialClasses],
  grades: [...initialGrades],
  attendance: [...initialAttendance],
  invoices: [...initialInvoices],
  transactions: []
};

// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    system: 'Rediker SIS & SaaS Iraq Platform',
    version: '2.5.0',
    time: new Date().toISOString(),
    stats: {
      schools: db.schools.length,
      totalStudents: db.students.length,
      totalStaff: db.staff.length,
      totalInvoices: db.invoices.length
    }
  });
});

// ==========================================
// 1. MULTI-SCHOOL SAAS & THEMES
// ==========================================

// Get all schools
app.get('/api/schools', (req, res) => {
  res.json({ success: true, schools: db.schools });
});

// Get single school by ID
app.get('/api/schools/:id', (req, res) => {
  const school = db.schools.find(s => s.id === req.params.id);
  if (!school) return res.status(404).json({ success: false, error: 'School not found' });
  res.json({ success: true, school });
});

// Register new school tenant (SaaS onboarding)
app.post('/api/schools', (req, res) => {
  const { nameAr, nameEn, city, district, phone, email, planId = 'basic', theme } = req.body;
  if (!nameAr) {
    return res.status(400).json({ success: false, error: 'School name in Arabic is required' });
  }

  const selectedPlan = saasPlans.find(p => p.id === planId) || saasPlans[0];
  const newSchool = {
    id: `sch-${Date.now().toString().slice(-6)}`,
    code: (nameEn || 'SCH').toUpperCase().replace(/\s+/g, '-').slice(0, 10),
    nameAr,
    nameEn: nameEn || nameAr,
    mottoAr: req.body.mottoAr || "معاً نحو التميز الأكاديمي",
    mottoEn: req.body.mottoEn || "Together Towards Academic Excellence",
    country: "Iraq",
    city: city || "بغداد",
    district: district || "المركز",
    phone: phone || "07700000000",
    email: email || "info@school.iq",
    foundedYear: new Date().getFullYear(),
    currency: "IQD",
    academicYear: "2025 - 2026",
    logo: req.body.logo || "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=150&auto=format&fit=crop&q=80",
    theme: theme || {
      id: "custom",
      name: "الهوية المخصصة للمدرسة",
      primary: "#0F766E",
      primaryHover: "#0D9488",
      secondary: "#D97706",
      accent: "#14B8A6",
      darkBg: "#134E4A",
      sidebarBg: "#042F2E",
      cardBorder: "#CCFBF1"
    },
    saasSubscription: {
      planId: selectedPlan.id,
      planNameAr: selectedPlan.nameAr,
      planNameEn: selectedPlan.nameEn,
      status: "active",
      cycle: "yearly",
      priceIQD: selectedPlan.priceYearlyIQD,
      studentsLimit: selectedPlan.studentsLimit,
      currentStudentsCount: 0,
      staffLimit: selectedPlan.staffLimit,
      storageGb: selectedPlan.storageGb,
      startDate: new Date().toISOString().split('T')[0],
      expiresDate: new Date(Date.now() + 365*24*60*60*1000).toISOString().split('T')[0],
      paymentGateway: "FIB"
    }
  };

  db.schools.unshift(newSchool);
  res.status(201).json({ success: true, school: newSchool });
});

// Update school visual identity & theme
app.put('/api/schools/:id/theme', (req, res) => {
  const index = db.schools.findIndex(s => s.id === req.params.id);
  if (index === -1) return res.status(404).json({ success: false, error: 'School not found' });

  const { theme, logo, nameAr, nameEn, mottoAr, mottoEn } = req.body;
  if (theme) db.schools[index].theme = { ...db.schools[index].theme, ...theme };
  if (logo) db.schools[index].logo = logo;
  if (nameAr) db.schools[index].nameAr = nameAr;
  if (nameEn) db.schools[index].nameEn = nameEn;
  if (mottoAr) db.schools[index].mottoAr = mottoAr;
  if (mottoEn) db.schools[index].mottoEn = mottoEn;

  res.json({ success: true, school: db.schools[index] });
});

// Update SaaS subscription plan
app.put('/api/schools/:id/subscription', (req, res) => {
  const index = db.schools.findIndex(s => s.id === req.params.id);
  if (index === -1) return res.status(404).json({ success: false, error: 'School not found' });

  const { planId, cycle = 'yearly', paymentGateway = 'ZainCash' } = req.body;
  const plan = saasPlans.find(p => p.id === planId);
  if (!plan) return res.status(400).json({ success: false, error: 'Invalid plan' });

  db.schools[index].saasSubscription = {
    ...db.schools[index].saasSubscription,
    planId: plan.id,
    planNameAr: plan.nameAr,
    planNameEn: plan.nameEn,
    status: "active",
    cycle,
    priceIQD: cycle === 'yearly' ? plan.priceYearlyIQD : plan.priceMonthlyIQD,
    studentsLimit: plan.studentsLimit,
    staffLimit: plan.staffLimit,
    storageGb: plan.storageGb,
    paymentGateway,
    expiresDate: new Date(Date.now() + (cycle === 'yearly' ? 365 : 30)*24*60*60*1000).toISOString().split('T')[0]
  };

  res.json({ success: true, subscription: db.schools[index].saasSubscription });
});

// Get SaaS plans
app.get('/api/saas/plans', (req, res) => {
  res.json({ success: true, plans: saasPlans });
});

// ==========================================
// 2. STUDENTS (SIS / Administrator's Plus)
// ==========================================

// Get students for a school
app.get('/api/schools/:schoolId/students', (req, res) => {
  const schoolStudents = db.students.filter(s => s.schoolId === req.params.schoolId);
  res.json({ success: true, count: schoolStudents.length, students: schoolStudents });
});

// Create single student
app.post('/api/schools/:schoolId/students', (req, res) => {
  const studentData = req.body;
  const newStudent = {
    id: `stu-${Date.now()}`,
    schoolId: req.params.schoolId,
    studentId: studentData.studentId || `STU-2026-${Math.floor(100 + Math.random() * 900)}`,
    fullNameAr: studentData.fullNameAr || "طالب جديد",
    fullNameEn: studentData.fullNameEn || "New Student",
    nationalId: studentData.nationalId || `199${Math.floor(100000000 + Math.random() * 900000000)}`,
    gender: studentData.gender || "ذكر",
    birthDate: studentData.birthDate || "2010-01-01",
    gradeLevel: studentData.gradeLevel || "الرابع العلمي",
    gradeLevelEn: studentData.gradeLevelEn || "Grade 10",
    section: studentData.section || "أ",
    guardianName: studentData.guardianName || "",
    guardianPhone: studentData.guardianPhone || "",
    guardianEmail: studentData.guardianEmail || "",
    address: studentData.address || "بغداد",
    bloodType: studentData.bloodType || "O+",
    medicalNotes: studentData.medicalNotes || "سليم",
    enrollmentDate: new Date().toISOString().split('T')[0],
    status: studentData.status || "منتظم",
    gpa: studentData.gpa || 0,
    attendanceRate: 100,
    tuitionTotal: studentData.tuitionTotal || 2500000,
    tuitionPaid: studentData.tuitionPaid || 0,
    tuitionBalance: (studentData.tuitionTotal || 2500000) - (studentData.tuitionPaid || 0),
    tuitionStatus: (studentData.tuitionPaid || 0) > 0 ? "جزئي" : "غير مدفوع"
  };

  db.students.unshift(newStudent);
  res.status(201).json({ success: true, student: newStudent });
});

// Bulk Import Students (via CSV or JSON)
app.post('/api/schools/:schoolId/students/bulk', (req, res) => {
  const { studentsList, csvString } = req.body;
  let parsed = [];

  if (csvString) {
    try {
      parsed = parseCsvString(csvString);
    } catch (err) {
      return res.status(400).json({ success: false, error: 'CSV parsing error: ' + err.message });
    }
  } else if (Array.isArray(studentsList)) {
    parsed = studentsList;
  } else {
    return res.status(400).json({ success: false, error: 'No student data provided' });
  }

  const addedStudents = parsed.map((item, index) => {
    return {
      id: `stu-${Date.now()}-${index}`,
      schoolId: req.params.schoolId,
      studentId: item.studentId || item.رقم_القيد || `STU-2026-${Math.floor(100 + Math.random() * 900)}`,
      fullNameAr: item.fullNameAr || item.الاسم_الرباعي_عربي || "طالب مستورد",
      fullNameEn: item.fullNameEn || item.الاسم_انجليزي || "Imported Student",
      nationalId: item.nationalId || item.الرقم_الوطني || "199000000000",
      gender: item.gender || item.الجنس || "ذكر",
      birthDate: item.birthDate || item.تاريخ_الميلاد || "2010-01-01",
      gradeLevel: item.gradeLevel || item.المرحلة_الدراسية || "الرابع العلمي",
      gradeLevelEn: item.gradeLevelEn || "Grade 10",
      section: item.section || item.الشعبة || "أ",
      guardianName: item.guardianName || item.اسم_ولي_الأمر || "",
      guardianPhone: item.guardianPhone || item.هاتف_ولي_الأمر || "",
      guardianEmail: item.guardianEmail || item.البريد_الإلكتروني || "",
      address: item.address || item.العنوان || "العراق",
      bloodType: item.bloodType || item.فصيلة_الدم || "O+",
      medicalNotes: item.medicalNotes || "سليم",
      enrollmentDate: new Date().toISOString().split('T')[0],
      status: "منتظم",
      gpa: Number(item.gpa || item.المعدل || 0),
      attendanceRate: 100,
      tuitionTotal: Number(item.tuitionTotal || item.القسط_الكلي || 2500000),
      tuitionPaid: Number(item.tuitionPaid || 0),
      tuitionBalance: Number(item.tuitionTotal || item.القسط_الكلي || 2500000) - Number(item.tuitionPaid || 0),
      tuitionStatus: Number(item.tuitionPaid || 0) > 0 ? "جزئي" : "غير مدفوع"
    };
  });

  db.students.push(...addedStudents);
  res.json({
    success: true,
    messageAr: `تم استيراد ${addedStudents.length} طالب بنجاح`,
    messageEn: `Successfully imported ${addedStudents.length} students`,
    count: addedStudents.length,
    imported: addedStudents
  });
});

// Export Students as CSV
app.get('/api/schools/:schoolId/students/export-csv', (req, res) => {
  const lang = req.query.lang || 'ar';
  const schoolStudents = db.students.filter(s => s.schoolId === req.params.schoolId);

  const formattedData = schoolStudents.map(s => {
    if (lang === 'ar') {
      return {
        "رقم_القيد": s.studentId,
        "الاسم_الرباعي_عربي": s.fullNameAr,
        "الاسم_انجليزي": s.fullNameEn,
        "الرقم_الوطني": s.nationalId,
        "الجنس": s.gender,
        "تاريخ_الميلاد": s.birthDate,
        "المرحلة_الدراسية": s.gradeLevel,
        "الشعبة": s.section,
        "اسم_ولي_الأمر": s.guardianName,
        "هاتف_ولي_الأمر": s.guardianPhone,
        "البريد_الإلكتروني": s.guardianEmail,
        "العنوان": s.address,
        "فصيلة_الدم": s.bloodType,
        "الحالة": s.status,
        "المعدل": s.gpa,
        "نسبة_الحضور": `${s.attendanceRate}%`,
        "القسط_الكلي": s.tuitionTotal,
        "المدفوع": s.tuitionPaid,
        "المتبقي": s.tuitionBalance,
        "حالة_السداد": s.tuitionStatus
      };
    } else {
      return {
        studentId: s.studentId,
        fullNameAr: s.fullNameAr,
        fullNameEn: s.fullNameEn,
        nationalId: s.nationalId,
        gender: s.gender,
        birthDate: s.birthDate,
        gradeLevel: s.gradeLevel,
        section: s.section,
        guardianName: s.guardianName,
        guardianPhone: s.guardianPhone,
        guardianEmail: s.guardianEmail,
        address: s.address,
        bloodType: s.bloodType,
        status: s.status,
        gpa: s.gpa,
        attendanceRate: `${s.attendanceRate}%`,
        tuitionTotal: s.tuitionTotal,
        tuitionPaid: s.tuitionPaid,
        tuitionBalance: s.tuitionBalance,
        tuitionStatus: s.tuitionStatus
      };
    }
  });

  const csv = generateCsvString(formattedData, lang);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="students-${req.params.schoolId}-${lang}.csv"`);
  res.send(csv);
});

// ==========================================
// 3. STAFF & TEACHERS (Rediker Faculty)
// ==========================================

app.get('/api/schools/:schoolId/staff', (req, res) => {
  const staff = db.staff.filter(s => s.schoolId === req.params.schoolId);
  res.json({ success: true, count: staff.length, staff });
});

app.post('/api/schools/:schoolId/staff/bulk', (req, res) => {
  const { staffList, csvString } = req.body;
  let parsed = [];
  if (csvString) parsed = parseCsvString(csvString);
  else if (Array.isArray(staffList)) parsed = staffList;

  const addedStaff = parsed.map((item, i) => ({
    id: `stf-${Date.now()}-${i}`,
    schoolId: req.params.schoolId,
    staffId: item.staffId || item.الرقم_الوظيفي || `TCH-${Math.floor(200 + Math.random() * 800)}`,
    fullNameAr: item.fullNameAr || item.الاسم_الرباعي_عربي || "عضو كادر جديد",
    fullNameEn: item.fullNameEn || item.الاسم_انجليزي || "New Faculty Member",
    role: item.role || item.المسمى_الوظيفي || "أستاذ مادة",
    roleEn: item.roleEn || "Teacher",
    department: item.department || item.القسم || "العلوم",
    departmentEn: item.departmentEn || "Sciences",
    email: item.email || item.البريد_الإلكتروني || "teacher@school.iq",
    phone: item.phone || item.رقم_الهاتف || "07700000000",
    qualification: item.qualification || item.المؤهل_العلمي || "بكالوريوس",
    qualificationEn: item.qualificationEn || "B.Sc.",
    salaryIQD: Number(item.salaryIQD || item.الراتب_الشهري_دينار || 1500000),
    subjectsTaught: item.subjectsTaught ? (Array.isArray(item.subjectsTaught) ? item.subjectsTaught : [item.subjectsTaught]) : ["المادة المقررة"],
    classesAssigned: ["الرابع العلمي أ"],
    status: "على رأس العمل",
    joinDate: new Date().toISOString().split('T')[0]
  }));

  db.staff.push(...addedStaff);
  res.json({ success: true, count: addedStaff.length, imported: addedStaff });
});

app.get('/api/schools/:schoolId/staff/export-csv', (req, res) => {
  const staff = db.staff.filter(s => s.schoolId === req.params.schoolId);
  const formatted = staff.map(st => ({
    "الرقم_الوظيفي": st.staffId,
    "الاسم_الرباعي_عربي": st.fullNameAr,
    "الاسم_انجليزي": st.fullNameEn,
    "المسمى_الوظيفي": st.role,
    "القسم": st.department,
    "البريد_الإلكتروني": st.email,
    "رقم_الهاتف": st.phone,
    "المؤهل_العلمي": st.qualification,
    "الراتب_الشهري_دينار": st.salaryIQD,
    "المواد_المعينة": st.subjectsTaught.join(', '),
    "الحالة": st.status
  }));

  const csv = generateCsvString(formatted, 'ar');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="staff-${req.params.schoolId}.csv"`);
  res.send(csv);
});

// ==========================================
// 4. CLASSES & TIMETABLE (Master Schedule)
// ==========================================

app.get('/api/schools/:schoolId/classes', (req, res) => {
  const classes = db.classes.filter(c => c.schoolId === req.params.schoolId);
  res.json({ success: true, count: classes.length, classes });
});

app.post('/api/schools/:schoolId/classes/bulk', (req, res) => {
  const { classesList, csvString } = req.body;
  let parsed = [];
  if (csvString) parsed = parseCsvString(csvString);
  else if (Array.isArray(classesList)) parsed = classesList;

  const added = parsed.map((item, i) => ({
    id: `cls-${Date.now()}-${i}`,
    schoolId: req.params.schoolId,
    code: item.code || item.رمز_الصف || `CLS-${i+1}`,
    nameAr: item.nameAr || item.اسم_الصف_عربي || "صف دراسي",
    nameEn: item.nameEn || item.اسم_الصف_انجليزي || "Class Room",
    gradeLevel: item.gradeLevel || item.المرحلة || "الرابع العلمي",
    section: item.section || item.الشعبة || "أ",
    roomNumber: item.roomNumber || item.رقم_القاعة || "قاعة 101",
    homeroomTeacher: item.homeroomTeacher || item.مربي_الصف || "د. حسين كريم",
    studentCount: 30,
    maxCapacity: Number(item.maxCapacity || item.السعة_القصوى || 35),
    academicTerm: "الفصل الدراسي الأول",
    weeklyPeriods: 35
  }));

  db.classes.push(...added);
  res.json({ success: true, count: added.length, imported: added });
});

app.get('/api/schools/:schoolId/classes/export-csv', (req, res) => {
  const classes = db.classes.filter(c => c.schoolId === req.params.schoolId);
  const formatted = classes.map(c => ({
    "رمز_الصف": c.code,
    "اسم_الصف_عربي": c.nameAr,
    "اسم_الصف_انجليزي": c.nameEn,
    "المرحلة": c.gradeLevel,
    "الشعبة": c.section,
    "رقم_القاعة": c.roomNumber,
    "مربي_الصف": c.homeroomTeacher,
    "عدد_الطلاب": c.studentCount,
    "السعة_القصوى": c.maxCapacity
  }));

  const csv = generateCsvString(formatted, 'ar');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="classes-${req.params.schoolId}.csv"`);
  res.send(csv);
});

// ==========================================
// 5. GRADEBOOK & REPORT CARDS (TeacherPlus)
// ==========================================

app.get('/api/schools/:schoolId/grades', (req, res) => {
  const grades = db.grades.filter(g => g.schoolId === req.params.schoolId);
  res.json({ success: true, count: grades.length, grades });
});

app.post('/api/schools/:schoolId/grades/bulk', (req, res) => {
  const { gradesList, csvString } = req.body;
  let parsed = [];
  if (csvString) parsed = parseCsvString(csvString);
  else if (Array.isArray(gradesList)) parsed = gradesList;

  const added = parsed.map((item, i) => {
    const daily = Number(item.dailyActivities || item.النشاط_اليومي_20 || 18);
    const mid = Number(item.midtermExam || item.امتحان_شهري_30 || 27);
    const quiz = Number(item.quizzes || item.اختبارات_قصيرة_10 || 9);
    const fin = Number(item.finalExam || item.الامتحان_النهائي_40 || 36);
    const total = daily + mid + quiz + fin;

    let letter = 'A';
    if (total >= 90) letter = 'A+';
    else if (total >= 80) letter = 'B+';
    else if (total >= 70) letter = 'C+';
    else if (total >= 50) letter = 'D';
    else letter = 'F';

    return {
      id: `grd-${Date.now()}-${i}`,
      schoolId: req.params.schoolId,
      studentId: item.studentId || item.رقم_الطالب || "STU-2026-001",
      studentNameAr: item.studentNameAr || item.اسم_الطالب || "طالب",
      studentNameEn: item.studentNameEn || "Student",
      classCode: item.classCode || item.رمز_المادة || "MATH-101",
      subjectNameAr: item.subjectNameAr || item.المادة_عربي || "الرياضيات",
      subjectNameEn: item.subjectNameEn || item.المادة_انجليزي || "Mathematics",
      teacherNameAr: item.teacherNameAr || "أستاذ المادة",
      term: item.term || item.الفصل || "الفصل الدراسي الأول",
      dailyActivities: daily,
      midtermExam: mid,
      quizzes: quiz,
      finalExam: fin,
      totalScore: total,
      letterGrade: letter,
      gpaScore: (total / 25).toFixed(1),
      status: total >= 50 ? "ناجح" : "راسب",
      statusEn: total >= 50 ? "Pass" : "Fail",
      remarks: item.remarks || "درجة مدخلة عبر الاستيراد الجماعي"
    };
  });

  db.grades.push(...added);
  res.json({ success: true, count: added.length, imported: added });
});

app.get('/api/schools/:schoolId/grades/export-csv', (req, res) => {
  const grades = db.grades.filter(g => g.schoolId === req.params.schoolId);
  const formatted = grades.map(g => ({
    "رقم_الطالب": g.studentId,
    "اسم_الطالب": g.studentNameAr,
    "رمز_المادة": g.classCode,
    "المادة_عربي": g.subjectNameAr,
    "المادة_انجليزي": g.subjectNameEn,
    "الفصل": g.term,
    "النشاط_اليومي_20": g.dailyActivities,
    "امتحان_شهري_30": g.midtermExam,
    "اختبارات_قصيرة_10": g.quizzes,
    "الامتحان_النهائي_40": g.finalExam,
    "المجموع_100": g.totalScore,
    "التقدير": g.letterGrade,
    "الحالة": g.status
  }));

  const csv = generateCsvString(formatted, 'ar');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="grades-${req.params.schoolId}.csv"`);
  res.send(csv);
});

// ==========================================
// 6. ATTENDANCE (Daily & Period)
// ==========================================

app.get('/api/schools/:schoolId/attendance', (req, res) => {
  const attendance = db.attendance.filter(a => a.schoolId === req.params.schoolId);
  res.json({ success: true, count: attendance.length, attendance });
});

app.post('/api/schools/:schoolId/attendance/bulk', (req, res) => {
  const { attendanceList, csvString } = req.body;
  let parsed = [];
  if (csvString) parsed = parseCsvString(csvString);
  else if (Array.isArray(attendanceList)) parsed = attendanceList;

  const added = parsed.map((item, i) => ({
    id: `att-${Date.now()}-${i}`,
    schoolId: req.params.schoolId,
    date: item.date || item.التاريخ || new Date().toISOString().split('T')[0],
    studentId: item.studentId || item.رقم_الطالب || "STU-2026-001",
    studentNameAr: item.studentNameAr || item.اسم_الطالب || "طالب",
    classCode: item.classCode || item.رمز_الصف || "G10-SCI-A",
    status: item.status || item.الحالة || "حاضر",
    statusEn: item.status === "حاضر" ? "Present" : (item.status === "غائب" ? "Absent" : "Late"),
    checkInTime: item.checkInTime || item.وقت_الحضور || "07:45 AM",
    notes: item.notes || item.ملاحظات_الغياب || ""
  }));

  db.attendance.push(...added);
  res.json({ success: true, count: added.length, imported: added });
});

app.get('/api/schools/:schoolId/attendance/export-csv', (req, res) => {
  const attendance = db.attendance.filter(a => a.schoolId === req.params.schoolId);
  const formatted = attendance.map(a => ({
    "التاريخ": a.date,
    "رقم_الطالب": a.studentId,
    "اسم_الطالب": a.studentNameAr,
    "رمز_الصف": a.classCode,
    "الحالة": a.status,
    "وقت_الحضور": a.checkInTime,
    "ملاحظات_الغياب": a.notes
  }));

  const csv = generateCsvString(formatted, 'ar');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="attendance-${req.params.schoolId}.csv"`);
  res.send(csv);
});

// ==========================================
// 7. BILLING & INVOICES (Student Billing & Iraqi Gateways)
// ==========================================

app.get('/api/schools/:schoolId/invoices', (req, res) => {
  const invoices = db.invoices.filter(inv => inv.schoolId === req.params.schoolId);
  res.json({ success: true, count: invoices.length, invoices });
});

app.post('/api/schools/:schoolId/invoices/bulk', (req, res) => {
  const { invoicesList, csvString } = req.body;
  let parsed = [];
  if (csvString) parsed = parseCsvString(csvString);
  else if (Array.isArray(invoicesList)) parsed = invoicesList;

  const added = parsed.map((item, i) => {
    const total = Number(item.amountIQD || item.المبلغ_الكلي_دينار || 2500000);
    const paid = Number(item.paidAmountIQD || item.المدفوع_دينار || 0);
    const rem = total - paid;
    return {
      id: `inv-${Date.now()}-${i}`,
      schoolId: req.params.schoolId,
      invoiceNumber: item.invoiceNumber || item.رقم_الفاتورة || `INV-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      studentId: item.studentId || item.رقم_الطالب || "STU-2026-001",
      studentNameAr: item.studentNameAr || item.اسم_الطالب || "طالب",
      gradeLevel: item.gradeLevel || item.المرحلة || "الرابع العلمي",
      feeCategory: item.feeCategory || item.نوع_القسط || "القسط الدراسي السنوي",
      amountIQD: total,
      paidAmountIQD: paid,
      remainingAmountIQD: rem,
      dueDate: item.dueDate || item.تاريخ_الاستحقاق || "2026-01-15",
      issueDate: new Date().toISOString().split('T')[0],
      status: rem === 0 ? "مدفوع بالكامل" : (paid > 0 ? "مدفوع جزئياً" : "مستحق الدفع"),
      statusEn: rem === 0 ? "Paid" : (paid > 0 ? "Partially Paid" : "Due"),
      paymentMethod: item.paymentMethod || item.بوابة_الدفع || "ZainCash",
      paymentGatewayName: "زين كاش العراق",
      transactionRef: "",
      receiptNumber: "",
      guardianPhone: "07701234567"
    };
  });

  db.invoices.push(...added);
  res.json({ success: true, count: added.length, imported: added });
});

app.get('/api/schools/:schoolId/invoices/export-csv', (req, res) => {
  const invoices = db.invoices.filter(i => i.schoolId === req.params.schoolId);
  const formatted = invoices.map(inv => ({
    "رقم_الفاتورة": inv.invoiceNumber,
    "رقم_الطالب": inv.studentId,
    "اسم_الطالب": inv.studentNameAr,
    "المرحلة": inv.gradeLevel,
    "نوع_القسط": inv.feeCategory,
    "المبلغ_الكلي_دينار": inv.amountIQD,
    "المدفوع_دينار": inv.paidAmountIQD,
    "المتبقي_دينار": inv.remainingAmountIQD,
    "تاريخ_الاستحقاق": inv.dueDate,
    "حالة_السداد": inv.status,
    "بوابة_الدفع": inv.paymentMethod,
    "رقم_الوصل": inv.receiptNumber || "-",
    "رمز_العملية": inv.transactionRef || "-"
  }));

  const csv = generateCsvString(formatted, 'ar');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="invoices-${req.params.schoolId}.csv"`);
  res.send(csv);
});

// ==========================================
// 8. IRAQI PAYMENT GATEWAY CHECKOUT & RECEIPTS
// ==========================================

// Get Iraqi Payment Gateways Info
app.get('/api/payments/gateways', (req, res) => {
  res.json({ success: true, gateways: iraqiPaymentGatewaysInfo });
});

// Initiate Payment (QiCard, ZainCash, FIB, AsiaPay)
app.post('/api/payments/initiate', async (req, res) => {
  try {
    const result = await IraqiPaymentService.initiatePayment(req.body);
    res.json(result);
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// Confirm Payment & Issue Official Receipt
app.post('/api/payments/confirm', async (req, res) => {
  try {
    const { invoiceId, schoolId, transactionId, gateway, pinOrOtp, cardDetails, phoneNumber } = req.body;
    const confirmResult = await IraqiPaymentService.confirmPayment({
      transactionId,
      gateway,
      pinOrOtp,
      cardDetails,
      phoneNumber
    });

    // Update invoice status if invoiceId is provided
    if (invoiceId) {
      const invIndex = db.invoices.findIndex(i => i.id === invoiceId || i.invoiceNumber === invoiceId);
      if (invIndex !== -1) {
        const inv = db.invoices[invIndex];
        inv.paidAmountIQD = inv.amountIQD;
        inv.remainingAmountIQD = 0;
        inv.status = "مدفوع بالكامل";
        inv.statusEn = "Paid";
        inv.paymentMethod = gateway;
        inv.transactionRef = confirmResult.transactionId;
        inv.receiptNumber = confirmResult.receiptNumber;
        inv.paidDate = confirmResult.paidDate;

        // Also update student's tuition balance
        const stuIndex = db.students.findIndex(s => s.studentId === inv.studentId);
        if (stuIndex !== -1) {
          db.students[stuIndex].tuitionPaid = db.students[stuIndex].tuitionTotal;
          db.students[stuIndex].tuitionBalance = 0;
          db.students[stuIndex].tuitionStatus = "مدفوع";
        }
      }
    }

    db.transactions.unshift({
      ...confirmResult,
      schoolId,
      invoiceId,
      timestamp: new Date().toISOString()
    });

    res.json(confirmResult);
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// ==========================================
// 9. CSV TEMPLATES & BULK EXPORT ALL
// ==========================================

// Get template for any section
app.get('/api/templates/csv/:section', (req, res) => {
  const { section } = req.params;
  const lang = req.query.lang || 'ar';
  const template = CSV_TEMPLATES[section];

  if (!template) {
    return res.status(404).json({ success: false, error: `No CSV template for section: ${section}` });
  }

  const headers = lang === 'ar' ? template.headersAr : template.headersEn;
  const sampleData = [headers, ...(template.sampleRowsAr || [])];
  const csv = generateCsvString(sampleData, lang);

  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="template-${section}-${lang}.csv"`);
  res.send(csv);
});

// Full School Backup / Consolidated Export
app.get('/api/schools/:schoolId/export-all', (req, res) => {
  const schoolId = req.params.schoolId;
  const school = db.schools.find(s => s.id === schoolId);
  const students = db.students.filter(s => s.schoolId === schoolId);
  const staff = db.staff.filter(s => s.schoolId === schoolId);
  const classes = db.classes.filter(c => c.schoolId === schoolId);
  const grades = db.grades.filter(g => g.schoolId === schoolId);
  const attendance = db.attendance.filter(a => a.schoolId === schoolId);
  const invoices = db.invoices.filter(i => i.schoolId === schoolId);

  res.json({
    success: true,
    exportedAt: new Date().toISOString(),
    school,
    counts: {
      students: students.length,
      staff: staff.length,
      classes: classes.length,
      grades: grades.length,
      attendance: attendance.length,
      invoices: invoices.length
    },
    data: {
      students,
      staff,
      classes,
      grades,
      attendance,
      invoices
    }
  });
});

// SPA Fallback for client-side routing when accessed on a domain (Express 5 compatible)
if (fs.existsSync(distPath)) {
  app.use((req, res, next) => {
    if (req.method === 'GET' && !req.path.startsWith('/api')) {
      return res.sendFile(path.join(distPath, 'index.html'));
    }
    next();
  });
}

app.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`🚀 Rediker School Management SaaS Backend Running!`);
  console.log(`🌐 Port: http://localhost:${PORT}`);
  console.log(`🇮🇶 Iraqi Payment Gateways: QiCard, ZainCash, FIB, AsiaPay`);
  console.log(`📂 Multi-Tenant Schools, Theming & Universal CSV Active`);
  console.log(`====================================================`);
});
