import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  Building2, 
  Globe2, 
  UserCheck, 
  Palette, 
  DownloadCloud, 
  ChevronDown, 
  ShieldCheck, 
  Sparkles,
  School
} from 'lucide-react';
import { exportDataToCsv } from '../services/csvExportImport';

export function Header({ onOpenThemeModal }) {
  const { 
    schools, 
    currentSchool, 
    switchSchool, 
    role, 
    setRole, 
    students,
    staff,
    classes,
    invoices,
    showToast 
  } = useSchool();
  
  const { lang, toggleLanguage, t, isRTL } = useLanguage();
  const [showSchoolDropdown, setShowSchoolDropdown] = useState(false);
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);

  // Quick download full school data pack
  const handleDownloadAllData = () => {
    const summaryData = [
      {
        "المدرسة": currentSchool.nameAr,
        "الكود": currentSchool.code,
        "المحافظة": currentSchool.city,
        "عدد_الطلاب": students.length,
        "عدد_الكادر": staff.length,
        "عدد_الشعب": classes.length,
        "عدد_الفواتير": invoices.length,
        "تاريخ_التصدير": new Date().toISOString()
      }
    ];
    exportDataToCsv(summaryData, `${currentSchool.code}-full-backup.csv`);
    showToast(isRTL ? "تم تصدير ملف بيانات المدرسة المجمع بنجاح" : "Full school backup exported successfully");
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-sm transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* School Brand & Logo */}
          <div className="flex items-center gap-4">
            <div className="relative group cursor-pointer" onClick={onOpenThemeModal} title={t('brandingTheme')}>
              <img 
                src={currentSchool.logo} 
                alt={currentSchool.nameAr}
                className="w-13 h-13 rounded-2xl object-cover ring-2 ring-slate-100 shadow-md group-hover:scale-105 transition-transform"
                style={{ borderColor: currentSchool.theme?.primary }}
              />
              <span 
                className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full ring-2 ring-white"
                style={{ backgroundColor: currentSchool.theme?.primary || '#0F766E' }}
                title="Active Theme Color"
              />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-lg sm:text-xl text-slate-900 tracking-tight flex items-center gap-2">
                  {lang === 'ar' ? currentSchool.nameAr : currentSchool.nameEn}
                </h1>
                <span 
                  className="hidden md:inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold text-white shadow-xs"
                  style={{ backgroundColor: currentSchool.theme?.primary || '#0F766E' }}
                >
                  {currentSchool.saasSubscription?.planNameAr?.split(' ')[0] || 'SaaS'}
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium hidden sm:block">
                {lang === 'ar' ? currentSchool.mottoAr : currentSchool.mottoEn}
              </p>
            </div>
          </div>

          {/* Controls: School Switcher, Role, Language, Quick Theme, Backup */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Multi-School Switcher Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => { setShowSchoolDropdown(!showSchoolDropdown); setShowRoleDropdown(false); }}
                className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 transition-colors border border-slate-200"
              >
                <Building2 className="w-4 h-4 text-slate-600" />
                <span className="hidden md:inline">{t('switchSchool')}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
              </button>

              {showSchoolDropdown && (
                <div 
                  className={`absolute ${isRTL ? 'left-0' : 'right-0'} mt-2 w-72 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-150`}
                >
                  <div className="px-4 py-2 border-b border-slate-100">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">{t('allSchools')}</p>
                  </div>
                  <div className="max-h-64 overflow-y-auto py-1">
                    {schools.map(school => (
                      <button
                        key={school.id}
                        onClick={() => {
                          switchSchool(school.id);
                          setShowSchoolDropdown(false);
                        }}
                        className={`w-full text-start px-4 py-2.5 flex items-center justify-between hover:bg-slate-50 transition-colors ${
                          school.id === currentSchool.id ? 'bg-emerald-50/70 font-bold' : ''
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <img src={school.logo} alt="" className="w-7 h-7 rounded-lg object-cover" />
                          <div>
                            <p className="text-xs text-slate-900">{lang === 'ar' ? school.nameAr : school.nameEn}</p>
                            <p className="text-[10px] text-slate-500">{school.city} • {school.saasSubscription?.planNameAr}</p>
                          </div>
                        </div>
                        {school.id === currentSchool.id && (
                          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: school.theme?.primary }} />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Role Switcher */}
            <div className="relative hidden lg:block">
              <button
                type="button"
                onClick={() => { setShowRoleDropdown(!showRoleDropdown); setShowSchoolDropdown(false); }}
                className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 transition-colors border border-slate-200"
              >
                <UserCheck className="w-4 h-4 text-emerald-600" />
                <span>
                  {role === 'admin' ? t('roleAdmin') : (role === 'superadmin' ? t('roleSuperAdmin') : (role === 'teacher' ? t('roleTeacher') : t('roleParent')))}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
              </button>

              {showRoleDropdown && (
                <div 
                  className={`absolute ${isRTL ? 'left-0' : 'right-0'} mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50`}
                >
                  {[
                    { id: 'admin', label: t('roleAdmin') },
                    { id: 'superadmin', label: t('roleSuperAdmin') },
                    { id: 'teacher', label: t('roleTeacher') },
                    { id: 'parent', label: t('roleParent') }
                  ].map(r => (
                    <button
                      key={r.id}
                      onClick={() => { setRole(r.id); setShowRoleDropdown(false); }}
                      className={`w-full text-start px-4 py-2 text-xs hover:bg-slate-50 ${role === r.id ? 'font-bold text-emerald-700 bg-emerald-50' : 'text-slate-700'}`}
                    >
                      {r.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Branding & Theme Customizer Button */}
            <button
              type="button"
              onClick={onOpenThemeModal}
              title={t('brandingTheme')}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-white shadow-xs transition-transform active:scale-95"
              style={{ backgroundColor: currentSchool.theme?.primary || '#0F766E' }}
            >
              <Palette className="w-4 h-4" />
              <span className="hidden sm:inline">{t('brandingTheme')}</span>
            </button>

            {/* Download Full Backup CSV */}
            <button
              type="button"
              onClick={handleDownloadAllData}
              title={t('downloadAllData')}
              className="p-2 sm:px-3 sm:py-2 rounded-xl text-xs font-semibold bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100 transition-colors flex items-center gap-1.5"
            >
              <DownloadCloud className="w-4 h-4 text-amber-700" />
              <span className="hidden md:inline">CSV Backup</span>
            </button>

            {/* Language Toggle Button (Arabic Primary / English) */}
            <button
              type="button"
              onClick={toggleLanguage}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border border-slate-300 bg-white hover:bg-slate-100 text-slate-800 transition-colors shadow-xs"
              title="تغيير اللغة / Change Language"
            >
              <Globe2 className="w-4 h-4 text-blue-600" />
              <span>{lang === 'ar' ? 'English' : 'العربية'}</span>
            </button>

          </div>

        </div>
      </div>
    </header>
  );
}
