import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  CreditCard, 
  Search, 
  UploadCloud, 
  DownloadCloud, 
  Plus, 
  Printer, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  Smartphone,
  QrCode,
  Zap
} from 'lucide-react';
import { exportDataToCsv } from '../services/csvExportImport';

export function Billing({ onOpenCsvModal, onOpenPaymentModal, onOpenReceiptModal }) {
  const { currentSchool, invoices, showToast } = useSchool();
  const { t, lang, isRTL } = useLanguage();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filteredInvoices = invoices.filter(inv => {
    const matchesSearch = 
      (inv.studentNameAr && inv.studentNameAr.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (inv.invoiceNumber && inv.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (inv.studentId && inv.studentId.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || inv.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const totalInvoiced = invoices.reduce((acc, i) => acc + (i.amountIQD || 0), 0);
  const totalPaid = invoices.reduce((acc, i) => acc + (i.paidAmountIQD || 0), 0);
  const totalRemaining = invoices.reduce((acc, i) => acc + (i.remainingAmountIQD || 0), 0);

  const handleExportCsv = () => {
    const formatted = filteredInvoices.map(inv => ({
      "رقم_الفاتورة": inv.invoiceNumber,
      "رقم_الطالب": inv.studentId,
      "اسم_الطالب": inv.studentNameAr,
      "المرحلة": inv.gradeLevel,
      "نوع_القسط": inv.feeCategory,
      "المبلغ_الكلي_دينار": inv.amountIQD,
      "المدفوع_دينار": inv.paidAmountIQD,
      "المتبقي_دينار": inv.remainingAmountIQD,
      "تاريخ_الاستحقاق": inv.dueDate,
      "حالة_السداد": inv.status,
      "بوابة_الدفع": inv.paymentMethod,
      "رقم_الوصل": inv.receiptNumber || "-",
      "رمز_العملية": inv.transactionRef || "-"
    }));

    exportDataToCsv(formatted, `invoices-${currentSchool.code}.csv`);
    showToast(isRTL ? 'تم تصدير ملف الفواتير والأقساط CSV بنجاح' : 'Invoices CSV exported successfully');
  };

  const primaryColor = currentSchool.theme?.primary || '#0F766E';

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center">
            <CreditCard className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              {t('billingTitle')} (Student Billing)
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              إدارة الأقساط المدرسية وبوابات الدفع الإلكترونية العراقية المعتمدة • {currentSchool.nameAr}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => onOpenCsvModal('invoices')}
            className="px-3.5 py-2.5 rounded-xl border border-amber-200 bg-amber-50 text-amber-900 text-xs font-bold hover:bg-amber-100 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <UploadCloud className="w-4 h-4 text-amber-700" />
            <span>استيراد فواتير (CSV)</span>
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-800 text-xs font-bold hover:bg-slate-50 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <DownloadCloud className="w-4 h-4 text-slate-600" />
            <span>{t('exportCsv')}</span>
          </button>
        </div>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-xs">
          <span className="text-xs font-bold text-slate-500">إجمالي الأقساط المطالب بها</span>
          <p className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
            {totalInvoiced.toLocaleString()} <span className="text-xs font-bold">{t('iqd')}</span>
          </p>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-xs">
          <span className="text-xs font-bold text-slate-500">إجمالي المبالغ المحصلة</span>
          <p className="text-xl sm:text-2xl font-black text-emerald-600 mt-2">
            {totalPaid.toLocaleString()} <span className="text-xs font-bold">{t('iqd')}</span>
          </p>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200/90 shadow-xs">
          <span className="text-xs font-bold text-slate-500">المبالغ المتبقية بذمة الطلاب</span>
          <p className="text-xl sm:text-2xl font-black text-rose-600 mt-2">
            {totalRemaining.toLocaleString()} <span className="text-xs font-bold">{t('iqd')}</span>
          </p>
        </div>
      </div>

      {/* Iraqi Gateways Banner */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-md">
        <div className="space-y-1">
          <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider block">
            بوابات الدفع الإلكتروني العراقية المتصلة مباشرة
          </span>
          <p className="text-xs text-white/90 font-medium">
            ادفع الآن بأمان عبر: زين كاش العراق • بطاقة كي كارد العالمية • مصرف العراق الأول FIB • محفظة آسيا باي
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-xl bg-white/10 text-white text-xs font-bold flex items-center gap-1.5 backdrop-blur-md">
            <Smartphone className="w-3.5 h-3.5 text-rose-400" />
            <span>زين كاش</span>
          </span>
          <span className="px-3 py-1 rounded-xl bg-white/10 text-white text-xs font-bold flex items-center gap-1.5 backdrop-blur-md">
            <CreditCard className="w-3.5 h-3.5 text-blue-400" />
            <span>كي كارد</span>
          </span>
          <span className="px-3 py-1 rounded-xl bg-white/10 text-white text-xs font-bold flex items-center gap-1.5 backdrop-blur-md">
            <QrCode className="w-3.5 h-3.5 text-teal-400" />
            <span>FIB QR</span>
          </span>
          <span className="px-3 py-1 rounded-xl bg-white/10 text-white text-xs font-bold flex items-center gap-1.5 backdrop-blur-md">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>آسيا باي</span>
          </span>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute top-1/2 -translate-y-1/2 text-slate-400 right-3" />
          <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث برقم الفاتورة أو اسم الطالب..."
            className="w-full pr-9 pl-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 bg-slate-50 focus:bg-white"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-700 font-semibold focus:outline-none"
        >
          <option value="all">كافة حالات السداد</option>
          <option value="مدفوع بالكامل">مدفوع بالكامل</option>
          <option value="مدفوع جزئياً">مدفوع جزئياً</option>
          <option value="مستحق الدفع">مستحق الدفع</option>
        </select>
      </div>

      {/* Invoices Table */}
      <div className="bg-white rounded-3xl border border-slate-200/90 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-start text-xs">
            <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
              <tr>
                <th className="p-3.5 text-start">{t('invoiceNumber')}</th>
                <th className="p-3.5 text-start">{t('studentName')}</th>
                <th className="p-3.5 text-start">{t('feeCategory')}</th>
                <th className="p-3.5 text-center">{t('totalAmount')}</th>
                <th className="p-3.5 text-center">{t('paidAmount')}</th>
                <th className="p-3.5 text-center">{t('remainingAmount')}</th>
                <th className="p-3.5 text-center">{t('status')}</th>
                <th className="p-3.5 text-center">إجراءات الدفع والوصل</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredInvoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="p-3.5 font-mono font-bold text-slate-700">{inv.invoiceNumber}</td>
                  <td className="p-3.5 font-bold text-slate-900">
                    <div>{inv.studentNameAr}</div>
                    <div className="text-[10px] text-slate-400 font-normal">{inv.gradeLevel}</div>
                  </td>
                  <td className="p-3.5 text-slate-700">{inv.feeCategory}</td>
                  <td className="p-3.5 text-center font-bold text-slate-900">
                    {inv.amountIQD?.toLocaleString()} {t('iqd')}
                  </td>
                  <td className="p-3.5 text-center font-bold text-emerald-700">
                    {inv.paidAmountIQD?.toLocaleString()} {t('iqd')}
                  </td>
                  <td className="p-3.5 text-center font-bold text-rose-600">
                    {inv.remainingAmountIQD?.toLocaleString()} {t('iqd')}
                  </td>
                  <td className="p-3.5 text-center">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold inline-block ${
                      inv.status === 'مدفوع بالكامل'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : (inv.status === 'مدفوع جزئياً' ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-rose-50 text-rose-700 border border-rose-200')
                    }`}>
                      {inv.status}
                    </span>
                  </td>
                  <td className="p-3.5 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      {inv.status !== 'مدفوع بالكامل' ? (
                        <button
                          type="button"
                          onClick={() => onOpenPaymentModal(inv)}
                          className="px-3 py-1.5 rounded-xl bg-emerald-700 text-white font-bold hover:bg-emerald-800 transition-colors shadow-xs flex items-center gap-1"
                        >
                          <CreditCard className="w-3.5 h-3.5" />
                          <span>{t('payNow')}</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => onOpenReceiptModal(inv)}
                          className="px-3 py-1.5 rounded-xl bg-slate-900 text-white font-bold hover:bg-slate-800 transition-colors shadow-xs flex items-center gap-1"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>{t('officialReceipt')}</span>
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
