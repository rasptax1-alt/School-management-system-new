import React from 'react';
import { useParams, NavLink, useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useApp } from '../context/AppContext';
import ForecastBarChart from '../components/Charts/ForecastBarChart';
import {
  ArrowLeft,
  Package,
  AlertTriangle,
  Building2,
  ShoppingCart,
  Calendar,
  CheckCircle2,
  TrendingUp,
  Clock,
  Sparkles
} from 'lucide-react';

export default function ProductDetail() {
  const { productId } = useParams();
  const navigate = useNavigate();
  const { t, isRtl, formatCurrency, formatNumber, formatDate } = useLanguage();
  const { products, supplierMap, purchaseOrders, triggerQuickRestockModal } = useApp();

  const product = products.find(p => p.id === productId);

  if (!product) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <h2 className="text-base font-semibold text-[#111111] mb-2">Product Not Found</h2>
        <NavLink to="/products" className="text-xs text-[#FF9000] font-medium hover:underline">
          {t('backToProducts')}
        </NavLink>
      </div>
    );
  }

  const supplier = supplierMap[product.supplier_id];
  const associatedOrders = purchaseOrders.filter(po => po.product_id === product.id);

  // Stockout countdown
  const daysUntilStockout = product.daily_sales_velocity > 0
    ? Math.max(0, Math.floor(product.current_stock / product.daily_sales_velocity))
    : 99;

  const isLow = product.current_stock <= product.reorder_point;
  const isZero = product.current_stock === 0;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 pb-24 flex flex-col gap-6">
      {/* Back button & Title */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate('/products')}
          className="flex items-center gap-1.5 text-xs text-[#898989] hover:text-[#111111] transition-colors"
        >
          <ArrowLeft className={`w-4 h-4 ${isRtl ? 'rotate-180' : ''}`} />
          <span>{t('backToProducts')}</span>
        </button>

        <button
          onClick={() => triggerQuickRestockModal(product)}
          className="px-4 py-2 rounded-full bg-[#FF9000] hover:bg-[#111111] text-[#111111] hover:text-white text-xs font-semibold transition-all shadow-sm flex items-center gap-1.5"
        >
          <ShoppingCart className="w-3.5 h-3.5" />
          <span>{t('triggerRestockNow')}</span>
        </button>
      </div>

      {/* Main Product Card */}
      <div className="bg-white rounded-3xl p-6 border border-[#DFDFDF] shadow-card-subtle flex flex-col md:flex-row gap-6">
        <img
          src={product.image_url}
          alt={product.name}
          className="w-full md:w-56 h-56 rounded-2xl object-cover border border-[#DFDFDF]"
        />

        <div className="flex-1 flex flex-col justify-between">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="font-mono text-xs px-2.5 py-0.5 rounded-full bg-[#EBEBED] text-[#111111] font-semibold">
                {product.sku}
              </span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#F3F3F5] text-[#898989]">
                {isRtl ? (product.categoryAr || product.category) : product.category}
              </span>
              {isZero ? (
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#F24E2C]/15 text-[#F24E2C] font-semibold">
                  {t('statusOutOfStock')}
                </span>
              ) : isLow ? (
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#FF9000]/15 text-[#B86800] font-semibold">
                  {t('statusLowStock')}
                </span>
              ) : (
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#10B981]/15 text-[#059669] font-semibold">
                  {t('statusActive')}
                </span>
              )}
            </div>

            <h1 className="text-xl sm:text-2xl font-bold text-[#111111]">
              {isRtl ? (product.nameAr || product.name) : product.name}
            </h1>
          </div>

          {/* Stock Runout Projection Banner */}
          <div className={`mt-4 p-4 rounded-2xl border flex items-center gap-3.5 ${
            isZero
              ? 'bg-[#F24E2C]/10 border-[#F24E2C]/30 text-[#F24E2C]'
              : isLow
              ? 'bg-[#FF9000]/10 border-[#FF9000]/30 text-[#B86800]'
              : 'bg-[#10B981]/10 border-[#10B981]/30 text-[#059669]'
          }`}>
            <AlertTriangle className="w-5 h-5 shrink-0" />
            <div className="text-xs">
              <div className="font-bold text-sm">
                {isZero ? t('statusOutOfStock') : `${t('depletesIn')} ${daysUntilStockout} ${t('days')}`}
              </div>
              <p className="opacity-80 mt-0.5">
                Current velocity: {product.daily_sales_velocity} {t('units')}{t('perDay')} · Reorder point: {product.reorder_point} {t('units')}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-white border border-[#DFDFDF] shadow-xs">
          <span className="text-xs text-[#898989]">{t('fieldStock')}</span>
          <div className="text-xl font-bold text-[#111111] mt-1">
            {formatNumber(product.current_stock)}
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-[#DFDFDF] shadow-xs">
          <span className="text-xs text-[#898989]">{t('fieldReorderPoint')}</span>
          <div className="text-xl font-bold text-[#111111] mt-1">
            {formatNumber(product.reorder_point)}
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-[#DFDFDF] shadow-xs">
          <span className="text-xs text-[#898989]">{t('fieldUnitCost')}</span>
          <div className="text-xl font-bold text-[#111111] mt-1">
            {formatCurrency(product.unit_cost)}
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-[#DFDFDF] shadow-xs">
          <span className="text-xs text-[#898989]">{t('fieldSellingPrice')}</span>
          <div className="text-xl font-bold text-[#111111] mt-1">
            {formatCurrency(product.selling_price)}
          </div>
        </div>
      </div>

      {/* Supplier & Associated Orders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Supplier Info */}
        <div className="bg-white p-5 rounded-3xl border border-[#DFDFDF] shadow-card-subtle flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-3 border-b border-[#DFDFDF]">
              <Building2 className="w-4 h-4 text-[#FF9000]" />
              <h2 className="font-semibold text-sm text-[#111111]">
                {t('supplierInfo')}
              </h2>
            </div>

            {supplier ? (
              <div className="mt-4 flex flex-col gap-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-[#898989]">{t('colSupplierName')}:</span>
                  <NavLink
                    to={`/suppliers/${supplier.id}`}
                    className="font-semibold text-[#111111] hover:text-[#FF9000] transition-colors"
                  >
                    {isRtl ? (supplier.nameAr || supplier.name) : supplier.name}
                  </NavLink>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#898989]">{t('colLeadTime')}:</span>
                  <span className="font-medium text-[#111111]">{supplier.default_lead_time_days} {t('days')}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#898989]">{t('colReliability')}:</span>
                  <span className="font-semibold text-[#10B981]">{supplier.reliability_score}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#898989]">{t('fieldPaymentTerms')}:</span>
                  <span className="text-[#343434]">{supplier.payment_terms}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#898989]">{t('fieldEmail')}:</span>
                  <span className="text-[#343434]">{supplier.email}</span>
                </div>
              </div>
            ) : (
              <p className="text-xs text-[#898989] mt-4">No supplier assigned</p>
            )}
          </div>
        </div>

        {/* Associated POs */}
        <div className="bg-white p-5 rounded-3xl border border-[#DFDFDF] shadow-card-subtle flex flex-col">
          <div className="flex items-center gap-2 pb-3 border-b border-[#DFDFDF]">
            <ShoppingCart className="w-4 h-4 text-[#111111]" />
            <h2 className="font-semibold text-sm text-[#111111]">
              {t('associatedPOs')}
            </h2>
          </div>

          <div className="divide-y divide-[#DFDFDF]/70 mt-2 flex-1">
            {associatedOrders.map(po => (
              <div key={po.id} className="py-2.5 flex items-center justify-between text-xs">
                <div>
                  <div className="font-mono font-medium text-[#111111]">{po.po_number}</div>
                  <div className="text-[11px] text-[#898989] mt-0.5">
                    {formatNumber(po.quantity)} {t('units')} · {formatDate(po.expected_delivery)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">{formatCurrency(po.total_cost)}</div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#EBEBED] text-[#111111] font-medium mt-0.5 inline-block">
                    {po.status}
                  </span>
                </div>
              </div>
            ))}

            {associatedOrders.length === 0 && (
              <div className="py-8 text-center text-xs text-[#898989]">
                No purchase orders recorded for this product.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
