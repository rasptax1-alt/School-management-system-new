import React, { useState } from 'react';
import { SchoolProvider, useSchool } from './context/SchoolContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './pages/Dashboard';
import { Students } from './pages/Students';
import { Staff } from './pages/Staff';
import { Classes } from './pages/Classes';
import { Attendance } from './pages/Attendance';
import { Gradebook } from './pages/Gradebook';
import { Billing } from './pages/Billing';
import { SaasAdmin } from './pages/SaasAdmin';
import { BrandingTheme } from './pages/BrandingTheme';
import { BulkCenter } from './pages/BulkCenter';

// Modals
import { IraqiPaymentModal } from './components/IraqiPaymentModal';
import { ReceiptModal } from './components/ReceiptModal';
import { ReportCardModal } from './components/ReportCardModal';
import { BulkCsvModal } from './components/BulkCsvModal';
import { SchoolThemeSettingsModal } from './components/SchoolThemeSettingsModal';
import { Toast } from './components/Toast';

function MainApp() {
  const [currentTab, setCurrentTab] = useState('dashboard');

  // Modals state
  const [paymentInvoice, setPaymentInvoice] = useState(null);
  const [receiptInvoice, setReceiptInvoice] = useState(null);
  const [reportCardStudent, setReportCardStudent] = useState(null);
  const [bulkCsvSection, setBulkCsvSection] = useState(null);
  const [showThemeModal, setShowThemeModal] = useState(false);

  const { grades } = useSchool();
  const { isRTL } = useLanguage();

  return (
    <div className={`min-h-screen bg-[#F8FAFC] text-slate-900 flex flex-col font-sans ${isRTL ? 'font-arabic' : ''}`}>
      
      {/* Top Navigation Header */}
      <Header onOpenThemeModal={() => setShowThemeModal(true)} />

      {/* Main Layout Area */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        
        {/* Sidebar Navigation */}
        <div className="hidden md:block">
          <Sidebar currentTab={currentTab} setCurrentTab={setCurrentTab} />
        </div>

        {/* Content Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {currentTab === 'dashboard' && (
            <Dashboard 
              onNavigate={setCurrentTab}
              onOpenCsvModal={(sec) => setBulkCsvSection(sec)}
              onOpenPaymentModal={(inv) => setPaymentInvoice(inv)}
            />
          )}

          {currentTab === 'students' && (
            <Students 
              onOpenCsvModal={(sec) => setBulkCsvSection(sec || 'students')}
              onOpenReportCard={(stu) => setReportCardStudent(stu)}
              onOpenPaymentModal={(inv) => setPaymentInvoice(inv)}
            />
          )}

          {currentTab === 'staff' && (
            <Staff onOpenCsvModal={(sec) => setBulkCsvSection(sec || 'staff')} />
          )}

          {currentTab === 'classes' && (
            <Classes onOpenCsvModal={(sec) => setBulkCsvSection(sec || 'classes')} />
          )}

          {currentTab === 'attendance' && (
            <Attendance onOpenCsvModal={(sec) => setBulkCsvSection(sec || 'attendance')} />
          )}

          {currentTab === 'gradebook' && (
            <Gradebook 
              onOpenCsvModal={(sec) => setBulkCsvSection(sec || 'grades')}
              onOpenReportCard={(stu) => setReportCardStudent(stu)}
            />
          )}

          {currentTab === 'billing' && (
            <Billing 
              onOpenCsvModal={(sec) => setBulkCsvSection(sec || 'invoices')}
              onOpenPaymentModal={(inv) => setPaymentInvoice(inv)}
              onOpenReceiptModal={(inv) => setReceiptInvoice(inv)}
            />
          )}

          {currentTab === 'saasAdmin' && (
            <SaasAdmin onOpenThemeModal={() => setShowThemeModal(true)} />
          )}

          {currentTab === 'brandingTheme' && (
            <BrandingTheme />
          )}

          {currentTab === 'bulkCenter' && (
            <BulkCenter onOpenCsvModal={(sec) => setBulkCsvSection(sec)} />
          )}
        </main>

      </div>

      {/* Global Interactive Modals */}
      {paymentInvoice && (
        <IraqiPaymentModal 
          invoice={paymentInvoice} 
          onClose={() => setPaymentInvoice(null)}
          onPaymentSuccess={(res) => {
            setReceiptInvoice({ ...paymentInvoice, ...res });
          }}
        />
      )}

      {receiptInvoice && (
        <ReceiptModal 
          invoice={receiptInvoice} 
          onClose={() => setReceiptInvoice(null)} 
        />
      )}

      {reportCardStudent && (
        <ReportCardModal 
          student={reportCardStudent}
          grades={grades}
          onClose={() => setReportCardStudent(null)}
        />
      )}

      {bulkCsvSection && (
        <BulkCsvModal 
          section={bulkCsvSection}
          onClose={() => setBulkCsvSection(null)}
        />
      )}

      {showThemeModal && (
        <SchoolThemeSettingsModal 
          onClose={() => setShowThemeModal(false)} 
        />
      )}

      {/* Toast notifications */}
      <Toast />

    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <SchoolProvider>
        <MainApp />
      </SchoolProvider>
    </LanguageProvider>
  );
}
