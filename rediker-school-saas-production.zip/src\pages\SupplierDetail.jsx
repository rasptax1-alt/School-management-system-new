import React from 'react';
import { useParams, NavLink, useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useApp } from '../context/AppContext';
import {
  ArrowLeft,
  Building2,
  MapPin,
  Clock,
  ShieldCheck,
  Mail,
  Phone,
  Package,
  ShoppingCart,
  Calendar
} from 'lucide-react';

export default function SupplierDetail() {
  const { supplierId } = useParams();
  const navigate = useNavigate();
  const { t, isRtl, formatCurrency, formatNumber, formatDate } = useLanguage();
  const { suppliers, products, purchaseOrders } = useApp();

  const supplier = suppliers.find(s => s.id === supplierId);

  if (!supplier) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <h2 className="text-base font-semibold text-[#111111] mb-2">Supplier Not Found</h2>
        <NavLink to="/suppliers" className="text-xs text-[#FF9000] font-medium hover:underline">
          {t('backToSuppliers')}
        </NavLink>
      </div>
    );
  }

  const suppliedProducts = products.filter(p => p.supplier_id === supplier.id);
  const supplierOrders = purchaseOrders.filter(po => po.supplier_id === supplier.id);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 pb-24 flex flex-col gap-6">
      {/* Back button */}
      <div>
        <button
          onClick={() => navigate('/suppliers')}
          className="flex items-center gap-1.5 text-xs text-[#898989] hover:text-[#111111] transition-colors"
        >
          <ArrowLeft className={`w-4 h-4 ${isRtl ? 'rotate-180' : ''}`} />
          <span>{t('backToSuppliers')}</span>
        </button>
      </div>

      {/* Supplier Profile Banner */}
      <div className="bg-white rounded-3xl p-6 border border-[#DFDFDF] shadow-card-subtle flex flex-col md:flex-row gap-6">
        <img
          src={supplier.image_url}
          alt={supplier.name}
          className="w-full md:w-48 h-48 rounded-2xl object-cover border border-[#DFDFDF]"
        />

        <div className="flex-1 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#10B981]/15 text-[#059669] font-bold">
                {supplier.reliability_score}% Reliability
              </span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#F3F3F5] text-[#898989]">
                {supplier.payment_terms}
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl font-bold text-[#111111]">
              {isRtl ? (supplier.nameAr || supplier.name) : supplier.name}
            </h1>

            <div className="flex items-center gap-1.5 text-xs text-[#898989] mt-1">
              <MapPin className="w-3.5 h-3.5 text-[#FF9000]" />
              <span>{isRtl ? (supplier.locationAr || supplier.location) : supplier.location}</span>
            </div>

            {supplier.notes && (
              <p className="text-xs text-[#343434] mt-3 leading-relaxed bg-[#F8F8FA] p-3 rounded-xl border border-[#DFDFDF]/60">
                {supplier.notes}
              </p>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4 pt-4 border-t border-[#DFDFDF]/70 text-xs">
            <div>
              <span className="text-[#898989] block">{t('colLeadTime')}</span>
              <span className="font-bold text-sm text-[#111111]">{supplier.default_lead_time_days} days</span>
            </div>
            <div>
              <span className="text-[#898989] block">{t('fieldContactName')}</span>
              <span className="font-semibold text-[#111111]">{supplier.contact_name || '—'}</span>
            </div>
            <div>
              <span className="text-[#898989] block">{t('fieldEmail')}</span>
              <span className="text-[#111111] truncate block">{supplier.email}</span>
            </div>
            <div>
              <span className="text-[#898989] block">{t('fieldPhone')}</span>
              <span className="text-[#111111]">{supplier.phone}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Products Supplied Table */}
      <div className="bg-white rounded-3xl p-5 border border-[#DFDFDF] shadow-card-subtle flex flex-col gap-3">
        <div className="flex items-center gap-2 pb-2 border-b border-[#DFDFDF]">
          <Package className="w-4 h-4 text-[#FF9000]" />
          <h2 className="font-semibold text-sm text-[#111111]">
            {t('suppliedProducts')} ({suppliedProducts.length})
          </h2>
        </div>

        <div className="divide-y divide-[#DFDFDF]/70 text-xs">
          {suppliedProducts.map(prod => (
            <div key={prod.id} className="py-3 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <img
                  src={prod.image_url}
                  alt={prod.name}
                  className="w-9 h-9 rounded-xl object-cover border border-[#DFDFDF]"
                />
                <div>
                  <NavLink
                    to={`/products/${prod.id}`}
                    className="font-semibold text-[#111111] hover:text-[#FF9000] transition-colors"
                  >
                    {isRtl ? (prod.nameAr || prod.name) : prod.name}
                  </NavLink>
                  <span className="font-mono text-[10px] text-[#898989] block">{prod.sku}</span>
                </div>
              </div>

              <div className="flex items-center gap-6 text-right">
                <div>
                  <span className="text-[#898989] text-[10px] block">{t('colStock')}</span>
                  <span className="font-semibold text-[#111111]">{formatNumber(prod.current_stock)}</span>
                </div>
                <div>
                  <span className="text-[#898989] text-[10px] block">{t('colUnitCost')}</span>
                  <span className="font-semibold text-[#111111]">{formatCurrency(prod.unit_cost)}</span>
                </div>
              </div>
            </div>
          ))}

          {suppliedProducts.length === 0 && (
            <div className="py-6 text-center text-xs text-[#898989]">
              No products associated with this supplier yet.
            </div>
          )}
        </div>
      </div>

      {/* Order History */}
      <div className="bg-white rounded-3xl p-5 border border-[#DFDFDF] shadow-card-subtle flex flex-col gap-3">
        <div className="flex items-center gap-2 pb-2 border-b border-[#DFDFDF]">
          <ShoppingCart className="w-4 h-4 text-[#111111]" />
          <h2 className="font-semibold text-sm text-[#111111]">
            {t('orderHistory')} ({supplierOrders.length})
          </h2>
        </div>

        <div className="divide-y divide-[#DFDFDF]/70 text-xs">
          {supplierOrders.map(po => (
            <div key={po.id} className="py-3 flex items-center justify-between gap-3">
              <div>
                <span className="font-mono font-bold text-[#111111]">{po.po_number}</span>
                <span className="text-[11px] text-[#898989] block mt-0.5">
                  Ordered on {formatDate(po.created_date)} · Expected {formatDate(po.expected_delivery)}
                </span>
              </div>

              <div className="text-right">
                <span className="font-bold text-xs text-[#111111]">{formatCurrency(po.total_cost)}</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#EBEBED] text-[#111111] font-medium block mt-0.5">
                  {po.status}
                </span>
              </div>
            </div>
          ))}

          {supplierOrders.length === 0 && (
            <div className="py-6 text-center text-xs text-[#898989]">
              No purchase orders with this supplier yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
