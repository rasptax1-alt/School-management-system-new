import React from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  FileSpreadsheet, 
  UploadCloud, 
  DownloadCloud, 
  FileDown, 
  GraduationCap, 
  Users, 
  BookOpen, 
  Award, 
  CalendarCheck, 
  CreditCard,
  CheckCircle2,
  Download
} from 'lucide-react';
import { 
  exportDataToCsv, 
  downloadSectionTemplate 
} from '../services/csvExportImport';

export function BulkCenter({ onOpenCsvModal }) {
  const { 
    currentSchool, 
    students, 
    staff, 
    classes, 
    grades, 
    attendance, 
    invoices, 
    showToast 
  } = useSchool();
  const { t, lang, isRTL } = useLanguage();

  const sectionsConfig = [
    {
      id: 'students',
      titleAr: 'بيانات الطلاب وشؤون القيد (SIS)',
      titleEn: 'Student Information System (SIS)',
      descAr: 'سجلات الطلاب، المعلومات الديموغرافية، أولياء الأمور، والمعدلات',
      count: students.length,
      icon: GraduationCap,
      color: 'teal',
      exportData: () => {
        const formatted = students.map(s => ({
          "رقم_القيد": s.studentId,
          "الاسم_الرباعي_عربي": s.fullNameAr,
          "الاسم_انجليزي": s.fullNameEn,
          "الرقم_الوطني": s.nationalId,
          "الجنس": s.gender,
          "المرحلة_الدراسية": s.gradeLevel,
          "الشعبة": s.section,
          "اسم_ولي_الأمر": s.guardianName,
          "هاتف_ولي_الأمر": s.guardianPhone,
          "المعدل": s.gpa,
          "القسط_الكلي": s.tuitionTotal,
          "حالة_السداد": s.tuitionStatus
        }));
        exportDataToCsv(formatted, `students-${currentSchool.code}.csv`);
        showToast(isRTL ? 'تم تنزيل بيانات الطلاب بنجاح' : 'Students data exported');
      }
    },
    {
      id: 'staff',
      titleAr: 'الكادر التدريسي والوظيفي',
      titleEn: 'Faculty & Staff Members',
      descAr: 'المعلمون، الأقسام، المؤهلات العلمية، الرواتب، والمواد المكلفين بها',
      count: staff.length,
      icon: Users,
      color: 'indigo',
      exportData: () => {
        const formatted = staff.map(st => ({
          "الرقم_الوظيفي": st.staffId,
          "الاسم_الرباعي_عربي": st.fullNameAr,
          "الاسم_انجليزي": st.fullNameEn,
          "المسمى_الوظيفي": st.role,
          "القسم": st.department,
          "البريد_الإلكتروني": st.email,
          "رقم_الهاتف": st.phone,
          "المؤهل_العلمي": st.qualification,
          "الراتب_الشهري_دينار": st.salaryIQD,
          "الحالة": st.status
        }));
        exportDataToCsv(formatted, `staff-${currentSchool.code}.csv`);
        showToast(isRTL ? 'تم تنزيل بيانات الكادر بنجاح' : 'Staff data exported');
      }
    },
    {
      id: 'classes',
      titleAr: 'الصفوف والشعب والقاعات',
      titleEn: 'Classes & Room Allocations',
      descAr: 'الشعب الدراسية، السعة القصوى، القاعات، ومربو الصفوف',
      count: classes.length,
      icon: BookOpen,
      color: 'amber',
      exportData: () => {
        const formatted = classes.map(c => ({
          "رمز_الصف": c.code,
          "اسم_الصف_عربي": c.nameAr,
          "المرحلة": c.gradeLevel,
          "الشعبة": c.section,
          "رقم_القاعة": c.roomNumber,
          "مربي_الصف": c.homeroomTeacher,
          "عدد_الطلاب": c.studentCount,
          "السعة_القصوى": c.maxCapacity
        }));
        exportDataToCsv(formatted, `classes-${currentSchool.code}.csv`);
        showToast(isRTL ? 'تم تنزيل بيانات الصفوف بنجاح' : 'Classes data exported');
      }
    },
    {
      id: 'grades',
      titleAr: 'دفتر الدرجات وسجل العلامات',
      titleEn: 'Gradebook & Academic Marks',
      descAr: 'درجات الفصول، الاختبارات اليومية، الامتحانات النهائية، والتقديرات',
      count: grades.length,
      icon: Award,
      color: 'purple',
      exportData: () => {
        const formatted = grades.map(g => ({
          "رقم_الطالب": g.studentId,
          "اسم_الطالب": g.studentNameAr,
          "رمز_المادة": g.classCode,
          "المادة_عربي": g.subjectNameAr,
          "الفصل": g.term,
          "النشاط_اليومي_20": g.dailyActivities,
          "امتحان_نصف_السنة_30": g.midtermExam,
          "الشفهي_والكويزات_10": g.quizzes,
          "النهائي_40": g.finalExam,
          "المجموع_100": g.totalScore,
          "التقدير": g.letterGrade,
          "الحالة": g.status
        }));
        exportDataToCsv(formatted, `grades-${currentSchool.code}.csv`);
        showToast(isRTL ? 'تم تنزيل درجات الطلاب بنجاح' : 'Grades exported');
      }
    },
    {
      id: 'attendance',
      titleAr: 'سجلات الحضور والغياب اليومي',
      titleEn: 'Daily Attendance Records',
      descAr: 'تواريخ الحضور، أوقات الوصول، حالات التأخير والإجازات المرضية',
      count: attendance.length,
      icon: CalendarCheck,
      color: 'emerald',
      exportData: () => {
        const formatted = attendance.map(a => ({
          "التاريخ": a.date,
          "رقم_الطالب": a.studentId,
          "اسم_الطالب": a.studentNameAr,
          "رمز_الصف": a.classCode,
          "الحالة": a.status,
          "وقت_الحضور": a.checkInTime,
          "ملاحظات_الغياب": a.notes
        }));
        exportDataToCsv(formatted, `attendance-${currentSchool.code}.csv`);
        showToast(isRTL ? 'تم تنزيل سجلات الحضور بنجاح' : 'Attendance exported');
      }
    },
    {
      id: 'invoices',
      titleAr: 'الفواتير والأقساط والمدفوعات',
      titleEn: 'Tuition Fees & Iraqi Payments',
      descAr: 'الفواتير الصادرة، المبالغ المسددة، البوابات العراقية، وأرقام وصولات القبض',
      count: invoices.length,
      icon: CreditCard,
      color: 'rose',
      exportData: () => {
        const formatted = invoices.map(inv => ({
          "رقم_الفاتورة": inv.invoiceNumber,
          "رقم_الطالب": inv.studentId,
          "اسم_الطالب": inv.studentNameAr,
          "المرحلة": inv.gradeLevel,
          "نوع_القسط": inv.feeCategory,
          "المبلغ_الكلي_دينار": inv.amountIQD,
          "المدفوع_دينار": inv.paidAmountIQD,
          "المتبقي_دينار": inv.remainingAmountIQD,
          "تاريخ_الاستحقاق": inv.dueDate,
          "حالة_السداد": inv.status,
          "بوابة_الدفع": inv.paymentMethod,
          "رقم_الوصل": inv.receiptNumber || "-",
          "رمز_العملية": inv.transactionRef || "-"
        }));
        exportDataToCsv(formatted, `invoices-${currentSchool.code}.csv`);
        showToast(isRTL ? 'تم تنزيل الفواتير بنجاح' : 'Invoices exported');
      }
    }
  ];

  // Download complete school master backup
  const handleDownloadFullSchoolBackup = () => {
    const backupPack = [
      {
        "اسم_المدرسة": currentSchool.nameAr,
        "كود_المدرسة": currentSchool.code,
        "المحافظة": currentSchool.city,
        "العام_الدراسي": currentSchool.academicYear,
        "إجمالي_الطلاب": students.length,
        "إجمالي_الكادر": staff.length,
        "إجمالي_الصفوف": classes.length,
        "إجمالي_الدرجات": grades.length,
        "إجمالي_سجلات_الحضور": attendance.length,
        "إجمالي_الفواتير": invoices.length,
        "تاريخ_النسخ": new Date().toISOString()
      }
    ];
    exportDataToCsv(backupPack, `${currentSchool.code}-complete-school-package.csv`);
    showToast('تم تصدير حزمة بيانات المدرسة الكاملة بنجاح!', 'success');
  };

  const primaryColor = currentSchool.theme?.primary || '#0F766E';

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              {t('bulkCenterTitle')}
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {t('bulkCenterSubtitle')} • {currentSchool.nameAr}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleDownloadFullSchoolBackup}
          className="px-5 py-2.5 rounded-xl text-white text-xs font-bold shadow-md hover:opacity-95 transition-all flex items-center gap-2"
          style={{ backgroundColor: primaryColor }}
        >
          <DownloadCloud className="w-4 h-4" />
          <span>{t('downloadFullSchoolBackup')}</span>
        </button>
      </div>

      {/* Sections Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sectionsConfig.map(sec => {
          const Icon = sec.icon;
          return (
            <div 
              key={sec.id}
              className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs hover:shadow-md transition-all flex flex-col justify-between space-y-5"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-700">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
                    {sec.count} سجل متوفر
                  </span>
                </div>

                <div>
                  <h3 className="font-extrabold text-sm text-slate-900">{sec.titleAr}</h3>
                  <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">{sec.descAr}</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 border-t border-slate-100 pt-4">
                
                {/* Bulk Import CSV Button */}
                <button
                  type="button"
                  onClick={() => onOpenCsvModal(sec.id)}
                  className="w-full py-2.5 rounded-xl text-xs font-bold text-white transition-all shadow-xs flex items-center justify-center gap-1.5"
                  style={{ backgroundColor: primaryColor }}
                >
                  <UploadCloud className="w-4 h-4" />
                  <span>استيراد ملف CSV لهذا القسم</span>
                </button>

                {/* Download Available Data CSV */}
                <button
                  type="button"
                  onClick={sec.exportData}
                  className="w-full py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-800 text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                >
                  <DownloadCloud className="w-4 h-4 text-slate-600" />
                  <span>تنزيل بيانات القسم الحالية (CSV)</span>
                </button>

                {/* Download Ready Template (Ar & En) */}
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => downloadSectionTemplate(sec.id, 'ar')}
                    className="flex-1 py-1.5 rounded-lg bg-emerald-50 text-emerald-800 hover:bg-emerald-100 text-[11px] font-semibold transition-colors flex items-center justify-center gap-1"
                  >
                    <Download className="w-3 h-3" />
                    <span>نموذج (عربي)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => downloadSectionTemplate(sec.id, 'en')}
                    className="flex-1 py-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 text-[11px] font-semibold transition-colors flex items-center justify-center gap-1"
                  >
                    <Download className="w-3 h-3" />
                    <span>Template (EN)</span>
                  </button>
                </div>

              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
}
