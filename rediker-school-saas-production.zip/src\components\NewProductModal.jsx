import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useApp } from '../context/AppContext';
import { X, Package, Check } from 'lucide-react';

export default function NewProductModal({ isOpen, onClose }) {
  const { t, isRtl } = useLanguage();
  const { addProduct, suppliers, addToast } = useApp();

  const [formData, setFormData] = useState({
    name: '',
    nameAr: '',
    sku: '',
    category: 'Electronics',
    current_stock: 100,
    reorder_point: 30,
    daily_sales_velocity: 5,
    unit_cost: 25,
    selling_price: 49,
    supplier_id: suppliers[0]?.id || '',
    image_url: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=300&auto=format&fit=crop&q=80'
  });

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.sku.trim()) {
      addToast('Please fill in required fields (Name & SKU)', 'error');
      return;
    }

    addProduct({
      ...formData,
      nameAr: formData.nameAr || formData.name
    });

    addToast(t('toastProductCreated'), 'success');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
      <div
        className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-[#DFDFDF] max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-4 border-b border-[#DFDFDF]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#111111] text-[#FF9000] flex items-center justify-center">
              <Package className="w-4 h-4" />
            </div>
            <h2 className="font-semibold text-base text-[#111111]">
              {t('modalNewProductTitle')}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-[#F3F3F5] text-[#898989] hover:text-[#111111] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 flex flex-col gap-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldName')} (EN) *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g. Ultra-Sensor 500"
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              />
            </div>

            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldName')} (AR)
              </label>
              <input
                type="text"
                value={formData.nameAr}
                onChange={(e) => setFormData({ ...formData, nameAr: e.target.value })}
                placeholder="مثال: مستشعر متطور 500"
                dir="rtl"
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs font-arabic"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldSKU')} *
              </label>
              <input
                type="text"
                required
                value={formData.sku}
                onChange={(e) => setFormData({ ...formData, sku: e.target.value.toUpperCase() })}
                placeholder="SKU-XXXX"
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white font-mono text-xs uppercase"
              />
            </div>

            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldCategory')}
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              >
                <option value="Electronics">Electronics</option>
                <option value="Packaging">Packaging</option>
                <option value="Industrial">Industrial</option>
                <option value="Apparel">Apparel</option>
                <option value="Home Goods">Home Goods</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldStock')}
              </label>
              <input
                type="number"
                min="0"
                value={formData.current_stock}
                onChange={(e) => setFormData({ ...formData, current_stock: Number(e.target.value) })}
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              />
            </div>

            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldReorderPoint')}
              </label>
              <input
                type="number"
                min="1"
                value={formData.reorder_point}
                onChange={(e) => setFormData({ ...formData, reorder_point: Number(e.target.value) })}
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              />
            </div>

            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldVelocity')}
              </label>
              <input
                type="number"
                step="0.1"
                min="0"
                value={formData.daily_sales_velocity}
                onChange={(e) => setFormData({ ...formData, daily_sales_velocity: Number(e.target.value) })}
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldUnitCost')}
              </label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={formData.unit_cost}
                onChange={(e) => setFormData({ ...formData, unit_cost: Number(e.target.value) })}
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              />
            </div>

            <div>
              <label className="block font-medium text-[#343434] mb-1">
                {t('fieldSellingPrice')}
              </label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={formData.selling_price}
                onChange={(e) => setFormData({ ...formData, selling_price: Number(e.target.value) })}
                className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-[#343434] mb-1">
              {t('fieldSupplier')}
            </label>
            <select
              value={formData.supplier_id}
              onChange={(e) => setFormData({ ...formData, supplier_id: e.target.value })}
              className="w-full h-9 px-3 rounded-xl bg-[#F3F3F5] border border-[#DFDFDF] focus:outline-none focus:border-[#111111] focus:bg-white text-xs"
            >
              {suppliers.map(s => (
                <option key={s.id} value={s.id}>
                  {isRtl ? (s.nameAr || s.name) : s.name} ({s.default_lead_time_days} days)
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#DFDFDF] mt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-full border border-[#DFDFDF] hover:bg-[#F3F3F5] text-[#343434] transition-colors"
            >
              {t('btnCancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-full bg-[#111111] hover:bg-[#FF9000] text-white hover:text-[#111111] font-semibold transition-all"
            >
              {t('btnSave')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
