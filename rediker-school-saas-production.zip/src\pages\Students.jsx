import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  GraduationCap, 
  Search, 
  Filter, 
  DownloadCloud, 
  UploadCloud, 
  Plus, 
  Award, 
  CreditCard, 
  Phone, 
  CheckCircle2, 
  X,
  FileSpreadsheet
} from 'lucide-react';
import { exportDataToCsv } from '../services/csvExportImport';

export function Students({ onOpenCsvModal, onOpenReportCard, onOpenPaymentModal }) {
  const { currentSchool, students, setStudents, grades, invoices, showToast } = useSchool();
  const { t, lang, isRTL } = useLanguage();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGrade, setSelectedGrade] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);

  // New Student Form State
  const [fullNameAr, setFullNameAr] = useState('');
  const [fullNameEn, setFullNameEn] = useState('');
  const [nationalId, setNationalId] = useState('');
  const [gender, setGender] = useState('ذكر');
  const [gradeLevel, setGradeLevel] = useState('الرابع العلمي');
  const [section, setSection] = useState('أ');
  const [guardianName, setGuardianName] = useState('');
  const [guardianPhone, setGuardianPhone] = useState('');
  const [address, setAddress] = useState('بغداد');
  const [tuitionTotal, setTuitionTotal] = useState(2500000);

  // Filter students
  const filteredStudents = students.filter(s => {
    const matchesSearch = 
      (s.fullNameAr && s.fullNameAr.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (s.fullNameEn && s.fullNameEn.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (s.studentId && s.studentId.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (s.guardianPhone && s.guardianPhone.includes(searchQuery));
    
    const matchesGrade = selectedGrade === 'all' || s.gradeLevel === selectedGrade;

    return matchesSearch && matchesGrade;
  });

  // Export current list to CSV
  const handleExportCsv = () => {
    const formatted = filteredStudents.map(s => ({
      "رقم_القيد": s.studentId,
      "الاسم_الرباعي_عربي": s.fullNameAr,
      "الاسم_انجليزي": s.fullNameEn,
      "الرقم_الوطني": s.nationalId,
      "الجنس": s.gender,
      "المرحلة_الدراسية": s.gradeLevel,
      "الشعبة": s.section,
      "اسم_ولي_الأمر": s.guardianName,
      "هاتف_ولي_الأمر": s.guardianPhone,
      "العنوان": s.address,
      "المعدل": s.gpa,
      "نسبة_الحضور": `${s.attendanceRate}%`,
      "القسط_الكلي": s.tuitionTotal,
      "المدفوع": s.tuitionPaid,
      "المتبقي": s.tuitionBalance,
      "حالة_السداد": s.tuitionStatus
    }));

    exportDataToCsv(formatted, `students-${currentSchool.code}.csv`);
    showToast(isRTL ? 'تم تصدير ملف الطلاب CSV بنجاح' : 'Students CSV exported successfully');
  };

  const handleAddStudentSubmit = (e) => {
    e.preventDefault();
    if (!fullNameAr) return;

    const newStudent = {
      id: `stu-${Date.now()}`,
      schoolId: currentSchool.id,
      studentId: `STU-2026-${Math.floor(100 + Math.random() * 900)}`,
      fullNameAr,
      fullNameEn: fullNameEn || fullNameAr,
      nationalId: nationalId || "199000000000",
      gender,
      birthDate: "2010-01-01",
      gradeLevel,
      section,
      guardianName: guardianName || fullNameAr.split(' ').slice(1).join(' '),
      guardianPhone: guardianPhone || "07700000000",
      address,
      bloodType: "O+",
      medicalNotes: "سليم",
      enrollmentDate: new Date().toISOString().split('T')[0],
      status: "منتظم",
      gpa: 92.5,
      attendanceRate: 100,
      tuitionTotal: Number(tuitionTotal),
      tuitionPaid: 0,
      tuitionBalance: Number(tuitionTotal),
      tuitionStatus: "غير مدفوع"
    };

    setStudents(prev => [newStudent, ...prev]);
    showToast(`تم تسجيل الطالب: ${newStudent.fullNameAr} بنجاح`, 'success');
    setShowAddModal(false);

    // Reset form
    setFullNameAr('');
    setFullNameEn('');
    setNationalId('');
    setGuardianPhone('');
  };

  const primaryColor = currentSchool.theme?.primary || '#0F766E';

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-900 tracking-tight">
                {t('students')} (Administrator's Plus)
              </h2>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                سجل قيد الطلاب الموحد • {currentSchool.nameAr} ({filteredStudents.length} طالب مسجل)
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons: Add, Bulk CSV Import, CSV Export */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => onOpenCsvModal('students')}
            className="px-3.5 py-2.5 rounded-xl border border-teal-200 bg-teal-50 text-teal-800 text-xs font-bold hover:bg-teal-100 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <UploadCloud className="w-4 h-4 text-teal-700" />
            <span>{t('bulkImportStudents')}</span>
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-800 text-xs font-bold hover:bg-slate-50 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <DownloadCloud className="w-4 h-4 text-slate-600" />
            <span>{t('exportCsv')}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 rounded-xl text-white text-xs font-bold shadow-md hover:opacity-95 transition-all flex items-center gap-1.5"
            style={{ backgroundColor: primaryColor }}
          >
            <Plus className="w-4 h-4" />
            <span>{t('addStudent')}</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute top-1/2 -translate-y-1/2 text-slate-400 right-3" />
          <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t('search')}
            className="w-full pr-9 pl-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 bg-slate-50 focus:bg-white"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-500" />
          <select
            value={selectedGrade}
            onChange={(e) => setSelectedGrade(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-700 font-semibold focus:outline-none"
          >
            <option value="all">كافة المراحل الدراسية</option>
            <option value="الرابع العلمي">الرابع العلمي</option>
            <option value="الخامس العلمي">الخامس العلمي</option>
            <option value="السادس العلمي">السادس العلمي (وزاري)</option>
            <option value="الثالث المتوسط">الثالث المتوسط</option>
          </select>
        </div>
      </div>

      {/* Students Data Table */}
      <div className="bg-white rounded-3xl border border-slate-200/90 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-start text-xs">
            <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
              <tr>
                <th className="p-3.5 text-start">{t('studentId')}</th>
                <th className="p-3.5 text-start">{t('studentName')}</th>
                <th className="p-3.5 text-start">{t('gradeLevel')}</th>
                <th className="p-3.5 text-start">{t('section')}</th>
                <th className="p-3.5 text-start">ولي الأمر والهاتف</th>
                <th className="p-3.5 text-center">{t('gpa')}</th>
                <th className="p-3.5 text-center">{t('tuitionStatus')}</th>
                <th className="p-3.5 text-center">{t('actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length > 0 ? (
                filteredStudents.map((s) => {
                  const studentInvoice = invoices.find(i => i.studentId === s.studentId);
                  return (
                    <tr key={s.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3.5 font-mono font-bold text-slate-700">{s.studentId}</td>
                      <td className="p-3.5 font-bold text-slate-900">
                        <div>{s.fullNameAr}</div>
                        <div className="text-[10px] text-slate-400 font-normal">{s.fullNameEn}</div>
                      </td>
                      <td className="p-3.5 text-slate-700">{s.gradeLevel}</td>
                      <td className="p-3.5 text-slate-700 font-semibold">{s.section}</td>
                      <td className="p-3.5 text-slate-600">
                        <div className="font-medium">{s.guardianName}</div>
                        <div className="text-[10px] text-slate-400 flex items-center gap-1 font-mono">
                          <Phone className="w-2.5 h-2.5" />
                          <span>{s.guardianPhone}</span>
                        </div>
                      </td>
                      <td className="p-3.5 text-center font-bold text-slate-900">
                        {s.gpa ? `${s.gpa}%` : '-'}
                      </td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold inline-block ${
                          s.tuitionStatus === 'مدفوع'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : (s.tuitionStatus === 'جزئي' ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-rose-50 text-rose-700 border border-rose-200')
                        }`}>
                          {s.tuitionStatus}
                        </span>
                      </td>
                      <td className="p-3.5 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => onOpenReportCard(s)}
                            title="إصدار الشهادة الرسمية"
                            className="p-1.5 rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 transition-colors"
                          >
                            <Award className="w-4 h-4" />
                          </button>
                          {studentInvoice && studentInvoice.status !== 'مدفوع بالكامل' && (
                            <button
                              type="button"
                              onClick={() => onOpenPaymentModal(studentInvoice)}
                              title="تسديد القسط عبر بوابة عراقية"
                              className="p-1.5 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100 transition-colors"
                            >
                              <CreditCard className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    لا يوجد طلاب مطابقين للبحث
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Single Student Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div 
              className="p-5 text-white flex items-center justify-between"
              style={{ backgroundColor: primaryColor }}
            >
              <h3 className="font-extrabold text-base">{t('addStudent')}</h3>
              <button onClick={() => setShowAddModal(false)} className="text-white hover:opacity-80">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddStudentSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">{t('studentName')} (عربي) *</label>
                <input 
                  type="text" 
                  required
                  value={fullNameAr}
                  onChange={(e) => setFullNameAr(e.target.value)}
                  placeholder="مثال: علي حيدر كاظم الزبيدي"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">الاسم بالإنجليزية</label>
                <input 
                  type="text" 
                  value={fullNameEn}
                  onChange={(e) => setFullNameEn(e.target.value)}
                  placeholder="Ali Haider Kadhim"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t('gradeLevel')}</label>
                  <select 
                    value={gradeLevel}
                    onChange={(e) => setGradeLevel(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                  >
                    <option value="الرابع العلمي">الرابع العلمي</option>
                    <option value="الخامس العلمي">الخامس العلمي</option>
                    <option value="السادس العلمي">السادس العلمي</option>
                    <option value="الثالث المتوسط">الثالث المتوسط</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t('section')}</label>
                  <input 
                    type="text" 
                    value={section}
                    onChange={(e) => setSection(e.target.value)}
                    placeholder="أ"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t('guardianPhone')}</label>
                  <input 
                    type="text" 
                    value={guardianPhone}
                    onChange={(e) => setGuardianPhone(e.target.value)}
                    placeholder="07701234567"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">القسط الدراسي السنوي (IQD)</label>
                  <input 
                    type="number" 
                    value={tuitionTotal}
                    onChange={(e) => setTuitionTotal(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 font-bold"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-white font-bold"
                  style={{ backgroundColor: primaryColor }}
                >
                  {t('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
