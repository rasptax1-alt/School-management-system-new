import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  CalendarCheck, 
  Calendar, 
  UploadCloud, 
  DownloadCloud, 
  Check, 
  X, 
  Clock, 
  AlertCircle,
  Save
} from 'lucide-react';
import { exportDataToCsv } from '../services/csvExportImport';

export function Attendance({ onOpenCsvModal }) {
  const { currentSchool, students, attendance, setAttendance, showToast } = useSchool();
  const { t, lang, isRTL } = useLanguage();

  const [selectedDate, setSelectedDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [selectedClass, setSelectedClass] = useState('all');

  // Filter attendance or synthesize daily rows for current students
  const filteredStudents = students.filter(s => selectedClass === 'all' || s.gradeLevel === selectedClass);

  const getStudentStatus = (studentId) => {
    const record = attendance.find(a => a.studentId === studentId && a.date === selectedDate);
    return record ? record.status : 'حاضر';
  };

  const handleStatusChange = (studentId, studentNameAr, newStatus) => {
    setAttendance(prev => {
      const existsIndex = prev.findIndex(a => a.studentId === studentId && a.date === selectedDate);
      if (existsIndex !== -1) {
        const updated = [...prev];
        updated[existsIndex] = {
          ...updated[existsIndex],
          status: newStatus,
          statusEn: newStatus === 'حاضر' ? 'Present' : (newStatus === 'غائب' ? 'Absent' : 'Late')
        };
        return updated;
      } else {
        return [
          {
            id: `att-${Date.now()}`,
            schoolId: currentSchool.id,
            date: selectedDate,
            studentId,
            studentNameAr,
            classCode: "G10-SCI-A",
            status: newStatus,
            statusEn: newStatus === 'حاضر' ? 'Present' : (newStatus === 'غائب' ? 'Absent' : 'Late'),
            checkInTime: newStatus === 'حاضر' ? '07:45 AM' : (newStatus === 'متأخر' ? '08:15 AM' : '-'),
            notes: ""
          },
          ...prev
        ];
      }
    });
  };

  const handleExportCsv = () => {
    const formatted = attendance.map(a => ({
      "التاريخ": a.date,
      "رقم_الطالب": a.studentId,
      "اسم_الطالب": a.studentNameAr,
      "رمز_الصف": a.classCode,
      "الحالة": a.status,
      "وقت_الحضور": a.checkInTime,
      "ملاحظات_الغياب": a.notes
    }));

    exportDataToCsv(formatted, `attendance-${currentSchool.code}-${selectedDate}.csv`);
    showToast(isRTL ? 'تم تصدير سجلات الحضور والغياب CSV بنجاح' : 'Attendance CSV exported successfully');
  };

  const primaryColor = currentSchool.theme?.primary || '#0F766E';

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
            <CalendarCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              {t('attendance')}
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              رصد الحضور والغياب اليومي للطلاب • {currentSchool.nameAr}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => onOpenCsvModal('attendance')}
            className="px-3.5 py-2.5 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-800 text-xs font-bold hover:bg-emerald-100 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <UploadCloud className="w-4 h-4 text-emerald-700" />
            <span>استيراد حضور (CSV)</span>
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-800 text-xs font-bold hover:bg-slate-50 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <DownloadCloud className="w-4 h-4 text-slate-600" />
            <span>{t('exportCsv')}</span>
          </button>
        </div>
      </div>

      {/* Date & Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="flex items-center gap-2 bg-slate-50 px-3 py-2 rounded-xl border border-slate-200">
            <Calendar className="w-4 h-4 text-slate-500" />
            <input 
              type="date" 
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent text-xs font-bold text-slate-800 focus:outline-none"
            />
          </div>

          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-700 font-semibold focus:outline-none"
          >
            <option value="all">كافة الصفوف والشعب</option>
            <option value="الرابع العلمي">الرابع العلمي</option>
            <option value="الخامس العلمي">الخامس العلمي</option>
            <option value="السادس العلمي">السادس العلمي</option>
          </select>
        </div>

        <button
          onClick={() => showToast('تم حفظ سجل الحضور والغياب اليومي بنجاح', 'success')}
          className="px-5 py-2 rounded-xl text-white text-xs font-bold shadow-md hover:opacity-95 transition-all flex items-center gap-1.5"
          style={{ backgroundColor: primaryColor }}
        >
          <Save className="w-4 h-4" />
          <span>{t('saveAttendance')}</span>
        </button>
      </div>

      {/* Attendance Sheet Table */}
      <div className="bg-white rounded-3xl border border-slate-200/90 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-start text-xs">
            <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
              <tr>
                <th className="p-3.5 text-start">{t('studentId')}</th>
                <th className="p-3.5 text-start">{t('studentName')}</th>
                <th className="p-3.5 text-start">{t('gradeLevel')}</th>
                <th className="p-3.5 text-center">حالة الحضور لليوم</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.map((s) => {
                const currentStatus = getStudentStatus(s.studentId);
                return (
                  <tr key={s.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3.5 font-mono font-bold text-slate-700">{s.studentId}</td>
                    <td className="p-3.5 font-bold text-slate-900">{s.fullNameAr}</td>
                    <td className="p-3.5 text-slate-600">{s.gradeLevel} - شعبة {s.section}</td>
                    <td className="p-3.5 text-center">
                      <div className="inline-flex items-center gap-1 p-1 rounded-xl bg-slate-100 border border-slate-200">
                        <button
                          type="button"
                          onClick={() => handleStatusChange(s.studentId, s.fullNameAr, 'حاضر')}
                          className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                            currentStatus === 'حاضر'
                              ? 'bg-emerald-600 text-white shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          حاضر
                        </button>
                        <button
                          type="button"
                          onClick={() => handleStatusChange(s.studentId, s.fullNameAr, 'متأخر')}
                          className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                            currentStatus === 'متأخر'
                              ? 'bg-amber-500 text-white shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          متأخر
                        </button>
                        <button
                          type="button"
                          onClick={() => handleStatusChange(s.studentId, s.fullNameAr, 'غائب')}
                          className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                            currentStatus === 'غائب'
                              ? 'bg-rose-600 text-white shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          غائب
                        </button>
                        <button
                          type="button"
                          onClick={() => handleStatusChange(s.studentId, s.fullNameAr, 'غائب بعذر')}
                          className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                            currentStatus === 'غائب بعذر'
                              ? 'bg-blue-600 text-white shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          بعذر
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
