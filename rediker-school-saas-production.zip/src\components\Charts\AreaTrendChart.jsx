import React, { useState, useMemo } from 'react';
import { useLanguage } from '../../context/LanguageContext';

export default function AreaTrendChart({ data = [], height = 240 }) {
  const { formatCurrency, formatDate } = useLanguage();
  const [hoverIndex, setHoverIndex] = useState(null);

  const { points, minVal, maxVal, pathD, areaD } = useMemo(() => {
    if (!data || data.length === 0) {
      return { points: [], minVal: 0, maxVal: 100, pathD: '', areaD: '' };
    }

    const values = data.map(d => d.value);
    const rawMin = Math.min(...values);
    const rawMax = Math.max(...values);
    const padding = (rawMax - rawMin) * 0.15 || 5000;
    const min = Math.max(0, rawMin - padding);
    const max = rawMax + padding;

    const width = 1000;
    const chartHeight = 200;

    const coords = data.map((d, i) => {
      const x = (i / (data.length - 1)) * width;
      const y = chartHeight - ((d.value - min) / (max - min)) * chartHeight;
      return { x, y, data: d };
    });

    if (coords.length < 2) return { points: coords, minVal: min, maxVal: max, pathD: '', areaD: '' };

    // Generate smooth bezier curve path
    let d = `M ${coords[0].x} ${coords[0].y}`;
    for (let i = 0; i < coords.length - 1; i++) {
      const p0 = coords[i === 0 ? i : i - 1];
      const p1 = coords[i];
      const p2 = coords[i + 1];
      const p3 = coords[i + 2] || p2;

      const cp1x = p1.x + (p2.x - p0.x) / 6;
      const cp1y = p1.y + (p2.y - p0.y) / 6;
      const cp2x = p2.x - (p3.x - p1.x) / 6;
      const cp2y = p2.y - (p3.y - p1.y) / 6;

      d += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${p2.x} ${p2.y}`;
    }

    const area = `${d} L ${width} ${chartHeight} L 0 ${chartHeight} Z`;

    return { points: coords, minVal: min, maxVal: max, pathD: d, areaD: area };
  }, [data]);

  const activePoint = hoverIndex !== null && points[hoverIndex] ? points[hoverIndex] : points[points.length - 1];

  return (
    <div className="w-full flex flex-col gap-2">
      {/* Dynamic Hover Badge */}
      <div className="flex items-center justify-between text-xs px-1">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-[#111111]" />
          <span className="text-[#898989]">
            {activePoint?.data?.date ? formatDate(activePoint.data.date) : 'Recent Value'}
          </span>
        </div>
        <div className="font-semibold text-sm text-[#111111]">
          {activePoint?.data?.value ? formatCurrency(activePoint.data.value) : '—'}
        </div>
      </div>

      {/* SVG Canvas */}
      <div className="relative w-full overflow-hidden rounded-xl bg-[#EBEBED]/60 p-2 border border-[#DFDFDF]/60">
        <svg
          viewBox="0 0 1000 200"
          className="w-full h-auto overflow-visible"
          style={{ height }}
          preserveAspectRatio="none"
          onMouseLeave={() => setHoverIndex(null)}
        >
          <defs>
            <linearGradient id="invGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#111111" stopOpacity="0.25" />
              <stop offset="60%" stopColor="#111111" stopOpacity="0.08" />
              <stop offset="100%" stopColor="#111111" stopOpacity="0.0" />
            </linearGradient>
            <linearGradient id="lineGlow" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#111111" />
              <stop offset="100%" stopColor="#FF9000" />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          <line x1="0" y1="50" x2="1000" y2="50" stroke="#DFDFDF" strokeDasharray="4 4" strokeWidth="1" />
          <line x1="0" y1="100" x2="1000" y2="100" stroke="#DFDFDF" strokeDasharray="4 4" strokeWidth="1" />
          <line x1="0" y1="150" x2="1000" y2="150" stroke="#DFDFDF" strokeDasharray="4 4" strokeWidth="1" />

          {/* Area fill */}
          {areaD && <path d={areaD} fill="url(#invGradient)" />}

          {/* Main trend curve */}
          {pathD && (
            <path
              d={pathD}
              fill="none"
              stroke="#111111"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}

          {/* Hover interactive vertical cursor */}
          {activePoint && (
            <g>
              <line
                x1={activePoint.x}
                y1="0"
                x2={activePoint.x}
                y2="200"
                stroke="#FF9000"
                strokeWidth="1.5"
                strokeDasharray="3 3"
              />
              <circle
                cx={activePoint.x}
                cy={activePoint.y}
                r="5"
                fill="#FF9000"
                stroke="#111111"
                strokeWidth="2"
              />
            </g>
          )}

          {/* Invisible interactive hover slices */}
          {points.map((p, idx) => (
            <rect
              key={idx}
              x={p.x - 500 / points.length}
              y="0"
              width={1000 / points.length}
              height="200"
              fill="transparent"
              className="cursor-pointer"
              onMouseEnter={() => setHoverIndex(idx)}
            />
          ))}
        </svg>

        {/* Min & Max Labels */}
        <div className="flex justify-between items-center text-[10px] text-[#898989] mt-1 px-1">
          <span>{data[0]?.dayLabel || '90 days ago'}</span>
          <span>{data[Math.floor(data.length / 2)]?.dayLabel || '45 days ago'}</span>
          <span>{data[data.length - 1]?.dayLabel || 'Today'}</span>
        </div>
      </div>
    </div>
  );
}
