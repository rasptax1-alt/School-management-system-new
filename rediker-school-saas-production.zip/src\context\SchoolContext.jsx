import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  defaultSchools, 
  saasPlans, 
  initialStudents, 
  initialStaff, 
  initialClasses, 
  initialGrades, 
  initialAttendance, 
  initialInvoices, 
  iraqiPaymentGatewaysInfo 
} from '../../server/data/defaultSchools';

const SchoolContext = createContext(null);

export function SchoolProvider({ children }) {
  // 1. Multi-School Tenants
  const [schools, setSchools] = useState(() => {
    const saved = localStorage.getItem('rediker_schools');
    return saved ? JSON.parse(saved) : defaultSchools;
  });

  const [currentSchoolId, setCurrentSchoolId] = useState(() => {
    const saved = localStorage.getItem('rediker_active_school_id');
    return saved || defaultSchools[0].id;
  });

  // Current active school object
  const currentSchool = schools.find(s => s.id === currentSchoolId) || schools[0];

  // 2. Active User Role
  const [role, setRole] = useState(() => {
    return localStorage.getItem('rediker_user_role') || 'admin'; // admin, superadmin, teacher, parent
  });

  // 3. School Module Entities
  const [students, setStudents] = useState(() => {
    const saved = localStorage.getItem('rediker_students');
    return saved ? JSON.parse(saved) : initialStudents;
  });

  const [staff, setStaff] = useState(() => {
    const saved = localStorage.getItem('rediker_staff');
    return saved ? JSON.parse(saved) : initialStaff;
  });

  const [classes, setClasses] = useState(() => {
    const saved = localStorage.getItem('rediker_classes');
    return saved ? JSON.parse(saved) : initialClasses;
  });

  const [grades, setGrades] = useState(() => {
    const saved = localStorage.getItem('rediker_grades');
    return saved ? JSON.parse(saved) : initialGrades;
  });

  const [attendance, setAttendance] = useState(() => {
    const saved = localStorage.getItem('rediker_attendance');
    return saved ? JSON.parse(saved) : initialAttendance;
  });

  const [invoices, setInvoices] = useState(() => {
    const saved = localStorage.getItem('rediker_invoices');
    return saved ? JSON.parse(saved) : initialInvoices;
  });

  const [notifications, setNotifications] = useState([]);

  // Apply Dynamic CSS Variables for the current school's visual identity
  useEffect(() => {
    if (currentSchool && currentSchool.theme) {
      const root = document.documentElement;
      root.style.setProperty('--school-primary', currentSchool.theme.primary || '#0F766E');
      root.style.setProperty('--school-primary-hover', currentSchool.theme.primaryHover || '#0D9488');
      root.style.setProperty('--school-secondary', currentSchool.theme.secondary || '#D97706');
      root.style.setProperty('--school-accent', currentSchool.theme.accent || '#14B8A6');
      root.style.setProperty('--school-dark-bg', currentSchool.theme.darkBg || '#134E4A');
      root.style.setProperty('--school-sidebar-bg', currentSchool.theme.sidebarBg || '#042F2E');
      root.style.setProperty('--school-card-border', currentSchool.theme.cardBorder || '#CCFBF1');
    }
    localStorage.setItem('rediker_active_school_id', currentSchoolId);
  }, [currentSchool, currentSchoolId]);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('rediker_schools', JSON.stringify(schools));
  }, [schools]);

  useEffect(() => {
    localStorage.setItem('rediker_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('rediker_staff', JSON.stringify(staff));
  }, [staff]);

  useEffect(() => {
    localStorage.setItem('rediker_classes', JSON.stringify(classes));
  }, [classes]);

  useEffect(() => {
    localStorage.setItem('rediker_grades', JSON.stringify(grades));
  }, [grades]);

  useEffect(() => {
    localStorage.setItem('rediker_attendance', JSON.stringify(attendance));
  }, [attendance]);

  useEffect(() => {
    localStorage.setItem('rediker_invoices', JSON.stringify(invoices));
  }, [invoices]);

  // Toast notification helper
  const showToast = (message, type = 'success') => {
    const id = Date.now();
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 4000);
  };

  // Switch Active School
  const switchSchool = (schoolId) => {
    const found = schools.find(s => s.id === schoolId);
    if (found) {
      setCurrentSchoolId(schoolId);
      showToast(`تم التبديل إلى: ${found.nameAr}`, 'info');
    }
  };

  // Update School Visual Identity / Theme
  const updateSchoolTheme = (schoolId, updatedFields) => {
    setSchools(prev => prev.map(s => {
      if (s.id === schoolId) {
        return {
          ...s,
          ...updatedFields,
          theme: { ...s.theme, ...(updatedFields.theme || {}) }
        };
      }
      return s;
    }));
    showToast('تم حفظ الهوية البصرية والثيم بنجاح', 'success');
  };

  // Add New School (SaaS Tenant Onboarding)
  const addNewSchool = (newSchoolData) => {
    const newSchool = {
      id: `sch-${Date.now().toString().slice(-6)}`,
      code: (newSchoolData.nameEn || 'SCH').toUpperCase().replace(/\s+/g, '-').slice(0, 10),
      nameAr: newSchoolData.nameAr,
      nameEn: newSchoolData.nameEn || newSchoolData.nameAr,
      mottoAr: newSchoolData.mottoAr || "معاً نحو التميز الأكاديمي",
      mottoEn: newSchoolData.mottoEn || "Together Towards Academic Excellence",
      country: "Iraq",
      city: newSchoolData.city || "بغداد",
      district: newSchoolData.district || "المركز",
      phone: newSchoolData.phone || "07700000000",
      email: newSchoolData.email || "info@school.iq",
      foundedYear: new Date().getFullYear(),
      currency: "IQD",
      academicYear: "2025 - 2026",
      logo: newSchoolData.logo || "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=150&auto=format&fit=crop&q=80",
      theme: newSchoolData.theme || {
        id: "custom",
        name: "الهوية المخصصة للمدرسة",
        primary: "#0F766E",
        primaryHover: "#0D9488",
        secondary: "#D97706",
        accent: "#14B8A6",
        darkBg: "#134E4A",
        sidebarBg: "#042F2E",
        cardBorder: "#CCFBF1"
      },
      saasSubscription: {
        planId: newSchoolData.planId || "basic",
        planNameAr: newSchoolData.planNameAr || "الباقة الأساسية",
        planNameEn: "Basic Plan",
        status: "active",
        cycle: "yearly",
        priceIQD: 3500000,
        studentsLimit: 250,
        currentStudentsCount: 0,
        staffLimit: 25,
        storageGb: 10,
        startDate: new Date().toISOString().split('T')[0],
        expiresDate: new Date(Date.now() + 365*24*60*60*1000).toISOString().split('T')[0],
        paymentGateway: "FIB"
      }
    };

    setSchools(prev => [newSchool, ...prev]);
    setCurrentSchoolId(newSchool.id);
    showToast(`تم تسجيل مدرسة ${newSchool.nameAr} بنجاح!`, 'success');
    return newSchool;
  };

  // Filtered Entities for the Current Active School
  const currentStudents = students.filter(s => s.schoolId === currentSchoolId);
  const currentStaff = staff.filter(s => s.schoolId === currentSchoolId);
  const currentClasses = classes.filter(c => c.schoolId === currentSchoolId);
  const currentGrades = grades.filter(g => g.schoolId === currentSchoolId);
  const currentAttendance = attendance.filter(a => a.schoolId === currentSchoolId);
  const currentInvoices = invoices.filter(i => i.schoolId === currentSchoolId);

  // Bulk Import for Any Section
  const bulkImportSection = (section, newItems) => {
    const timestamp = Date.now();
    switch (section) {
      case 'students': {
        const mapped = newItems.map((item, idx) => ({
          id: `stu-${timestamp}-${idx}`,
          schoolId: currentSchoolId,
          studentId: item.studentId || item.رقم_القيد || `STU-2026-${Math.floor(100 + Math.random() * 900)}`,
          fullNameAr: item.fullNameAr || item.الاسم_الرباعي_عربي || "طالب جديد",
          fullNameEn: item.fullNameEn || item.الاسم_انجليزي || "New Student",
          nationalId: item.nationalId || item.الرقم_الوطني || "199000000000",
          gender: item.gender || item.الجنس || "ذكر",
          birthDate: item.birthDate || item.تاريخ_الميلاد || "2010-01-01",
          gradeLevel: item.gradeLevel || item.المرحلة_الدراسية || "الرابع العلمي",
          gradeLevelEn: item.gradeLevelEn || "Grade 10",
          section: item.section || item.الشعبة || "أ",
          guardianName: item.guardianName || item.اسم_ولي_الأمر || "",
          guardianPhone: item.guardianPhone || item.هاتف_ولي_الأمر || "",
          guardianEmail: item.guardianEmail || item.البريد_الإلكتروني || "",
          address: item.address || item.العنوان || "العراق",
          bloodType: item.bloodType || item.فصيلة_الدم || "O+",
          medicalNotes: item.medicalNotes || "سليم",
          enrollmentDate: new Date().toISOString().split('T')[0],
          status: "منتظم",
          gpa: Number(item.gpa || item.المعدل || 0),
          attendanceRate: 100,
          tuitionTotal: Number(item.tuitionTotal || item.القسط_الكلي || 2500000),
          tuitionPaid: Number(item.tuitionPaid || 0),
          tuitionBalance: Number(item.tuitionTotal || item.القسط_الكلي || 2500000) - Number(item.tuitionPaid || 0),
          tuitionStatus: Number(item.tuitionPaid || 0) > 0 ? "جزئي" : "غير مدفوع"
        }));
        setStudents(prev => [...mapped, ...prev]);
        showToast(`تم استيراد ${mapped.length} طالب بنجاح`, 'success');
        break;
      }
      case 'staff': {
        const mapped = newItems.map((item, idx) => ({
          id: `stf-${timestamp}-${idx}`,
          schoolId: currentSchoolId,
          staffId: item.staffId || item.الرقم_الوظيفي || `TCH-${Math.floor(200 + Math.random() * 800)}`,
          fullNameAr: item.fullNameAr || item.الاسم_الرباعي_عربي || "عضو كادر",
          fullNameEn: item.fullNameEn || item.الاسم_انجليزي || "Faculty Member",
          role: item.role || item.المسمى_الوظيفي || "معلم",
          roleEn: item.roleEn || "Teacher",
          department: item.department || item.القسم || "العلوم",
          departmentEn: item.departmentEn || "Sciences",
          email: item.email || item.البريد_الإلكتروني || "teacher@school.iq",
          phone: item.phone || item.رقم_الهاتف || "07700000000",
          qualification: item.qualification || item.المؤهل_العلمي || "بكالوريوس",
          salaryIQD: Number(item.salaryIQD || item.الراتب_الشهري_دينار || 1500000),
          subjectsTaught: item.subjectsTaught ? (Array.isArray(item.subjectsTaught) ? item.subjectsTaught : [item.subjectsTaught]) : ["المادة المقررة"],
          classesAssigned: ["الرابع العلمي أ"],
          status: "على رأس العمل",
          joinDate: new Date().toISOString().split('T')[0]
        }));
        setStaff(prev => [...mapped, ...prev]);
        showToast(`تم استيراد ${mapped.length} من أعضاء الكادر بنجاح`, 'success');
        break;
      }
      case 'classes': {
        const mapped = newItems.map((item, idx) => ({
          id: `cls-${timestamp}-${idx}`,
          schoolId: currentSchoolId,
          code: item.code || item.رمز_الصف || `CLS-${idx + 1}`,
          nameAr: item.nameAr || item.اسم_الصف_عربي || "صف دراسي جديد",
          nameEn: item.nameEn || item.اسم_الصف_انجليزي || "New Class",
          gradeLevel: item.gradeLevel || item.المرحلة || "الرابع العلمي",
          section: item.section || item.الشعبة || "أ",
          roomNumber: item.roomNumber || item.رقم_القاعة || "قاعة 101",
          homeroomTeacher: item.homeroomTeacher || item.مربي_الصف || "أستاذ المادة",
          studentCount: 30,
          maxCapacity: Number(item.maxCapacity || item.السعة_القصوى || 35),
          academicTerm: "الفصل الدراسي الأول",
          weeklyPeriods: 35
        }));
        setClasses(prev => [...mapped, ...prev]);
        showToast(`تم استيراد ${mapped.length} شعبة دراسية بنجاح`, 'success');
        break;
      }
      case 'grades': {
        const mapped = newItems.map((item, idx) => {
          const daily = Number(item.dailyActivities || item.النشاط_اليومي_20 || 18);
          const mid = Number(item.midtermExam || item.امتحان_شهري_30 || 27);
          const quiz = Number(item.quizzes || item.اختبارات_قصيرة_10 || 9);
          const fin = Number(item.finalExam || item.الامتحان_النهائي_40 || 36);
          const total = daily + mid + quiz + fin;
          return {
            id: `grd-${timestamp}-${idx}`,
            schoolId: currentSchoolId,
            studentId: item.studentId || item.رقم_الطالب || "STU-2026-001",
            studentNameAr: item.studentNameAr || item.اسم_الطالب || "طالب",
            studentNameEn: item.studentNameEn || "Student",
            classCode: item.classCode || item.رمز_المادة || "MATH-101",
            subjectNameAr: item.subjectNameAr || item.المادة_عربي || "الرياضيات",
            subjectNameEn: item.subjectNameEn || item.المادة_انجليزي || "Mathematics",
            teacherNameAr: "أستاذ المادة",
            term: item.term || item.الفصل || "الفصل الدراسي الأول",
            dailyActivities: daily,
            midtermExam: mid,
            quizzes: quiz,
            finalExam: fin,
            totalScore: total,
            letterGrade: total >= 90 ? "A+" : (total >= 80 ? "B+" : "C"),
            gpaScore: (total / 25).toFixed(1),
            status: total >= 50 ? "ناجح" : "راسب",
            statusEn: total >= 50 ? "Pass" : "Fail",
            remarks: "درجة مسجلة عبر الاستيراد الجماعي"
          };
        });
        setGrades(prev => [...mapped, ...prev]);
        showToast(`تم استيراد ${mapped.length} علامة بنجاح`, 'success');
        break;
      }
      case 'attendance': {
        const mapped = newItems.map((item, idx) => ({
          id: `att-${timestamp}-${idx}`,
          schoolId: currentSchoolId,
          date: item.date || item.التاريخ || new Date().toISOString().split('T')[0],
          studentId: item.studentId || item.رقم_الطالب || "STU-2026-001",
          studentNameAr: item.studentNameAr || item.اسم_الطالب || "طالب",
          classCode: item.classCode || item.رمز_الصف || "G10-SCI-A",
          status: item.status || item.الحالة || "حاضر",
          statusEn: item.status === "حاضر" ? "Present" : "Absent",
          checkInTime: item.checkInTime || item.وقت_الحضور || "07:45 AM",
          notes: item.notes || item.ملاحظات_الغياب || ""
        }));
        setAttendance(prev => [...mapped, ...prev]);
        showToast(`تم استيراد ${mapped.length} سجل حضور بنجاح`, 'success');
        break;
      }
      case 'invoices': {
        const mapped = newItems.map((item, idx) => {
          const total = Number(item.amountIQD || item.المبلغ_الكلي_دينار || 2500000);
          const paid = Number(item.paidAmountIQD || item.المدفوع_دينار || 0);
          return {
            id: `inv-${timestamp}-${idx}`,
            schoolId: currentSchoolId,
            invoiceNumber: item.invoiceNumber || item.رقم_الفاتورة || `INV-2026-${Math.floor(1000 + Math.random() * 9000)}`,
            studentId: item.studentId || item.رقم_الطالب || "STU-2026-001",
            studentNameAr: item.studentNameAr || item.اسم_الطالب || "طالب",
            gradeLevel: item.gradeLevel || item.المرحلة || "الرابع العلمي",
            feeCategory: item.feeCategory || item.نوع_القسط || "القسط الدراسي السنوي",
            amountIQD: total,
            paidAmountIQD: paid,
            remainingAmountIQD: total - paid,
            dueDate: item.dueDate || item.تاريخ_الاستحقاق || "2026-01-15",
            issueDate: new Date().toISOString().split('T')[0],
            status: total - paid === 0 ? "مدفوع بالكامل" : (paid > 0 ? "مدفوع جزئياً" : "مستحق الدفع"),
            statusEn: total - paid === 0 ? "Paid" : (paid > 0 ? "Partially Paid" : "Due"),
            paymentMethod: item.paymentMethod || item.بوابة_الدفع || "ZainCash",
            paymentGatewayName: "زين كاش العراق",
            transactionRef: "",
            receiptNumber: "",
            guardianPhone: "07701234567"
          };
        });
        setInvoices(prev => [...mapped, ...prev]);
        showToast(`تم استيراد ${mapped.length} فاتورة بنجاح`, 'success');
        break;
      }
      default:
        showToast('قسم غير معروف', 'error');
    }
  };

  // Complete Payment via Iraqi Gateway
  const markInvoicePaid = (invoiceId, paymentDetails) => {
    setInvoices(prev => prev.map(inv => {
      if (inv.id === invoiceId || inv.invoiceNumber === invoiceId) {
        return {
          ...inv,
          paidAmountIQD: inv.amountIQD,
          remainingAmountIQD: 0,
          status: "مدفوع بالكامل",
          statusEn: "Paid",
          paymentMethod: paymentDetails.gateway,
          paymentGatewayName: paymentDetails.gatewayName,
          transactionRef: paymentDetails.transactionId,
          receiptNumber: paymentDetails.receiptNumber,
          paidDate: paymentDetails.paidDate || new Date().toISOString().split('T')[0]
        };
      }
      return inv;
    }));

    // Also update student tuition balance
    const targetInvoice = invoices.find(i => i.id === invoiceId || i.invoiceNumber === invoiceId);
    if (targetInvoice) {
      setStudents(prev => prev.map(s => {
        if (s.studentId === targetInvoice.studentId) {
          return {
            ...s,
            tuitionPaid: s.tuitionTotal,
            tuitionBalance: 0,
            tuitionStatus: "مدفوع"
          };
        }
        return s;
      }));
    }

    showToast(`تم تأكيد السداد وإصدار الوصل الرسمي: ${paymentDetails.receiptNumber}`, 'success');
  };

  return (
    <SchoolContext.Provider value={{
      schools,
      currentSchool,
      currentSchoolId,
      switchSchool,
      addNewSchool,
      updateSchoolTheme,
      role,
      setRole,
      saasPlans,
      gateways: iraqiPaymentGatewaysInfo,
      
      // Current School Filtered Entities
      students: currentStudents,
      allStudents: students,
      setStudents,
      staff: currentStaff,
      allStaff: staff,
      setStaff,
      classes: currentClasses,
      allClasses: classes,
      setClasses,
      grades: currentGrades,
      allGrades: grades,
      setGrades,
      attendance: currentAttendance,
      allAttendance: attendance,
      setAttendance,
      invoices: currentInvoices,
      allInvoices: invoices,
      setInvoices,
      
      // Actions
      bulkImportSection,
      markInvoicePaid,
      notifications,
      showToast
    }}>
      {children}
    </SchoolContext.Provider>
  );
}

export function useSchool() {
  const context = useContext(SchoolContext);
  if (!context) {
    throw new Error('useSchool must be used within a SchoolProvider');
  }
  return context;
}
