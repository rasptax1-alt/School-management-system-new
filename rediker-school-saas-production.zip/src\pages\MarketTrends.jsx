import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useApp } from '../context/AppContext';
import {
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  Zap,
  ShieldAlert,
  BarChart2
} from 'lucide-react';

export default function MarketTrends() {
  const { t, isRtl } = useLanguage();
  const { marketTrends } = useApp();

  const risingCount = marketTrends.filter(m => m.direction === 'up').length;
  const decliningCount = marketTrends.filter(m => m.direction === 'down').length;
  const avgScore = marketTrends.length
    ? Math.round(marketTrends.reduce((sum, m) => sum + m.trend_score, 0) / marketTrends.length)
    : 0;

  const topGainer = marketTrends.reduce((max, m) => (!max || m.forecast_change_pct > max.forecast_change_pct ? m : max), null);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-24 flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#DFDFDF]">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-4 h-4 rounded-full bg-[#FF9000]" />
            <h1 className="font-semibold text-lg text-[#111111]">
              {t('marketTrendsTitle')}
            </h1>
            <span className="text-xs text-[#898989]">
              ({marketTrends.length} categories · Q4 2026)
            </span>
          </div>
          <p className="text-xs text-[#898989] mt-1">
            {t('marketTrendsSubtitle')}
          </p>
        </div>
      </div>

      {/* Macro Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-5 rounded-3xl bg-[#111111] text-white flex flex-col justify-between shadow-sm">
          <span className="text-xs text-white/70">{t('avgTrendScore')}</span>
          <div className="text-2xl sm:text-3xl font-light text-[#FF9000] mt-3">
            {avgScore}/100
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-white border border-[#DFDFDF] flex flex-col justify-between shadow-card-subtle">
          <span className="text-xs text-[#898989]">{t('risingCategories')}</span>
          <div className="text-2xl sm:text-3xl font-light text-[#10B981] mt-3 flex items-center gap-1">
            <ArrowUpRight className="w-5 h-5" />
            <span>{risingCount}</span>
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-white border border-[#DFDFDF] flex flex-col justify-between shadow-card-subtle">
          <span className="text-xs text-[#898989]">{t('decliningCategories')}</span>
          <div className="text-2xl sm:text-3xl font-light text-[#F24E2C] mt-3 flex items-center gap-1">
            <ArrowDownRight className="w-5 h-5" />
            <span>{decliningCount}</span>
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-white border border-[#DFDFDF] flex flex-col justify-between shadow-card-subtle">
          <span className="text-xs text-[#898989]">{t('topGainer')}</span>
          <div className="text-2xl sm:text-3xl font-light text-[#111111] mt-3">
            {topGainer ? `+${topGainer.forecast_change_pct}%` : '—'}
          </div>
        </div>
      </div>

      {/* Market Category Trend Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {marketTrends.map(item => {
          const isUp = item.direction === 'up';
          const factors = isRtl ? (item.key_factorsAr || item.key_factors) : item.key_factors;
          const summary = isRtl ? (item.summaryAr || item.summary) : item.summary;
          const advisory = isRtl ? (item.advisoryAr || item.advisory) : item.advisory;

          return (
            <div
              key={item.id}
              className="bg-white rounded-3xl p-6 border border-[#DFDFDF] shadow-card-subtle flex flex-col justify-between gap-4"
            >
              <div>
                {/* Category Header */}
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-[#EBEBED] text-[#111111] font-mono font-semibold">
                      {t('trendScore')}: {item.trend_score}
                    </span>
                    <h3 className="font-bold text-base text-[#111111] mt-2">
                      {isRtl ? (item.categoryAr || item.category) : item.category}
                    </h3>
                  </div>

                  <div className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${
                    isUp
                      ? 'bg-[#10B981]/15 text-[#059669]'
                      : 'bg-[#F24E2C]/15 text-[#F24E2C]'
                  }`}>
                    {isUp ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                    <span>{isUp ? '+' : ''}{item.forecast_change_pct}%</span>
                  </div>
                </div>

                {/* Summary */}
                <p className="text-xs text-[#343434] leading-relaxed mt-3">
                  {summary}
                </p>

                {/* Key Drivers Tags */}
                {factors && factors.length > 0 && (
                  <div className="mt-3 flex flex-wrap items-center gap-1.5">
                    <span className="text-[10px] text-[#898989]">{t('keyDrivers')}:</span>
                    {factors.map((f, i) => (
                      <span
                        key={i}
                        className="text-[10px] px-2 py-0.5 rounded-md bg-[#F3F3F5] text-[#343434] border border-[#DFDFDF]/70"
                      >
                        {f}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* AI Inventory Advisory Box */}
              <div className="p-3.5 rounded-2xl bg-[#FF9000]/10 border border-[#FF9000]/25 text-xs text-[#B86800]">
                <div className="flex items-center gap-1.5 font-bold mb-1 text-[#111111]">
                  <Sparkles className="w-3.5 h-3.5 text-[#FF9000]" />
                  <span>{t('aiAdvisory')}</span>
                </div>
                <p className="leading-relaxed opacity-95">
                  {advisory}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
