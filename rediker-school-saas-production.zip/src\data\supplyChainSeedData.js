export const seedSuppliers = [
  {
    id: "sup-1",
    name: "Global Logistics Components",
    nameAr: "المكونات اللوجستية العالمية",
    contact_name: "Marcus Vance",
    email: "marcus.vance@globallogistics.com",
    phone: "+1 (555) 382-9910",
    default_lead_time_days: 12,
    reliability_score: 96,
    payment_terms: "Net 30",
    location: "Shenzhen, China",
    locationAr: "شينزين، الصين",
    image_url: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=200&auto=format&fit=crop&q=80",
    notes: "Primary supplier for high-spec capacitive modules and connectors. Consistent delivery records."
  },
  {
    id: "sup-2",
    name: "Precision Microchips AG",
    nameAr: "مايكرو تشيبس إيه جي",
    contact_name: "Elena Rossi",
    email: "e.rossi@precisionmicro.ch",
    phone: "+41 44 211 4480",
    default_lead_time_days: 7,
    reliability_score: 99,
    payment_terms: "Net 60",
    location: "Zurich, Switzerland",
    locationAr: "زيورخ، سويسرا",
    image_url: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=200&auto=format&fit=crop&q=80",
    notes: "Tier-1 certified semiconductor fabrication partner. Premium pricing with 99.8% quality adherence."
  },
  {
    id: "sup-3",
    name: "Atlas Industrial Packaging",
    nameAr: "أطلس للتغليف الصناعي",
    contact_name: "Tariq Al-Mansoor",
    email: "tariq@atlaspack.sa",
    phone: "+966 13 882 1099",
    default_lead_time_days: 3,
    reliability_score: 98,
    payment_terms: "Net 30",
    location: "Dammam, Saudi Arabia",
    locationAr: "الدمام، المملكة العربية السعودية",
    image_url: "https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=200&auto=format&fit=crop&q=80",
    notes: "Regional strategic partner for heavy-duty shipping containers, crates, and tamper seals."
  },
  {
    id: "sup-4",
    name: "Nordic Fiber & Textiles",
    nameAr: "منسوجات الألياف الإسكندنافية",
    contact_name: "Freja Lindqvist",
    email: "freja@nordicfiber.se",
    phone: "+46 8 400 2911",
    default_lead_time_days: 14,
    reliability_score: 94,
    payment_terms: "Net 30",
    location: "Stockholm, Sweden",
    locationAr: "ستوكهولم، السويد",
    image_url: "https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=200&auto=format&fit=crop&q=80",
    notes: "Eco-certified aramid fabric and protective warehouse safety gear manufacturer."
  },
  {
    id: "sup-5",
    name: "Horizon Polymer & Plastics",
    nameAr: "هورايزون للبلمرات والبلاستيك",
    contact_name: "Jin-Woo Park",
    email: "park.jw@horizonpoly.kr",
    phone: "+82 51 980 1200",
    default_lead_time_days: 10,
    reliability_score: 93,
    payment_terms: "Net 45",
    location: "Busan, South Korea",
    locationAr: "بوسان، كوريا الجنوبية",
    image_url: "https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?w=200&auto=format&fit=crop&q=80",
    notes: "High volume polymer extrusions, seals, and shock-absorbent composite casings."
  }
];

export const seedProducts = [
  {
    id: "prod-1",
    name: "Ultra-Capacitor Core 450V",
    nameAr: "مكثف فائق التردد 450 فولت",
    sku: "SKU-8021",
    category: "Electronics",
    categoryAr: "الإلكترونيات",
    current_stock: 18,
    reorder_point: 50,
    daily_sales_velocity: 8.5,
    unit_cost: 45,
    selling_price: 89,
    supplier_id: "sup-1",
    status: "active",
    image_url: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=300&auto=format&fit=crop&q=80"
  },
  {
    id: "prod-2",
    name: "Thermal Sensor Array Gen-3",
    nameAr: "مصفوفة المستشعر الحراري الجيل الثالث",
    sku: "SKU-4912",
    category: "Electronics",
    categoryAr: "الإلكترونيات",
    current_stock: 4,
    reorder_point: 30,
    daily_sales_velocity: 5.2,
    unit_cost: 72,
    selling_price: 139,
    supplier_id: "sup-2",
    status: "active",
    image_url: "https://images.unsplash.com/photo-1555664424-778a1e5e1b48?w=300&auto=format&fit=crop&q=80"
  },
  {
    id: "prod-3",
    name: "Reinforced Eco-Crate 80L",
    nameAr: "صندوق شحن مقوى صديق للبيئة 80 لتر",
    sku: "SKU-1190",
    category: "Packaging",
    categoryAr: "التغليف",
    current_stock: 340,
    reorder_point: 100,
    daily_sales_velocity: 12.0,
    unit_cost: 14,
    selling_price: 29,
    supplier_id: "sup-3",
    status: "active",
    image_url: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=300&auto=format&fit=crop&q=80"
  },
  {
    id: "prod-4",
    name: "Tactical Carbon Shell Casing",
    nameAr: "غلاف كربوني تكتيكي مقاوم للصدمات",
    sku: "SKU-7734",
    category: "Industrial",
    categoryAr: "الصناعي",
    current_stock: 12,
    reorder_point: 40,
    daily_sales_velocity: 6.8,
    unit_cost: 110,
    selling_price: 219,
    supplier_id: "sup-5",
    status: "active",
    image_url: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=300&auto=format&fit=crop&q=80"
  },
  {
    id: "prod-5",
    name: "Optic Transceiver Module SFP+",
    nameAr: "وحدة الإرسال والاستقبال الضوئي SFP+",
    sku: "SKU-6028",
    category: "Electronics",
    categoryAr: "الإلكترونيات",
    current_stock: 0,
    reorder_point: 25,
    daily_sales_velocity: 4.1,
    unit_cost: 65,
    selling_price: 125,
    supplier_id: "sup-2",
    status: "active",
    image_url: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=300&auto=format&fit=crop&q=80"
  },
  {
    id: "prod-6",
    name: "Silicone O-Ring Seal Kit 240pc",
    nameAr: "طقم حشيات وحلقات سيليكون عازلة 240 قطعة",
    sku: "SKU-3312",
    category: "Industrial",
    categoryAr: "الصناعي",
    current_stock: 850,
    reorder_point: 200,
    daily_sales_velocity: 22.0,
    unit_cost: 3.5,
    selling_price: 8.9,
    supplier_id: "sup-5",
    status: "active",
    image_url: "https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?w=300&auto=format&fit=crop&q=80"
  },
  {
    id: "prod-7",
    name: "Smart Thermostat Microcontroller",
    nameAr: "متحكم الثرموستات الذكي المصغر",
    sku: "SKU-9921",
    category: "Electronics",
    categoryAr: "الإلكترونيات",
    current_stock: 65,
    reorder_point: 80,
    daily_sales_velocity: 7.0,
    unit_cost: 38,
    selling_price: 74,
    supplier_id: "sup-1",
    status: "active",
    image_url: "https://images.unsplash.com/photo-1517420704952-d9f39e95b43e?w=300&auto=format&fit=crop&q=80"
  },
  {
    id: "prod-8",
    name: "Heavy Duty Polyethylene Wrap",
    nameAr: "غلاف بولي إيثيلين صناعي عالي التحمل",
    sku: "SKU-2051",
    category: "Packaging",
    categoryAr: "التغليف",
    current_stock: 210,
    reorder_point: 150,
    daily_sales_velocity: 14.5,
    unit_cost: 18,
    selling_price: 36,
    supplier_id: "sup-3",
    status: "active",
    image_url: "https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=300&auto=format&fit=crop&q=80"
  },
  {
    id: "prod-9",
    name: "Aramid Protective Work Gloves (L)",
    nameAr: "قفازات أراميد واقية فائقة القوة (كبير)",
    sku: "SKU-5441",
    category: "Apparel",
    categoryAr: "الملابس والسلامة",
    current_stock: 110,
    reorder_point: 60,
    daily_sales_velocity: 5.5,
    unit_cost: 22,
    selling_price: 49,
    supplier_id: "sup-4",
    status: "active",
    image_url: "https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=300&auto=format&fit=crop&q=80"
  },
  {
    id: "prod-10",
    name: "Legacy Aluminum Alloy Bracket",
    nameAr: "دعامة سبائك الألومنيوم الكلاسيكية",
    sku: "SKU-1002",
    category: "Industrial",
    categoryAr: "الصناعي",
    current_stock: 15,
    reorder_point: 20,
    daily_sales_velocity: 0.1,
    unit_cost: 25,
    selling_price: 52,
    supplier_id: "sup-5",
    status: "discontinued",
    image_url: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=300&auto=format&fit=crop&q=80"
  }
];

export const seedPurchaseOrders = [
  {
    id: "po-1",
    po_number: "PO-2026-101",
    product_id: "prod-1",
    supplier_id: "sup-1",
    quantity: 200,
    unit_cost: 45,
    total_cost: 9000,
    status: "suggested",
    created_date: "2026-10-12",
    suggested_date: "2026-10-12",
    expected_delivery: "2026-10-25",
    ai_reasoning: "Stock is projected to deplete in 2.1 days at current velocity (8.5/day). Ordering 200 units accounts for supplier lead time (12 days) plus a 14-day safety buffer.",
    ai_reasoningAr: "من المتوقع نفاد المخزون خلال 2.1 يوم بمعدل الاستهلاك الحالي (8.5/يوم). طلب 200 وحدة يغطي مهلة المورد (12 يوماً) بالإضافة لهامش أمان لمدة 14 يوماً."
  },
  {
    id: "po-2",
    po_number: "PO-2026-102",
    product_id: "prod-2",
    supplier_id: "sup-2",
    quantity: 150,
    unit_cost: 72,
    total_cost: 10800,
    status: "suggested",
    created_date: "2026-10-12",
    suggested_date: "2026-10-12",
    expected_delivery: "2026-10-20",
    ai_reasoning: "Critical stock alert: Only 4 units remaining. Sales velocity is 5.2/day. High stockout risk before weekend. Expedited order recommended.",
    ai_reasoningAr: "تنبيه مخزون حرج: 4 وحدات فقط متبقية. سرعة المبيعات 5.2/يوم. خطر وشيك لنفاد المخزون قبل عطلة نهاية الأسبوع. يوصى بطلب عاجل."
  },
  {
    id: "po-3",
    po_number: "PO-2026-103",
    product_id: "prod-5",
    supplier_id: "sup-2",
    quantity: 100,
    unit_cost: 65,
    total_cost: 6500,
    status: "suggested",
    created_date: "2026-10-12",
    suggested_date: "2026-10-12",
    expected_delivery: "2026-10-22",
    ai_reasoning: "Zero stock balance detected. Unfulfilled backorders accumulating. Reordering 100 units restores minimum buffer threshold.",
    ai_reasoningAr: "رصيد المخزون صفر حالياً مع تراكم طلبات معلقة. طلب 100 وحدة يعيد مخزون الأمان إلى المستوى المطلوب."
  },
  {
    id: "po-4",
    po_number: "PO-2026-104",
    product_id: "prod-4",
    supplier_id: "sup-5",
    quantity: 100,
    unit_cost: 110,
    total_cost: 11000,
    status: "pending_approval",
    created_date: "2026-10-11",
    expected_delivery: "2026-10-24",
    ai_reasoning: "Stock dropped below reorder point of 40 units. Current stock 12.",
    ai_reasoningAr: "انخفض المخزون دون نقطة إعادة الطلب البالغة 40 وحدة. المخزون الحالي 12."
  },
  {
    id: "po-5",
    po_number: "PO-2026-105",
    product_id: "prod-7",
    supplier_id: "sup-1",
    quantity: 120,
    unit_cost: 38,
    total_cost: 4560,
    status: "approved",
    created_date: "2026-10-10",
    approval_date: "2026-10-11",
    expected_delivery: "2026-10-24"
  },
  {
    id: "po-6",
    po_number: "PO-2026-106",
    product_id: "prod-3",
    supplier_id: "sup-3",
    quantity: 400,
    unit_cost: 14,
    total_cost: 5600,
    status: "ordered",
    created_date: "2026-10-09",
    approval_date: "2026-10-09",
    expected_delivery: "2026-10-16"
  },
  {
    id: "po-7",
    po_number: "PO-2026-107",
    product_id: "prod-6",
    supplier_id: "sup-5",
    quantity: 1000,
    unit_cost: 3.5,
    total_cost: 3500,
    status: "received",
    created_date: "2026-10-02",
    approval_date: "2026-10-02",
    expected_delivery: "2026-10-08"
  },
  {
    id: "po-8",
    po_number: "PO-2026-108",
    product_id: "prod-9",
    supplier_id: "sup-4",
    quantity: 150,
    unit_cost: 22,
    total_cost: 3300,
    status: "received",
    created_date: "2026-09-28",
    approval_date: "2026-09-29",
    expected_delivery: "2026-10-05"
  }
];

export const seedMarketTrends = [
  {
    id: "trend-1",
    category: "Electronics & Semiconductors",
    categoryAr: "الإلكترونيات وأشباه الموصلات",
    trend_score: 88,
    direction: "up",
    forecast_change_pct: 18.4,
    signal_strength: "High",
    signal_strengthAr: "قوية جداً",
    summary: "Global semiconductor demand has accelerated driven by autonomous edge AI hardware. Foundry utilization rates exceed 94%, extending lead times by 10-14 days.",
    summaryAr: "تسارع الطلب العالمي على أشباه الموصلات نتيجة التوسع في أجهزة الذكاء الاصطناعي. نسب تشغيل المصانع تتجاوز 94%، مما يمدد المهل بـ 10-14 يوماً.",
    key_factors: ["Surge in Edge AI hardware", "Foundry capacity constraints", "Shipping route adjustments"],
    key_factorsAr: ["طفرة عتاد الذكاء الاصطناعي", "ضغوط الطاقة الإنتاجية للمصانع", "تعديلات مسارات الشحن البحري"],
    advisory: "Increase safety stock multiplier to 1.35x and secure advance rolling purchase contracts for Q4.",
    advisoryAr: "رفع معامل مخزون الأمان إلى 1.35 ضعف وإبرام عقود شراء دورية مسبقة للربع الرابع."
  },
  {
    id: "trend-2",
    category: "Sustainable Packaging",
    categoryAr: "التغليف المستدام والصديق للبيئة",
    trend_score: 76,
    direction: "up",
    forecast_change_pct: 12.1,
    signal_strength: "Moderate",
    signal_strengthAr: "متوسطة",
    summary: "New ESG circular-economy mandates across EMEA are accelerating conversion to recycled kraft paper and eco-polymer packaging crates.",
    summaryAr: "معايير الاستدامة والاقتصاد الدائري في منطقة الشرق الأوسط وأوروبا تسرع التحول نحو الكرتون المعاد تدويره وصناديق البوليمر البيئية.",
    key_factors: ["Regulatory compliance deadlines", "Raw pulp price stabilization", "Retailer brand guidelines"],
    key_factorsAr: ["مواعيد الالتزام التنظيمي", "استقرار أسعار لب الخشب", "إرشادات علامات التجزئة التجارية"],
    advisory: "Lock in 6-month fixed volume pricing with Atlas Industrial Packaging to hedge against pulp adjustments.",
    advisoryAr: "تثبيت أسعار الكميات لمدة 6 أشهر مع أطلس للتغليف للتحوط ضد تقلبات أسعار المواد الخام."
  },
  {
    id: "trend-3",
    category: "Petrochemicals & Raw Polymers",
    categoryAr: "البتروكيماويات والبوليمرات الخام",
    trend_score: 42,
    direction: "down",
    forecast_change_pct: -6.5,
    signal_strength: "High",
    signal_strengthAr: "قوية",
    summary: "Refinery expansions and declining shipping freight container rates have resulted in downstream price cooling across thermoplastic resins.",
    summaryAr: "توسعات مصافي التكرير وانخفاض أسعار شحن الحاويات أدت إلى انخفاض تكلفة الراتنجات البلاستيكية الحرارية عالمياً.",
    key_factors: ["Lower ocean freight tariffs", "Refinery supply overhang", "Reduced industrial manufacturing demand"],
    key_factorsAr: ["انخفاض تعرفة الشحن البحري", "وفرة المعروض من المصافي", "تباطؤ مؤقت في التصنيع الصناعي"],
    advisory: "Operate lean just-in-time replenishment buffers; delay bulk spot purchases to capitalize on declining spot rates.",
    advisoryAr: "الاعتماد على نظام التوريد في الوقت المحدد وتأجيل الشراء الفوري الضخم للاستفادة من هبوط الأسعار."
  },
  {
    id: "trend-4",
    category: "Industrial Hardware & Metals",
    categoryAr: "المعادن والمعدات الصناعية الثقيلة",
    trend_score: 64,
    direction: "up",
    forecast_change_pct: 7.8,
    signal_strength: "Moderate",
    signal_strengthAr: "متوسطة",
    summary: "Robust regional infrastructure and industrial logistics expansion provide steady support for fastener, alloy, and hardware consumption.",
    summaryAr: "مشاريع البنية التحتية واللوجستيات الإقليمية تدعم بشكل مستقر استهلاك السبائك والمعدات الصناعية وقطع التثبيت.",
    key_factors: ["Regional giga-projects pipeline", "Stable base metal futures", "Local assembly mandates"],
    key_factorsAr: ["مشاريع البنية التحتية العملاقة", "استقرار عقود المعادن الآجلة", "متطلبات التجميع المحلي"],
    advisory: "Maintain standard 30-day stock levels with primary domestic vendors to guarantee fulfillment SLA.",
    advisoryAr: "الحفاظ على مخزون قياسي يكفي 30 يوماً مع الموردين المحليين لضمان سرعة تلبية الطلبات."
  }
];

// 90-day historical inventory valuation curve generator
export function generate90DayInventoryHistory(baseValue = 186000) {
  const points = [];
  const now = new Date();
  let current = baseValue * 0.82;
  
  for (let i = 89; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    // Random walk with upward trend
    const dailyChange = (Math.random() - 0.46) * 3200;
    current = Math.max(120000, current + dailyChange);
    points.push({
      date: d.toISOString().split('T')[0],
      dayLabel: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      value: Math.round(current)
    });
  }
  return points;
}

// 30-day demand forecast generator
export function generate30DayDemandForecast(dailyVelocity = 64) {
  const days = [];
  const now = new Date();
  
  for (let i = 1; i <= 30; i++) {
    const d = new Date(now);
    d.setDate(d.getDate() + i);
    const dayOfWeek = d.getDay();
    const weekendFactor = (dayOfWeek === 5 || dayOfWeek === 6) ? 0.65 : 1.15;
    const seasonality = 1 + (Math.sin(i / 5) * 0.12);
    const projected = Math.round(dailyVelocity * weekendFactor * seasonality + (Math.random() * 8 - 4));
    const baseline = Math.round(dailyVelocity * (1 + (Math.random() * 0.1 - 0.05)));
    
    days.push({
      day: i,
      date: d.toISOString().split('T')[0],
      dayLabel: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      projected: Math.max(10, projected),
      baseline: Math.max(10, baseline)
    });
  }
  return days;
}
