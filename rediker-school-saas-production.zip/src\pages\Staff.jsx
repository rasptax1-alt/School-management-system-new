import React, { useState } from 'react';
import { useSchool } from '../context/SchoolContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  Users, 
  Search, 
  UploadCloud, 
  DownloadCloud, 
  Plus, 
  Phone, 
  Mail, 
  BookOpen, 
  X,
  Briefcase
} from 'lucide-react';
import { exportDataToCsv } from '../services/csvExportImport';

export function Staff({ onOpenCsvModal }) {
  const { currentSchool, staff, setStaff, showToast } = useSchool();
  const { t, lang, isRTL } = useLanguage();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);

  // New Staff form state
  const [fullNameAr, setFullNameAr] = useState('');
  const [fullNameEn, setFullNameEn] = useState('');
  const [role, setRole] = useState('أستاذ مادة');
  const [department, setDepartment] = useState('الرياضيات');
  const [phone, setPhone] = useState('');
  const [qualification, setQualification] = useState('بكالوريوس');
  const [salaryIQD, setSalaryIQD] = useState(1500000);

  const filteredStaff = staff.filter(st => {
    const matchesSearch = 
      (st.fullNameAr && st.fullNameAr.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (st.staffId && st.staffId.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (st.phone && st.phone.includes(searchQuery));
    const matchesDept = selectedDept === 'all' || st.department === selectedDept;
    return matchesSearch && matchesDept;
  });

  const handleExportCsv = () => {
    const formatted = filteredStaff.map(st => ({
      "الرقم_الوظيفي": st.staffId,
      "الاسم_الرباعي_عربي": st.fullNameAr,
      "الاسم_انجليزي": st.fullNameEn,
      "المسمى_الوظيفي": st.role,
      "القسم": st.department,
      "البريد_الإلكتروني": st.email,
      "رقم_الهاتف": st.phone,
      "المؤهل_العلمي": st.qualification,
      "الراتب_الشهري_دينار": st.salaryIQD,
      "المواد_المعينة": st.subjectsTaught?.join(', ') || '',
      "الحالة": st.status
    }));

    exportDataToCsv(formatted, `staff-${currentSchool.code}.csv`);
    showToast(isRTL ? 'تم تصدير ملف الكادر التدريسي CSV بنجاح' : 'Staff CSV exported successfully');
  };

  const handleAddSubmit = (e) => {
    e.preventDefault();
    if (!fullNameAr) return;

    const newStaffMember = {
      id: `stf-${Date.now()}`,
      schoolId: currentSchool.id,
      staffId: `TCH-${Math.floor(200 + Math.random() * 800)}`,
      fullNameAr,
      fullNameEn: fullNameEn || fullNameAr,
      role,
      roleEn: "Teacher",
      department,
      departmentEn: department,
      email: `${fullNameEn.toLowerCase().replace(/\s+/g, '.')}@school.edu.iq`,
      phone: phone || "07700000000",
      qualification,
      qualificationEn: qualification,
      salaryIQD: Number(salaryIQD),
      subjectsTaught: [department],
      classesAssigned: ["الرابع العلمي أ"],
      status: "على رأس العمل",
      joinDate: new Date().toISOString().split('T')[0]
    };

    setStaff(prev => [newStaffMember, ...prev]);
    showToast(`تمت إضافة ${newStaffMember.fullNameAr} إلى الكادر`, 'success');
    setShowAddModal(false);

    setFullNameAr('');
    setFullNameEn('');
    setPhone('');
  };

  const primaryColor = currentSchool.theme?.primary || '#0F766E';

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200/90 shadow-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-700 flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              {t('staff')} (Rediker Faculty)
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              دليل الكادر التدريسي والإداري • {currentSchool.nameAr} ({filteredStaff.length} موظف)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => onOpenCsvModal('staff')}
            className="px-3.5 py-2.5 rounded-xl border border-indigo-200 bg-indigo-50 text-indigo-800 text-xs font-bold hover:bg-indigo-100 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <UploadCloud className="w-4 h-4 text-indigo-700" />
            <span>{t('bulkImportStaff')}</span>
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-800 text-xs font-bold hover:bg-slate-50 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <DownloadCloud className="w-4 h-4 text-slate-600" />
            <span>{t('exportCsv')}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 rounded-xl text-white text-xs font-bold shadow-md hover:opacity-95 transition-all flex items-center gap-1.5"
            style={{ backgroundColor: primaryColor }}
          >
            <Plus className="w-4 h-4" />
            <span>{t('addStaff')}</span>
          </button>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute top-1/2 -translate-y-1/2 text-slate-400 right-3" />
          <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث بالاسم، الرقم الوظيفي، أو التخصص..."
            className="w-full pr-9 pl-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50 focus:bg-white"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-700 font-semibold focus:outline-none"
          >
            <option value="all">كافة الأقسام والتخصصات</option>
            <option value="الرياضيات">الرياضيات</option>
            <option value="اللغة العربية والتربية الإسلامية">اللغة العربية</option>
            <option value="العلوم والفيزياء">العلوم والفيزياء</option>
            <option value="تكنولوجيا المعلومات">تكنولوجيا المعلومات</option>
          </select>
        </div>
      </div>

      {/* Staff Table */}
      <div className="bg-white rounded-3xl border border-slate-200/90 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-start text-xs">
            <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
              <tr>
                <th className="p-3.5 text-start">{t('staffId')}</th>
                <th className="p-3.5 text-start">{t('staffName')}</th>
                <th className="p-3.5 text-start">{t('department')}</th>
                <th className="p-3.5 text-start">{t('role')}</th>
                <th className="p-3.5 text-start">المواد المعينة</th>
                <th className="p-3.5 text-start">الاتصال</th>
                <th className="p-3.5 text-center">{t('salary')}</th>
                <th className="p-3.5 text-center">{t('status')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStaff.map((st) => (
                <tr key={st.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="p-3.5 font-mono font-bold text-slate-700">{st.staffId}</td>
                  <td className="p-3.5 font-bold text-slate-900">
                    <div>{st.fullNameAr}</div>
                    <div className="text-[10px] text-slate-400 font-normal">{st.qualification}</div>
                  </td>
                  <td className="p-3.5 text-slate-700 font-medium">{st.department}</td>
                  <td className="p-3.5 text-slate-700">{st.role}</td>
                  <td className="p-3.5 text-slate-600">
                    <span className="px-2 py-0.5 rounded-md bg-slate-100 text-[11px] font-semibold">
                      {st.subjectsTaught?.join(', ') || 'المادة المقررة'}
                    </span>
                  </td>
                  <td className="p-3.5 text-slate-600 font-mono text-[11px]">
                    <div className="flex items-center gap-1">
                      <Phone className="w-3 h-3 text-slate-400" />
                      <span>{st.phone}</span>
                    </div>
                  </td>
                  <td className="p-3.5 text-center font-bold text-slate-900">
                    {st.salaryIQD?.toLocaleString()} {t('iqd')}
                  </td>
                  <td className="p-3.5 text-center">
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                      {st.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Staff Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div 
              className="p-5 text-white flex items-center justify-between"
              style={{ backgroundColor: primaryColor }}
            >
              <h3 className="font-extrabold text-base">{t('addStaff')}</h3>
              <button onClick={() => setShowAddModal(false)} className="text-white hover:opacity-80">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">{t('staffName')} (عربي) *</label>
                <input 
                  type="text" 
                  required
                  value={fullNameAr}
                  onChange={(e) => setFullNameAr(e.target.value)}
                  placeholder="مثال: أ. أحمد هاشم السلامي"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t('department')}</label>
                  <select 
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white"
                  >
                    <option value="الرياضيات">الرياضيات</option>
                    <option value="اللغة العربية">اللغة العربية</option>
                    <option value="الفيزياء والعلوم">الفيزياء والعلوم</option>
                    <option value="اللغة الإنجليزية">اللغة الإنجليزية</option>
                    <option value="تكنولوجيا المعلومات">تكنولوجيا المعلومات</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t('role')}</label>
                  <input 
                    type="text" 
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t('phone')}</label>
                  <input 
                    type="text" 
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="07700000000"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t('salary')} (دينار)</label>
                  <input 
                    type="number" 
                    value={salaryIQD}
                    onChange={(e) => setSalaryIQD(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 font-bold"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-white font-bold"
                  style={{ backgroundColor: primaryColor }}
                >
                  {t('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
